# ***** BEGIN GPL LICENSE BLOCK *****
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ***** END GPL LICENCE BLOCK *****

import mathutils as mathu
from mathutils import Vector

def get_vertices_center(verts, obj, local_space):
    vert_world_first = verts[0].co
    if not local_space:
        vert_world_first = obj.matrix_world @ verts[0].co

    x_min = vert_world_first.x
    x_max = vert_world_first.x
    y_min = vert_world_first.y
    y_max = vert_world_first.y
    z_min = vert_world_first.z
    z_max = vert_world_first.z

    for vert in verts:
        vert_world = vert.co
        if not local_space:
            vert_world = obj.matrix_world @ vert.co

        if vert_world.x > x_max:
            x_max = vert_world.x
        if vert_world.x < x_min:
            x_min = vert_world.x
        if vert_world.y > y_max:
            y_max = vert_world.y
        if vert_world.y < y_min:
            y_min = vert_world.y
        if vert_world.z > z_max:
            z_max = vert_world.z
        if vert_world.z < z_min:
            z_min = vert_world.z

    x_orig = ((x_max - x_min) / 2.0) + x_min
    y_orig = ((y_max - y_min) / 2.0) + y_min
    z_orig = ((z_max - z_min) / 2.0) + z_min

    return Vector((x_orig, y_orig, z_orig))


def get_verts_bounds(verts, obj, x_axis, y_axis, z_axis, local_space):

    center = get_vertices_center(verts, obj, local_space)

    x_min = 0.0
    x_max = 0.0
    y_min = 0.0
    y_max = 0.0
    z_min = 0.0
    z_max = 0.0

    for vert in verts:
        vert_world = vert.co
        if not local_space:
            vert_world = obj.matrix_world @ vert.co

        if x_axis:
            x_check = mathu.geometry.distance_point_to_plane(vert_world, center, x_axis)
            if x_check > x_max:
                x_max = x_check
            elif x_check < x_min:
                x_min = x_check

        if y_axis:
            y_check = mathu.geometry.distance_point_to_plane(vert_world, center, y_axis)
            if y_check > y_max:
                y_max = y_check
            elif y_check < y_min:
                y_min = y_check

        if z_axis:
            z_check = mathu.geometry.distance_point_to_plane(vert_world, center, z_axis)
            if z_check > z_max:
                z_max = z_check
            elif z_check < z_min:
                z_min = z_check

    return (x_max + abs(x_min), y_max + abs(y_min), z_max + abs(z_min), center)


def get_vertices_size(verts, obj):
    # if obj.mode == 'EDIT':
    # bm.verts.ensure_lookup_table()
    vert_world_first = obj.matrix_world @ verts[0].co
    # multiply_scale(vert_world_first, obj.scale)

    x_min = vert_world_first.x
    x_max = vert_world_first.x
    y_min = vert_world_first.y
    y_max = vert_world_first.y
    z_min = vert_world_first.z
    z_max = vert_world_first.z

    for vert in verts:
        vert_world = obj.matrix_world @ vert.co
        # multiply_scale(vert_world, obj.scale)

        if vert_world.x > x_max:
            x_max = vert_world.x
        if vert_world.x < x_min:
            x_min = vert_world.x
        if vert_world.y > y_max:
            y_max = vert_world.y
        if vert_world.y < y_min:
            y_min = vert_world.y
        if vert_world.z > z_max:
            z_max = vert_world.z
        if vert_world.z < z_min:
            z_min = vert_world.z

    x_size = (x_max - x_min)
    y_size = (y_max - y_min)
    z_size = (z_max - z_min)

    final_size = x_size
    if final_size < y_size:
        final_size = y_size
    if final_size < z_size:
        final_size = z_size

    return final_size
