# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty
import numpy as np
from .material_operators import HTOOL_OT_CurvesUVRefresh, HTOOL_OT_AssignRegionsFromObjProps
from mathutils import Vector, kdtree, Matrix, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
from .resample2d import interpol_Catmull_Rom_splines
from .ribbons_operations import HTOOL_OT_MeshRibbonsToCurve
from .particle_hair import HTOOL_OT_RibbonsFromParticleHairChild
from .hair_curve_helpers import HTOOL_OT_EmbedRoots,  HTOOL_OT_CurvesTiltAlign,  HTOOL_OT_CurvesTiltSmooth, HTOOL_OT_CurveRadiusFromUVWidth
from .utils.general_utils import create_new_curve_obj
import bgl
import gpu
from .hair_curve_helpers import get_obj_mesh_bvht
from .utils.helper_functions import calc_pow_inverted
from gpu_extras.batch import batch_for_shader
from .profile_operations import generate_profile, update_profile

# def handleHandlers():
#     modal_hair_settings = bpy.context.scene.ht_props.modal_hair
#
#     if modal_hair_settings.runModalHair:
#         if (hair_modal not in bpy.app.handlers.scene_update_post):
#             global last_time
#             last_time = time.time()
#             bpy.app.handlers.scene_update_post.append(hair_modal)
#             print('starting hair_modal')
#     else:
#         remList = []
#         for h in bpy.app.handlers.scene_update_post:
#             if h == hair_modal:  #or h.__name__ == "hair_modal"
#                 remList.append(h)
#         for h in remList:
#             bpy.app.handlers.scene_update_post.remove(h)
#             print('finishing hair_modal')
shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
STRANDS_CO = []  # for faster drawing postpixel

# Any Python object can act as the subscription's owner.
owner = object()
owner_bpsys = object()

def draw_strands_overlay_px(self, context):
    if not bpy.context.space_data.overlay.show_overlays:
        return
    if not context.active_object or not STRANDS_CO:
        return
    settings_modal = context.active_object.ht_props.modal_hair
    if settings_modal.runModalHair is False or settings_modal.drawStrands is False:
        return
    # strands_points.append(np.einsum('ij,aj->ai', mat, points_to_vec)) #mat times point list
    average_co = Vector((0, 0, 0))
    for strand in STRANDS_CO:  # for strand point
        average_co += strand[0]  # use rotts for average
    average_co = average_co/len(STRANDS_CO)

    camera_pos = context.region_data.view_matrix.inverted().translation
    camDistance = camera_pos - average_co
    maxRange = 1 - (settings_modal.drawOffset / camDistance.length_squared) / 20
    color = settings_modal.draw_color
    bgl.glLineWidth(2)
    bgl.glEnable(bgl.GL_BLEND)
    bgl.glEnable(bgl.GL_DEPTH_TEST)
    bgl.glDepthRange(0, maxRange)
    for strip in STRANDS_CO:
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": strip})
        shader.bind()
        shader.uniform_float("color", (color[0], color[1], color[2], color[3]))
        batch.draw(shader)
    # restore opengl defaults
    bgl.glDepthRange(0, 1)
    bgl.glDisable(bgl.GL_DEPTH_TEST)
    bgl.glLineWidth(1)
    bgl.glDisable(bgl.GL_BLEND)


handle = []


def drawHair(context):
    if context.active_object.ht_props.modal_hair.runModalHair:
        if handle:
            bpy.types.SpaceView3D.draw_handler_remove(handle[0], 'WINDOW')
        args = (None, bpy.context)  # u can pass arbitrary class as first param  Instead of (self, context)
        handle[:] = [bpy.types.SpaceView3D.draw_handler_add(draw_strands_overlay_px, args, 'WINDOW', 'POST_VIEW')]
    else:
        if handle:
            bpy.types.SpaceView3D.draw_handler_remove(handle[0], 'WINDOW')
            handle[:] = []


class ParticleModalSettings(bpy.types.PropertyGroup):
    def reset_tilt_run(self, context):
        partsysMod = context.active_object.particle_systems.active  # use first
        if partsysMod.name:
            hair_obj = bpy.data.objects[partsysMod.name]
            pts_cnt = len(hair_obj.data.splines[0].points) if hair_obj.data.splines[0].type in {'NURBS', 'POLY'} else len(hair_obj.data.splines[0].bezier_points )
            one_rad = (0,) * pts_cnt
            for spl in hair_obj.data.splines:
                pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                pts.foreach_set("tilt", one_rad)
        self['resetTilt'] = False
        self['smoothTiltStrength'] = 0
        self.alignToSurface = False

    def clear_radius(self, context):
        if not self['vg_radius']:
            partsysMod = context.active_object.particle_systems.active  # use first
            if partsysMod.name:
                hair_obj = bpy.data.objects[partsysMod.name]
                pts_cnt = len(hair_obj.data.splines[0].points) if hair_obj.data.splines[0].type in {'NURBS', 'POLY'} else len(hair_obj.data.splines[0].bezier_points )
                one_rad = (1,) * pts_cnt
                for spl in hair_obj.data.splines:
                    pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                    pts.foreach_set("radius", one_rad)
                hair_obj.update_tag()


    def smooth_tilt_check(self, context):
        if not self.alignToSurface:
            self['smoothTiltStrength'] = 0
        else:
            self.run_update(context)

    def run_update(self, context):
        # do some fake operation to force model hair update
        global FORCE_UPDATE
        FORCE_UPDATE = True

    def get_width(self):
        active_obj = bpy.context.active_object
        if active_obj:
            part_name = active_obj.particle_systems.active.name
            if part_name in bpy.context.scene.objects.keys():
                obj = bpy.data.objects[part_name]
                if obj.type == 'CURVE':
                    return obj.ht_props.profile_props.strandWidth
        return 1

    def set_width(self, value):
        active_obj = bpy.context.active_object
        if active_obj and active_obj.type == 'MESH':
            part_name = active_obj.particle_systems.active.name
            if part_name in bpy.context.scene.objects.keys():
                obj = bpy.data.objects[part_name]
                if obj.type == 'CURVE':
                    obj.ht_props.profile_props.strandWidth = value

    def update_width(self, context):
        active_obj = bpy.context.active_object
        if active_obj and active_obj.type == 'MESH':
            part_name = active_obj.particle_systems.active.name
            obj = bpy.data.objects.get(part_name)
            if obj and obj.type == 'CURVE':
                update_profile(obj, strandWidth=self.profile_width)

    def switch_profile(self, context):
        if self.set_profile != 'KEEP':
            part_name = context.active_object.particle_systems.active.name
            if part_name in context.scene.objects.keys():
                obj = bpy.data.objects[part_name]
                if obj.type == 'CURVE':
                    generate_profile(obj, self.set_profile, strandWidth=self.profile_width)

    def switch_type(self, context):
        active_obj = bpy.context.active_object
        part_name = active_obj.particle_systems.active.name
        obj = bpy.data.objects.get(part_name)
        if obj and obj.type == 'CURVE':
            override = context.copy()
            override.update({
                'active_object': obj,
                'object': obj,
                'particle_edit_object': None,
                'mode': 'EDIT_CURVE',
                'selected_objects':[obj],
                'selected_editable_objects':[obj],
                'objects_in_mode':[obj],
                'objects_in_mode_unique_data':[obj],
                'edit_object':obj,
                'editable_objects':[obj],
            })
            bpy.ops.curve.spline_type_set( override, type=self.hairType) # coverride doea not work


    # def update_uv(self, context):
    #     active_obj = bpy.context.active_object
    #     if active_obj and active_obj.type == 'MESH':
    #         part_name = active_obj.particle_systems.active.name
    #         if part_name in bpy.context.scene.objects.keys():
    #             obj = bpy.data.objects[part_name]
    #             obj.ht_props['use_auto_uv'] = self.use_auto_uv
    #             if self.use_auto_uv:
    #                 HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(context.active_object)


    with_children: BoolProperty(name="Generate children",
                                description="Generate children hairs (require at least three parent strands)", default=False, update=run_update)
    include_parent_strands: BoolProperty(name="Include Parent Strands",
                                         description="Include parent strands when generating hair cards", default=False, update=run_update)
    embedValue: FloatProperty(name="Embed Roots Depth", description="Embed curve ribbons roots depth", default=0, min=0, max=10, update=run_update)
    points_count: IntProperty(name="Points per strand", description="How many points generate for each strand", default=5, min=2, soft_max=20, update=run_update)
    smooth_curves: IntProperty(name="Strand Smoothing", default=0, min=0, max=6, update=run_update)
    hairType: bpy.props.EnumProperty(name="Type", default="NURBS",
                                     items=(("NURBS", "Nurbs Curves", ""),
                                            ("POLY", "Poly Curves", "")), update=run_update) # only affects new strands...
    offset_tip: FloatProperty(name="Offset to tip", description="Move spline points more toward tip", default=0, min=0, max=1, subtype='PERCENTAGE', update=run_update)
    offset_root: FloatProperty(name="Offset to root", description="Move spline points more toward root", default=0, min=0, max=1, subtype='PERCENTAGE', update=run_update)

    # use_auto_uv: bpy.props.BoolProperty(name="Auto UV", default=True, description="Assign uv automatically to drawn strand.\nDetailed setup can be done under UV Image Editor->Right Sidebar->Hair Tool UV Tab", update=update_uv)
    profile_width: FloatProperty(name="Width", description="Profile width - affects all strands profle width", default=0.5, min=0.0, soft_max=10, set=set_width, get=get_width, update=update_width)
    taper_amount: FloatProperty(name="Taper amount", description="Taper amount", default=0, min=0, max=1, update=run_update)
    taper_shape: FloatProperty(name="Taper Shape", description="Taper Shape", default=0, min=-1, max=1,  update=run_update)


    set_profile: bpy.props.EnumProperty(name='Profile', description='',
                                        items=[
                                            ('ROUND', 'Round', 'Curves will have cylindrical profile'),
                                            ('OBJECT', 'Flat', 'Curves will have flat (ribbon) profile'),
                                            ('KEEP', 'Use Current', 'Do not change current curve profile')
                                        ], default='OBJECT', update=switch_profile)
    alignToSurface: BoolProperty(name="Tilt aligning", description="Enable interactive aligning curve ribbons to target surface",
                                 default=False, update=run_update)
    smoothTiltStrength: IntProperty(name="Tilt smoothing strength", description="Enable tilt smoothing \n Works only when \'Tilt Aligning\' is enabled",
                                    default=0, min=0, max=5, update=smooth_tilt_check)
    resetTilt: BoolProperty(name="Reset tilt", description="Reset curve ribbon tilt", default=False, update=reset_tilt_run)
    childCount: IntProperty(name="Child count", default=100, min=10, soft_max=3000, update=run_update)
    # child_hq_placement: BoolProperty(name="child even spacing", description='More uniform child particle distribution \n(WIP implementation - wont work with vertex weights, bit slow)', default=False,  update=run_update)
    placement_jittering: IntProperty(name="Placement", description="Placement Randomization/Face \n"
                                    "Helps even out particle distribution \n"
                                    "0 = automatic", default=0, min=0, max=1000, update=run_update)
    lenSeed: IntProperty(name="Length Seed", default=1, min=1, max=1000, update=run_update)
    randomize_length: FloatProperty(name="Length", description="Randomize length", default=0, min=0, max=1, subtype='PERCENTAGE', update=run_update)

    clump: FloatProperty(name="Clump", description="amount of clumping", default=0, min=0, max=1, update=run_update)
    clump_shape: FloatProperty(name="Clump Shape", description="Clump Shape", default=0, min=-1, max=1,  update=run_update)

    rot_seed: IntProperty(name="Noise Seed", default=1, min=1, max=1000, update=run_update)
    randomize_rot: FloatProperty(name="Rotation", description="Randomize rotation of child chair strands.", default=0.0, min=0.0, max=1.0, update=run_update)

    vg_density: bpy.props.StringProperty(name='Density', description='Vertex group to control strands density', default='')
    ivg_density: bpy.props.BoolProperty(name='Invert Density', description='', default=False)

    vg_length: bpy.props.StringProperty(name='Length', description='Vertex group to control strands length', default='')
    ivg_length: bpy.props.BoolProperty(name='Invert Length', description='', default=False)

    vg_rotation: bpy.props.StringProperty(name='Rotation', description='Vertex group to control random rotation strength', default='')
    ivg_rotation: bpy.props.BoolProperty(name='Invert Rotation', description='', default=False)

    vg_radius: bpy.props.StringProperty(name='Radius', description='Vertex group to control strand radius', default='', update=clear_radius)
    ivg_radius: bpy.props.BoolProperty(name='Invert Radius', description='', default=False)

    vg_clump: bpy.props.StringProperty(name='Clump', description='Vertex group to control strand clumping', default='')
    ivg_clump: bpy.props.BoolProperty(name='Invert Clump', description='', default=False)

    vg_taper: bpy.props.StringProperty(name='Taper', description='Vertex group to control strand tapering', default='')
    ivg_taper: bpy.props.BoolProperty(name='Invert taper', description='', default=False)

    particle_settings: bpy.props.EnumProperty(name='Settings', description='Use Blender particle settings or Hair Tool custom settings for hair generation',
        items=[
            ('BLENDER', 'Use Blender Child Settings', 'Generate child curves based on blender particle hair settings'),
            ('HAIR_TOOL', 'Use Hair Tool Child Settings', 'Generate child curves based on Hair Tool groom settings')
        ], default='HAIR_TOOL', update=run_update)

class ModalHairSettings(bpy.types.PropertyGroup):
    def modalHairCheck(self, context):
        if context.mode == 'PARTICLE':
            global FORCE_UPDATE
            FORCE_UPDATE = True
            if self.runModalHair:
                particle_id = context.active_object.particle_systems.active_index
                while len(self.particle_system_modal_settings) < particle_id+1:
                    self.particle_system_modal_settings.add()
                drawHair(context)
                bpy.ops.object.modal_hair_refresh('INVOKE_DEFAULT')  # seemsSmoother
        else:
            self['runModalHair'] = False

    def run_update(self, context):
        # do some fake operation to force model hair update
        global FORCE_UPDATE
        FORCE_UPDATE = True


    runModalHair: BoolProperty(name="Interactive Grooming", description="Generate curve ribbons and update them periodically", default=False, update=modalHairCheck)

    hairType: bpy.props.EnumProperty(name="Hair Type", default="NURBS",
        items=(("NURBS", "Nurbs", ""),
            ("POLY", "Poly", "")), update=run_update)

    particle_system_modal_settings: bpy.props.CollectionProperty(type=ParticleModalSettings)

    drawStrands: BoolProperty(name="Parent strands overlay", description="Draw orange overlay on top of parent strands", default=False)
    drawOffset: bpy.props.FloatProperty(name="Draw Offset", description="Parent Strand Draw Offset (similar to Draw In Front optio in Blender)", min=0.0, max=1.0, default=0.5, subtype='FACTOR')
    draw_color: bpy.props.FloatVectorProperty(name="Color", description="Color", default=(0.8, 0.4, 0.0, 1), subtype='COLOR', size=4, max=1, min=0)


class ICOMB_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        idx = int(item.path_from_id()[-2]) # particleModalSettings type
        obj = context.active_object
        target_psys_name = obj.particle_systems[idx].name if idx < len(obj.particle_systems) else 'No Target'
        row = layout.row(align=True)
        row.label(text=target_psys_name, icon= 'MOD_PARTICLES' )
        # row.operator('particles.delete_settings', icon='REMOVE', text='').index = idx


class HTOOL_MT_InteractiveHairMenu(bpy.types.Menu):
    bl_idname = "HTOOL_MT_InteractiveHairMenu"
    bl_label = "Hair Tool Menu Panel"
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.particle_systems.active_index < len(obj.ht_props.modal_hair.particle_system_modal_settings)

    def draw(self, context):
        layout = self.layout
        layout.operator('particles.copy_comb_settings', icon='COPYDOWN')
        layout.operator('particles.paste_comb_settings', icon='PASTEDOWN')
        layout.operator('particles.scale_particles')

class HTOOL_PT_ModalParticleHairParent:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Hair Tool'
    bl_context = "particlemode"


class HTOOL_PT_ModalParticleHair(HTOOL_PT_ModalParticleHairParent, bpy.types.Panel):
    bl_idname = "HTOOL_PT_ModalParticleHair"
    bl_label = "Hair Grooming"

    @classmethod
    def poll(cls, context):
        return context.active_object

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        row = layout.row(align=True)
        row.template_list("ICOMB_UL_List", "", modal_hair_settings, "particle_system_modal_settings", obj.particle_systems, "active_index", rows=2)
        col = row.column(align=True)
        col.operator('particles.create_settings', icon='ADD', text='')
        col.operator('particles.delete_settings', icon='REMOVE', text='')
        # col.separator()
        col.menu("HTOOL_MT_InteractiveHairMenu", icon='DOWNARROW_HLT', text="")
        col = layout.column()
        # col.enabled = obj.particle_systems.active != None
        if len(modal_hair_settings.particle_system_modal_settings) < particle_id + 1:
            col.operator('particles.create_settings')
        else:
            ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
            col.prop(modal_hair_settings, 'runModalHair', icon="PARTICLEMODE")
            col.prop(ht_part_sys_props, 'particle_settings',  expand=True)

        col = layout.column()
        col.prop(modal_hair_settings, 'drawStrands', icon="OVERLAY")
        if modal_hair_settings.drawStrands:
            row = col.row(align=True)
            row.prop(modal_hair_settings, 'drawOffset')
            row.prop(modal_hair_settings, 'draw_color', text='')

            # if ht_part_sys_props.particle_settings == 'HAIR_TOOL':
            #     row = layout.row(align=True)
            #     col = layout.column(align=True)
                # col.prop(ht_part_sys_props, 'with_children', icon='PARTICLE_PATH')



class HTOOL_PT_ModalCurveHair(HTOOL_PT_ModalParticleHairParent, bpy.types.Panel):
    bl_parent_id = "HTOOL_PT_ModalParticleHair"
    bl_idname = 'HTOOL_PT_ModalCurveHair'
    bl_label = "Generated Curves Settings"
    bl_order = 10
    # bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(ls, context):
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        if len(modal_hair_settings.particle_system_modal_settings) == 0 or particle_id > len(modal_hair_settings.particle_system_modal_settings)-1:
            return False
        return True


    def draw(self, context):
        layout = self.layout
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
        gen_hair_obj = None
        if obj.particle_systems.active:
            target_name = obj.particle_systems.active.name
            gen_hair_obj = bpy.data.objects.get(target_name)

        col = layout.column(align=True)
        col.prop(ht_part_sys_props, 'hairType')
        if ht_part_sys_props.particle_settings == 'HAIR_TOOL':
            col.prop(ht_part_sys_props, 'points_count')
        else:
            col.prop(obj.particle_systems.active.settings, 'display_step')
        if gen_hair_obj:
            col.prop(gen_hair_obj.ht_props, 'use_auto_uv', emboss=True, icon='UV_ISLANDSEL')

        col = layout.column(align=True)
        col.label(text='Profile')
        col.prop(ht_part_sys_props, 'set_profile', text='Type')
        if gen_hair_obj: #does target obj exist
            col.prop(ht_part_sys_props, 'profile_width')
            col.prop(ht_part_sys_props, 'taper_amount')
            col.prop(ht_part_sys_props, 'taper_shape')


        if ht_part_sys_props.particle_settings == 'HAIR_TOOL':
            col = layout.column(align=True)
            col.prop(ht_part_sys_props, 'offset_tip')
            col.prop(ht_part_sys_props, 'offset_root')

        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(ht_part_sys_props, 'alignToSurface', icon_only=False, icon="SNAP_NORMAL")
        row.prop(ht_part_sys_props, 'resetTilt', icon_only=True, icon="FILE_REFRESH")
        row = col.row(align=True)
        row.prop(ht_part_sys_props, 'smoothTiltStrength')
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(ht_part_sys_props, 'embedValue')
        col.prop(ht_part_sys_props, 'smooth_curves', icon_only=False)

        col = layout.column(align=True)
        row = col.row(align=True)


class HTOOL_PT_ModalChildSettings(HTOOL_PT_ModalParticleHairParent, bpy.types.Panel):
    bl_parent_id = "HTOOL_PT_ModalParticleHair"
    bl_idname = 'HTOOL_PT_ModalChildSettings'
    bl_label = "Children"
    bl_order = 20
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
        self.layout.prop(ht_part_sys_props, 'with_children', text='')

    @classmethod
    def poll(ls, context):
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        if len(modal_hair_settings.particle_system_modal_settings) == 0 or particle_id > len(modal_hair_settings.particle_system_modal_settings)-1:
            return False
        ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
        if obj and ht_part_sys_props.particle_settings == 'HAIR_TOOL':
            return True
        else:
           return False

    def draw(self, context):
        layout = self.layout
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
        col = layout.column(align=True)
        if  ht_part_sys_props.with_children:
            col.prop(ht_part_sys_props, 'include_parent_strands', icon='OUTLINER_DATA_HAIR')
            col = layout.column(align=True)
            # col.prop(ht_part_sys_props, 'child_hq_placement')
            col.prop(ht_part_sys_props, 'childCount')

            col = layout.column(align=True)
            col.prop(ht_part_sys_props, 'clump')
            col.prop(ht_part_sys_props, 'clump_shape')
            col.label(text='Randomize')
            col.prop(ht_part_sys_props, 'placement_jittering')
            row = col.row(align=True)
            split = row.split(factor=0.7, align=True)
            split.prop(ht_part_sys_props, 'randomize_length')
            split.prop(ht_part_sys_props, 'lenSeed', text='Seed')

            row = col.row(align=True)
            split = row.split(factor=0.7, align=True)
            split.prop(ht_part_sys_props, 'randomize_rot')
            split.prop(ht_part_sys_props, 'rot_seed', text='Seed')


class HTOOL_PT_ModalVertGroups(HTOOL_PT_ModalParticleHairParent, bpy.types.Panel):
    bl_parent_id = "HTOOL_PT_ModalParticleHair"
    bl_idname = 'HTOOL_PT_ModalVertGroups'
    bl_order = 30
    bl_label = "Vertex Groups"
    # bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(ls, context):
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        if len(modal_hair_settings.particle_system_modal_settings) == 0 or particle_id > len(modal_hair_settings.particle_system_modal_settings)-1:
            return False
        ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
        if obj and ht_part_sys_props.particle_settings == 'HAIR_TOOL' and ht_part_sys_props.with_children:
            return True
        else:
           return False

    def draw(self, context):
        layout = self.layout
        obj = context.object
        modal_hair_settings = obj.ht_props.modal_hair
        particle_id = obj.particle_systems.active_index
        ht_part_sys_props = modal_hair_settings.particle_system_modal_settings[particle_id]
        if ht_part_sys_props.particle_settings == 'HAIR_TOOL':
            col = layout.column()
            row = col.row(align=True)
            sub = row.row(align=True)
            sub.use_property_decorate = False
            sub.prop_search(ht_part_sys_props, "vg_density", obj, "vertex_groups", text="Density")
            row.prop(ht_part_sys_props, "ivg_density", text="", toggle=True, icon='ARROW_LEFTRIGHT')

            row = col.row(align=True)
            sub = row.row(align=True)
            sub.use_property_decorate = False
            sub.prop_search(ht_part_sys_props, "vg_length", obj, "vertex_groups", text="Length")
            row.prop(ht_part_sys_props, "ivg_length", text="", toggle=True, icon='ARROW_LEFTRIGHT')

            row = col.row(align=True)
            sub = row.row(align=True)
            sub.use_property_decorate = False
            sub.prop_search(ht_part_sys_props, "vg_clump", obj, "vertex_groups", text="Clump")
            row.prop(ht_part_sys_props, "ivg_clump", text="", toggle=True, icon='ARROW_LEFTRIGHT')

            row = col.row(align=True)
            sub = row.row(align=True)
            sub.use_property_decorate = False
            sub.prop_search(ht_part_sys_props, "vg_taper", obj, "vertex_groups", text="Taper")
            row.prop(ht_part_sys_props, "ivg_taper", text="", toggle=True, icon='ARROW_LEFTRIGHT')

            row = col.row(align=True)
            sub = row.row(align=True)
            sub.use_property_decorate = False
            sub.prop_search(ht_part_sys_props, "vg_rotation", obj, "vertex_groups", text="Rotation")
            row.prop(ht_part_sys_props, "ivg_rotation", text="", toggle=True, icon='ARROW_LEFTRIGHT')

            row = col.row(align=True)
            sub = row.row(align=True)
            sub.use_property_decorate = False
            sub.prop_search(ht_part_sys_props, "vg_radius", obj, "vertex_groups", text="Radius")
            row.prop(ht_part_sys_props, "ivg_radius", text="", toggle=True, icon='ARROW_LEFTRIGHT')



last_operation = None

ignore_list = ignored_operators = [
    "bpy.ops.object.embed_roots",
    "bpy.ops.particles.copy_comb_settings",
    "bpy.ops.object.curves_smooth",
    "bpy.ops.object.generate_profile",
    "bpy.ops.object.transform_apply",
    "bpy.ops.object.curves_align_tilt",
    "bpy.ops.object.curves_smooth_tilt",
    "bpy.ops.object.modal_hair_refresh",
]
FORCE_UPDATE = True
IGNORED_OPERATORS_NAMES = [
    'OBJECT_OT_modal_hair_refresh',
    'WM_OT_radial_control',
    'PARTICLE_OT_select_more',
    'PARTICLE_OT_select_less',
    'PARTICLE_OT_select_all']


def taper_shape(x, shape):
    """
    Adjust hair radius by Hair Shape
    f(0, shape) = 0, f(1, shape) = 1, f(x, 0) - linear
    shape > 0 - curved up, shape < 0 - curved down
    """
    return x ** (10.0 ** -shape)

def clump_profile(root_rad, tip_rad, clump_shape, length ):
    return np.fromiter( (root_rad + (tip_rad - root_rad) * taper_shape(i / (length - 1), clump_shape) for i in range(length)), 'f')


class HTOOL_OT_ModalTimerOperator(bpy.types.Operator):
    """Operator which runs its self from a timer"""
    bl_idname = "object.modal_hair_refresh"
    bl_label = "Modal hair refresh"
    bl_options = {"REGISTER", "UNDO"}

    particle_obj_ev = None
    pointsChildRoots = None
    old_points_settings = None
    back_pointsChildRoots = []

    @staticmethod
    def scale_strand(strand, scale):
        if scale == 1:
            return
        for p in strand[1:]:
            forward_dir = p - strand[0]
            p[:] = forward_dir * scale + strand[0]  # override source strand pt_co

    def calc_wg_scale_factor(self, vg_len_name, invert):
        '''return vg scale factor for each face for eval obj (with mods)'''
        vg_len_scale = []
        if vg_len_name:  # calc weight based on root point
            wg_idx = self.active_obj.vertex_groups[vg_len_name].index
            if wg_idx != -1:  # scale by vgrups
                mesh_from_eval = self.obj_eval.to_mesh()  # evaluated so with modifiers
                for face in mesh_from_eval.polygons:  # ? should give same order as polygon face.ids order
                    averageWeight = 0
                    for vertIndex in face.vertices:  # DONE: check if work on mesh with modifiers
                        for group in mesh_from_eval.vertices[vertIndex].groups:
                            if group.group == wg_idx:
                                averageWeight += group.weight
                                break
                    vg_weight = 1 - averageWeight / len(face.vertices) if invert else averageWeight / len(face.vertices)
                    vg_len_scale.append(vg_weight)
                self.obj_eval.to_mesh_clear()
        return vg_len_scale

    def create_hair(self, context):
        '''Do this on init() once'''
        particleObj = self.obj_eval
        partsysMod = particleObj.particle_systems.active  # use first
        hair_name = partsysMod.name
        if hair_name not in bpy.data.objects.keys():
            curveObj = create_new_curve_obj(hair_name, bpy.data.objects[particleObj.name], set_active=False)
            curveObj.matrix_world = particleObj.matrix_world
            curveObj.ht_props.target_obj = particleObj.name  # store source surface for snapping oper
            self.target_hair_obj = curveObj
            self.hair_ribbon_update(context)
            ht_part_sys_props = particleObj.ht_props.modal_hair.particle_system_modal_settings[particleObj.particle_systems.active_index]
            target_profile = 'OBJECT' if ht_part_sys_props.set_profile == 'KEEP' else ht_part_sys_props.set_profile
            if 'diagonal' not in curveObj.keys():  # or else it may happen - profille * digonal == 0
                # curveObj['diagonal'] = context.active_object.dimensions.length / 2
                curveObj['diagonal'] = context.active_object.dimensions.length / context.active_object.matrix_world.to_scale().length
            generate_profile(curveObj, target_profile , strandWidth=ht_part_sys_props.profile_width)
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(curveObj)
            # curveObj.ht_props['use_auto_uv'] = True

        else:
            curveObj = bpy.data.objects[hair_name]
            curveObj.hide_viewport = False
        self.target_hair_obj = curveObj

        if curveObj.name not in context.scene.objects.keys():
            if curveObj.ht_props.hair_settings.hair_curve_child != '':  # try switching mesh ribbon to curve ribbon
                mesh_hair_child = bpy.data.objects.get(curveObj.ht_props.hair_settings.hair_curve_child)
                if mesh_hair_child:
                    HTOOL_OT_MeshRibbonsToCurve.switch_mesh_to_curve_ribbon(context, mesh_hair_child, set_active=False)
                    curveObj.select_set(False)
                else:
                    curveObj.ht_props.hair_settings.hair_curve_child = ''  # reset broken ptr
                    context.collection.objects.link(curveObj)
            else:
                context.collection.objects.link(curveObj)
        return curveObj


    def blender_particle_hair(self, context):
        bpy.ops.particle.particle_edit_toggle()

        p_sys = self.obj_eval.particle_systems.active  # use last

        num_parents = len(p_sys.particles)
        hair_start_idx, strands_cnt = (0, num_parents) if p_sys.settings.child_type == 'NONE' else (num_parents, len(p_sys.child_particles))

        # NOTE: points which are not available are equal to (0, 0, 0). We will weld such points by updating (0, 0, 0) point to previous point
        length = 2 ** p_sys.settings.display_step + 1
        obj = self.obj_eval
        all_points = np.fromiter(
            (elem for particle_idx in range(hair_start_idx, hair_start_idx + strands_cnt)
                for step in range(length)
                for elem in p_sys.co_hair(obj, particle_no=particle_idx, step=step)), 'f'
        ).reshape(-1, length, 3)

        # radius_scale = 1
        # Blender "radius" field value is in fact Diameter. Divide it by 2
        root = p_sys.settings.root_radius / 2.
        tip = p_sys.settings.tip_radius / 2.

        points_radii = clump_profile(root, tip, p_sys.settings.shape, length)

        bpy.ops.particle.particle_edit_toggle()
        return all_points, points_radii


    def particle_hair_to_points_with_children(self, context):
        ''' return list of child strands, per strand radius, and per strand taper (strand rad list) '''
        partsysMod = self.obj_eval.particle_systems.active  # use last
        particle_id = self.obj_eval.particle_systems.active_index  # use last
        ht_part_sys_props = context.active_object.ht_props.modal_hair.particle_system_modal_settings[particle_id]  # cos using self.active_obj gives random settings...
        particle_count = len(partsysMod.particles)
        if particle_count < 3:  # create two fake strands so that barycentric works
            self.report({'INFO'}, 'Create at least 3 parent/guide strands')
            return None, None

        pointsList_hair = self.read_particle_hair(context, partsysMod)
        if ht_part_sys_props.offset_tip or ht_part_sys_props.offset_root:
            offset_tip_tns = calc_pow_inverted(ht_part_sys_props.offset_tip+1, ht_part_sys_props.points_count)
            offset_root_tip_tns = np.power(offset_tip_tns, ht_part_sys_props.offset_root+1)
        else:
            offset_root_tip_tns = None

        # same_point_count cos barycentric transform requires it
        # create nnew Part Sytem with uniform points
        # do we need to recalculate pointsChildRoots ?
        new_point_settings = [ht_part_sys_props.childCount, ht_part_sys_props.placement_jittering, ht_part_sys_props.vg_density, ht_part_sys_props.ivg_density]
        if self.old_points_settings != new_point_settings:  # * get surface points from new temp part sytem.
            pointsChildRoots = HTOOL_OT_RibbonsFromParticleHairChild.createUniformParticleSystem(
                context, ht_part_sys_props.childCount,
                ht_part_sys_props.placement_jittering,
                world_space=True,
                use_custom_density = True,
                density=ht_part_sys_props.vg_density,
                idensity=ht_part_sys_props.ivg_density)  # return child part roots positions

            self.old_points_settings = new_point_settings
            self.back_pointsChildRoots = [p.copy() for p in pointsChildRoots]  # cos original points sometimes go to Nan,
            self.depsgraph.update()  # * update back to combed particle system
            self.obj_eval = context.active_object.evaluated_get(self.depsgraph)
            partsysMod = self.obj_eval.particle_systems.active  # use last
            particle_id = self.obj_eval.particle_systems.active_index  # use last
        else:
            pointsChildRoots = self.back_pointsChildRoots

        parent_strands = interpol_Catmull_Rom_splines(pointsList_hair, ht_part_sys_props.points_count, uniform_spacing=False,
                                                      same_point_count=True, tn_fallof=offset_root_tip_tns)  # just gives smoother result on borders
        parentRoots = [strand[0].copy() for strand in parent_strands]  # first point of roots
        kd = kdtree.KDTree(particle_count)
        [kd.insert(root, i) for i, root in enumerate(parentRoots)]
        kd.balance()

        np.random.seed(ht_part_sys_props.rot_seed)
        rand_3 = np.random.rand(ht_part_sys_props.childCount, 3)
        quat_u1_u2_u3_u4 = np.empty((ht_part_sys_props.childCount, 4), 'f')
        quat_u1_u2_u3_u4[:, 0] = np.sqrt(1-rand_3[:, 0])*np.sin(2*3.14*rand_3[:, 1])
        quat_u1_u2_u3_u4[:, 1] = np.sqrt(1-rand_3[:, 0])*np.cos(2*3.14*rand_3[:, 1])
        quat_u1_u2_u3_u4[:, 2] = np.sqrt(rand_3[:, 0])*np.sin(2*3.14*rand_3[:, 2])
        quat_u1_u2_u3_u4[:, 3] = np.sqrt(rand_3[:, 0])*np.cos(2*3.14*rand_3[:, 2])
        zero_quat = Quaternion((1, 0, 0, 0))

        np.random.seed(ht_part_sys_props.lenSeed)
        lenWeights = (1+(2*np.random.rand(ht_part_sys_props.childCount)-1.0)*ht_part_sys_props.randomize_length).tolist()

        vg_len_name = ht_part_sys_props.vg_length
        if vg_len_name and (not self.wg_scale_factor or self.update_vg_mask['length']):
            self.wg_scale_factor = self.calc_wg_scale_factor(vg_len_name, invert=ht_part_sys_props.ivg_length)  # * calculae weights from len vertex grup
            self.update_vg_mask['length'] = False

        vg_rotation_name = ht_part_sys_props.vg_rotation
        if vg_rotation_name and (not self.wg_rot_factor or self.update_vg_mask['rotation']):
            self.wg_rot_factor = self.calc_wg_scale_factor(vg_rotation_name, invert=ht_part_sys_props.ivg_rotation)  # * calculae weights from len vertex grup
            self.update_vg_mask['rotation'] = False

        vg_clump_name = ht_part_sys_props.vg_clump
        if vg_clump_name and (not self.wg_rot_factor or self.update_vg_mask['clump']):
            self.wg_clump_factor = self.calc_wg_scale_factor(vg_clump_name, invert=ht_part_sys_props.ivg_clump)  # * calculae weights from len vertex grup
            self.update_vg_mask['clump'] = False

        vg_taper_name = ht_part_sys_props.vg_taper
        if vg_taper_name and (not self.wg_rot_factor or self.update_vg_mask['taper']):
            self.wg_taper_factor = self.calc_wg_scale_factor(vg_taper_name, invert=ht_part_sys_props.ivg_taper)  # * calculae weights from len vertex grup
            self.update_vg_mask['taper'] = False

        vg_radius_name = ht_part_sys_props.vg_radius
        if vg_radius_name and (not self.wg_radius_factor or self.update_vg_mask['radius']):
            self.wg_radius_factor = self.calc_wg_scale_factor(vg_radius_name, invert=ht_part_sys_props.ivg_radius)  # * calculae weights from len vertex grup
            self.update_vg_mask['radius'] = False

        childStrandsPoints = []  # will contain strands with child points
        childStrandRootNormals = []
        searchDistance = 10 * self.diag_local
        taper_per_strand = []  # each strand can be masked by taper vgroup
        pts_cnt = ht_part_sys_props.points_count
        clump_factor = 1-clump_profile(1, 1-ht_part_sys_props.clump, ht_part_sys_props.clump_shape,  pts_cnt)
        const_taper = clump_profile(1, 1-ht_part_sys_props.taper_amount, ht_part_sys_props.taper_shape, pts_cnt) # shared for all strands if not affected by vgroup


        def calculate_rad_taper(hit_idx):
            if vg_radius_name and vg_taper_name: # affects overall radius of strand
                strand_rad = self.wg_radius_factor[hit_idx] #  radius multiplier - affected by vgroup
                taper_tip = ht_part_sys_props.taper_amount * self.wg_taper_factor[hit_idx] # taper masked by vgroup
                taper_per_strand.append(strand_rad * clump_profile(1, 1-taper_tip, ht_part_sys_props.taper_shape, pts_cnt))
            elif vg_radius_name: # only radius is changed,
                uniform_rad = self.wg_radius_factor[hit_idx] # constand radius multiplier based on vgroup
                taper_per_strand.append(const_taper * uniform_rad)
            elif vg_taper_name: # only taper is changed,
                taper_tip = ht_part_sys_props.taper_amount * self.wg_taper_factor[hit_idx] # taper masked by vgroup
                taper_per_strand.append( clump_profile(1, 1-taper_tip, ht_part_sys_props.taper_shape, pts_cnt))
            else: # no vgroups that affect radius or taper
                taper_per_strand.append(const_taper)


        for child_id, (childRoot, lenWeight) in enumerate(zip(pointsChildRoots, lenWeights)):  # for each child find it three parents and genereate strands by barycentric transform
            _, normalChildRoot, rootHitIndex, _ = self.source_surf_bvh_w.find_nearest(childRoot, searchDistance)
            childStrandRootNormals.append(normalChildRoot)
            threeClosestParentRoots = kd.find_n(childRoot, 3)  # find three closes parent roots
            rootTri_co, proot_idx, distances = zip(*threeClosestParentRoots)  # split it into 3 arrays
            sourceTri_BVHT = BVHTree.FromPolygons(rootTri_co, [(0, 1, 2)], all_triangles=True)  # [0,1,2] - polygon == vert indices list
            childRootSnapped, normalChildProjected, _, _ = sourceTri_BVHT.find_nearest(childRoot, searchDistance)  # snap generated child to parent triangle ares \normals are sometimes flipped
            childRootSnapped2, normalChildProjected2, _, _ = self.source_surf_bvh_w.find_nearest(childRootSnapped, searchDistance)  # this gives ok normals always

            if vg_len_name:  # scale by vertex_group_length influence
                lenWeight *= self.wg_scale_factor[rootHitIndex]


            # noise.seed_set(self.rot_seed + i)  # add seed per strand/ring ?
            # noiseVectorPerStrand = noise.noise_vector(childInterpolatedPoint / diagonal, noise_basis ='PERLIN_ORIGINAL') * self.randomize_rot * diagonal / 10
            # for childRootSnapped points transform them from parent root triangles to parent next segment triangle t1,t2,t3
            # and compensate child snapping to root triangle from before

            rotQuat = normalChildProjected2.rotation_difference(normalChildRoot)
            translationMatrix = Matrix.Translation(childRoot)
            rotMatrixRot = rotQuat.to_matrix().to_4x4()
            mat_sca = Matrix.Scale(lenWeight, 4)
            transformMatrix = translationMatrix @ rotMatrixRot
            mul_matrix = transformMatrix @ mat_sca
            if ht_part_sys_props.randomize_rot:
                rotWeight = 1
                if vg_rotation_name:  # scale by vertex_group_length influence
                    wg_rotation = self.wg_rot_factor[rootHitIndex]
                    rotWeight = wg_rotation * lenWeight
                quat_rot = zero_quat.slerp(Quaternion(quat_u1_u2_u3_u4[child_id]), ht_part_sys_props.randomize_rot/2*rotWeight)
                mul_matrix = mul_matrix @ quat_rot.to_matrix().to_4x4()

            # NOTE: loop over tris formed over parent[x], parent[y], parent[z] n-th element
            strandPoints = []
            for n, (t1, t2, t3) in enumerate(zip(parent_strands[proot_idx[0]], parent_strands[proot_idx[1]], parent_strands[proot_idx[2]])):
                pointTransformed = barycentric_transform(childRootSnapped, rootTri_co[0], rootTri_co[1], rootTri_co[2], Vector(t1), Vector(t2), Vector(t3))
                childInterpolatedPoint = mul_matrix @ (pointTransformed - childRootSnapped)  # rotate child strand to original pos (from before snapt)

                clump_vg_mask = self.wg_clump_factor[rootHitIndex] if vg_clump_name else 1
                if ht_part_sys_props.clump > 0.01:
                    childInterpolatedPoint = childInterpolatedPoint.lerp(t1, clump_vg_mask*clump_factor[n])
                strandPoints.append(childInterpolatedPoint)
                # kd.find(childRootSnapped)
            childStrandsPoints.append(strandPoints)

            calculate_rad_taper(rootHitIndex)


        if ht_part_sys_props.include_parent_strands:
            childStrandsPoints.extend(parent_strands)
            # if vg_len_name or vg_radius_name:  # scale by vgroup
            for pstrand in parent_strands:
                snappedPoint, normalChildRoot, rootHitIndex, distance = self.source_surf_bvh_w.find_nearest(pstrand[0], searchDistance)
                if vg_len_name:
                    self.scale_strand(pstrand, self.wg_scale_factor[rootHitIndex])
                calculate_rad_taper(rootHitIndex)


        return childStrandsPoints, taper_per_strand

    def read_particle_hair(self, context, partsysMod):
        pointsList_hair = []
        global STRANDS_CO
        # strands_len = len(partsysMod.particles[0].hair_keys) - 1
        for strand in partsysMod.particles:  # for strand point
            pointsList_hair.append([self.obj_eval.matrix_world @ hair_key.co for hair_key in strand.hair_keys])  # not much gain from np: 2 x 0.001sec  only
        STRANDS_CO = pointsList_hair
        return pointsList_hair

    def particle_hair_to_points(self, context):
        partsysMod = self.obj_eval.particle_systems.active  # use last
        particle_id = self.obj_eval.particle_systems.active_index  # use last
        ht_part_sys_props = self.active_obj.ht_props.modal_hair.particle_system_modal_settings[particle_id]

        if ht_part_sys_props.offset_tip or ht_part_sys_props.offset_root:
            offset_tip_tns = calc_pow_inverted(ht_part_sys_props.offset_tip+1, ht_part_sys_props.points_count)
            offset_root_tip_tns = np.power(offset_tip_tns, ht_part_sys_props.offset_root+1)
        else:
            offset_root_tip_tns = None

        splinesPointsList = []
        extendList = self.read_particle_hair(context, partsysMod)
        if len(extendList) > 0:
            splinesPointsList = interpol_Catmull_Rom_splines(extendList, ht_part_sys_props.points_count, uniform_spacing=False, same_point_count=True, tn_fallof=offset_root_tip_tns)

        vg_len_name =  ht_part_sys_props.vg_length
        if vg_len_name:  # * scale size by vgroup
            if not self.wg_scale_factor or self.update_vg_mask['length']:
                self.wg_scale_factor = self.calc_wg_scale_factor(vg_len_name, invert=ht_part_sys_props.ivg_length)  # * calculae weights from len vertex grup
                self.update_vg_mask['length']

        vg_radius_name = ht_part_sys_props.vg_radius
        if vg_radius_name and (not self.wg_radius_factor or self.update_vg_mask['radius']):
            self.wg_radius_factor = self.calc_wg_scale_factor(vg_radius_name, invert=ht_part_sys_props.ivg_radius)  # * calculae weights from len vertex grup
            self.update_vg_mask['radius'] = False

        radius_per_strand = []
        pts_cnt = ht_part_sys_props.points_count
        const_taper = clump_profile(1, 1-ht_part_sys_props.taper_amount, ht_part_sys_props.taper_shape, pts_cnt) # shared for all strands if not affected by vgroup
        if vg_len_name or vg_radius_name:  # scale by vgroup for pstrand in parent_strands:
            for pstrand in splinesPointsList:
                point, normal, rootHitIndex, distance = self.source_surf_bvh_w.find_nearest(pstrand[0], 10 * self.diag_local)
                if vg_len_name:
                    self.scale_strand(pstrand, self.wg_scale_factor[rootHitIndex])
                if vg_radius_name:
                    radius_per_strand.append(self.wg_radius_factor[rootHitIndex]*const_taper)
                else:
                    radius_per_strand.append(const_taper)
        else:
            radius_per_strand = [const_taper] * len(splinesPointsList)
        return splinesPointsList, radius_per_strand

    def hair_ribbon_update(self, context):
        self.depsgraph.update()
        active_obj = context.active_object
        particle_id = self.obj_eval.particle_systems.active_index  # use last
        modal_hair_props = active_obj.ht_props.modal_hair
        curveData = self.target_hair_obj.data
        if active_obj.particle_systems.active.settings.type != 'HAIR' or particle_id >= len(modal_hair_props.particle_system_modal_settings):
            return

        ht_part_sys_props = modal_hair_props.particle_system_modal_settings[particle_id]
        if ht_part_sys_props.particle_settings == 'HAIR_TOOL':
            # NOTE: strands_rad_taper - list of radius taper - scale radius according to vgroup taper and radius
            if ht_part_sys_props.with_children:
                splinesPointsList, strands_rad_taper = self.particle_hair_to_points_with_children(context)
                per_spl_radius = True # no radius masked by vgroup when using blender particle hair...
            else:
                splinesPointsList, strands_rad_taper = self.particle_hair_to_points(context)
                per_spl_radius = True

        else:
            # NOTE: strands_rad_taper - single uniform radus taper for all strands
            splinesPointsList, strands_rad_taper = self.blender_particle_hair(context)
            per_spl_radius = False # no radius masked by vgroup when using blender particle hair...

            if modal_hair_props.drawStrands: # update parent strands co
                partsysMod = self.obj_eval.particle_systems.active
                _ = self.read_particle_hair(context, partsysMod)  # done inside too self.particle_hair_to_points_with_children()


        if splinesPointsList is None or len(splinesPointsList) == 0:
            return
        per_spl_pts_cnt = len(splinesPointsList[0]) # ht_part_sys_props.points_count

        # XXX: remake into np.c_ ?
        splinePointsNpOnes = np.ones((len(splinesPointsList), per_spl_pts_cnt, 4), dtype=np.float32)  # 4 coord x,y,z ,1
        splinePointsNpOnes[:, :, :-1] = splinesPointsList  # fill x,y,z - exept last row (1)- for size
        # n = splinesPointsList[0].shape[0]
        # splinePointsNpOnes = np.c_[ splinesPointsList, np.ones(n) ]


        spline_count = len(curveData.splines)
        # fix strands count
        extra_spl_cnt = spline_count - len(splinePointsNpOnes)
        if extra_spl_cnt > 0:
            for i in reversed(range(extra_spl_cnt)):
                curveData.splines.remove(curveData.splines[-i-1])
        elif extra_spl_cnt < 0:
            for i in range(-extra_spl_cnt):
                polyline = curveData.splines.new(ht_part_sys_props.hairType)
                polyline.points.add(per_spl_pts_cnt - 1)
                if ht_part_sys_props.hairType == 'NURBS':
                    polyline.order_u = 3
                    polyline.resolution_u = self.target_hair_obj.data.resolution_u
                    polyline.use_endpoint_u = True


        def del_extra_pts(points_to_delete):
            for spl in curveData.splines:
                for p in spl.points:
                    p.select = False

            for sp_id, pts_ids in points_to_delete.items():
                spline = curveData.splines[sp_id]
                for p_id in pts_ids:
                    spline.points[p_id].select = True

            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
            backup_active = context.view_layer.objects.active
            context.view_layer.objects.active = self.target_hair_obj
            bpy.ops.object.mode_set(mode='EDIT', toggle=False)
            bpy.ops.curve.select_tips(roots=False)

            bpy.ops.curve.delete(type='VERT')

            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
            context.view_layer.objects.active = backup_active
            bpy.ops.object.mode_set(mode='PARTICLE_EDIT', toggle=False)


        # fix strands point count - add Pts
        del_pts_in_splines = {}
        for spl_id, polyline in enumerate(curveData.splines):
            new_points = per_spl_pts_cnt - len(polyline.points)
            if new_points > 0:  # orig spline has not enough
                polyline.points.add(new_points)
            elif new_points < 0:  # orig spline have too many points
                del_pts_in_splines[spl_id] =  [per_spl_pts_cnt + i for i in range(abs(new_points))]
        if del_pts_in_splines:
            del_extra_pts(del_pts_in_splines)


        if self.target_hair_obj.ht_props.use_auto_uv:
            HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(self.target_hair_obj)

        mat = np.array(self.target_hair_obj.matrix_world.inverted())
        for i, (polyline, splinePoints) in enumerate(zip(curveData.splines, splinePointsNpOnes)):
            splinePoints_world = np.einsum('ij,aj->ai', mat, splinePoints)  # mat times point list
            polyline.points.foreach_set("co", splinePoints_world.ravel())
            if ht_part_sys_props.particle_settings == 'HAIR_TOOL':
                if per_spl_radius:
                    polyline.points.foreach_set("radius", strands_rad_taper[i]) # per_spline_radius - from vgroup mask
                else:
                    polyline.points.foreach_set("radius", strands_rad_taper)
            else: # use blender psys 'Hair Shape'
                polyline.points.foreach_set("radius", strands_rad_taper)

        if self.target_hair_obj.ht_props.link_uv_to_radius:
            HTOOL_OT_CurveRadiusFromUVWidth.radius_from_uv_width(self.target_hair_obj, use_multiplier=True)

        curveData.update_tag()
        backup_active = context.view_layer.objects.active
        context.view_layer.objects.active = self.target_hair_obj
        if ht_part_sys_props.embedValue > 0:
            HTOOL_OT_EmbedRoots.embed_strands_roots(context, self.target_hair_obj, self.source_surf_bvh_w,  embed=ht_part_sys_props.embedValue, onlySelection=False)
        if ht_part_sys_props.smooth_curves > 0:
            bpy.ops.object.curves_smooth(onlySelection=False,  smooth=ht_part_sys_props.smooth_curves)
        if ht_part_sys_props.alignToSurface is True:
            HTOOL_OT_CurvesTiltAlign.align_curve_tilt(context, self.depsgraph, self.target_hair_obj, self.source_surf_bvh_w, resetTilt=True, onlySelection=False)
            if ht_part_sys_props.smoothTiltStrength > 0:
                HTOOL_OT_CurvesTiltSmooth.run_smooth_titl(context, self.target_hair_obj, strength=ht_part_sys_props.smoothTiltStrength, onlySelection=False)
        context.view_layer.objects.active = backup_active

    def finish(self, context):
        context.active_object.ht_props.modal_hair.runModalHair = False
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        bpy.msgbus.clear_by_owner(owner)
        bpy.msgbus.clear_by_owner(owner_bpsys)


    def set_msgbus(self, context):
        ''' update len and rotation vg on property change - in obj particle mod vgroups'''
        particle_id = self.active_obj.particle_systems.active_index  # use last
        ht_part_sys_props = context.active_object.ht_props.modal_hair.particle_system_modal_settings[particle_id]

        vg_names = ('density', 'length', 'rotation', 'radius', 'clump', 'taper')
        for vg_name in vg_names:
            sub_to_vgmask = ht_part_sys_props.path_resolve(f"vg_{vg_name}", False)
            sub_to_ing_vgmask = ht_part_sys_props.path_resolve(f"ivg_{vg_name}", False)

            bpy.msgbus.subscribe_rna( key=sub_to_vgmask, owner=owner, args=(self, vg_name,), notify=update_vg_cache,)
            bpy.msgbus.subscribe_rna( key=sub_to_ing_vgmask, owner=owner, args=(self, vg_name,), notify=update_vg_cache,)

        active_psys = context.active_object.particle_systems.active
        for psys_prop_name in active_psys.settings.bl_rna.properties.keys():
            try:
                psys_key = active_psys.settings.path_resolve(psys_prop_name, False)
                bpy.msgbus.subscribe_rna( key=psys_key, owner=owner_bpsys, args=(self,), notify=generic_update,)
            except Exception as e:
                print(e)


    def modal(self, context, event):
        global IGNORED_OPERATORS_NAMES
        global FORCE_UPDATE
        if event.type in {'ESC'}:
            self.finish(context)
            return {'CANCELLED'}

        elif event.type == 'TIMER':
            global last_operation
            if context.mode != 'PARTICLE':
                self.finish(context)
                return {'CANCELLED'}
            oper = context.active_operator
            if FORCE_UPDATE or (oper and oper != last_operation and oper.bl_idname not in IGNORED_OPERATORS_NAMES):
                if FORCE_UPDATE:
                    FORCE_UPDATE = False
                else:
                    # print(oper.bl_idname)
                    last_operation = oper
                # return {'RUNNING_MODAL'}
                # self.depsgraph.update()
                partsysMod = self.obj_eval.particle_systems.active  # use first
                active = self.obj_eval.particle_systems.active
                psys_modal_settings = context.active_object.ht_props.modal_hair.particle_system_modal_settings
                if active.settings.type == 'HAIR' and self.obj_eval.particle_systems.active_index < len(psys_modal_settings):
                    if partsysMod.name in bpy.data.objects.keys():
                        if partsysMod.name not in context.scene.objects.keys():  # assume it was removed by user
                            bpy.data.objects.remove(bpy.data.objects[partsysMod.name])
                            self.target_hair_obj = self.create_hair(context)
                        else:
                            self.target_hair_obj = bpy.data.objects[partsysMod.name]
                        if self.target_hair_obj.hide_get():
                            self.target_hair_obj.hide_set(False)
                    else:
                        self.target_hair_obj = self.create_hair(context)
                    # print('Updating hair!')

                    self.hair_ribbon_update(context)
        elif event.ctrl and event.type == 'Z' and event.value == 'RELEASE':
            # * to prevent crash on undo (undo removas all self.xx data..) - remake all self.xx data
            self.depsgraph = context.evaluated_depsgraph_get()
            self.obj_eval = context.active_object.evaluated_get(self.depsgraph)
            partsysMod = self.obj_eval.particle_systems.active  # use first
            self.target_hair_obj = bpy.data.objects[partsysMod.name]
            self.hair_ribbon_update(context)

        if not context.active_object.ht_props.modal_hair.runModalHair:
            return {'FINISHED'}
        return {'PASS_THROUGH'}



    def invoke(self, context, event):
        self.active_obj = context.active_object
        self.depsgraph = context.evaluated_depsgraph_get()
        self.obj_eval = context.active_object.evaluated_get(self.depsgraph)

        # diagonal -to normalize some values
        # BBOX is world coords.  convert to local space  by @ scale.inv()  (cos we use local space Surface_BVHT)
        self.diag_local = self.obj_eval.dimensions.length  # /ob.matrix_world.to_scale().length #wrold
        # self.sourceSurface_BVHT = get_obj_mesh_bvht(self.obj_eval, self.depsgraph, applyModifiers=True, world_space=False)  # only for chair with children - calculate in once on init
        self.source_surf_bvh_w = get_obj_mesh_bvht(self.obj_eval, self.depsgraph, applyModifiers=True, world_space=True)  # for tilt aliging and other

        # deal with vgroups
        self.wg_scale_factor = None
        self.wg_rot_factor = None
        self.wg_radius_factor = None
        self.update_vg_mask = {'length':True, 'rotation':True, 'radius':True, 'clump':True, 'taper':True} # density handled separately

        self.set_msgbus(context)

        partsysMod = self.obj_eval.particle_systems.active  # use first
        if partsysMod.settings.type == 'HAIR':
            bpy.ops.particle.select_all(action='SELECT')
            bpy.ops.particle.remove_doubles()  # ! if no cache this fails
            bpy.ops.particle.select_all(action='DESELECT')
            psys_modal_settings = context.active_object.ht_props.modal_hair.particle_system_modal_settings
            if self.obj_eval.particle_systems.active_index < len(psys_modal_settings):
                self.target_hair_obj = self.create_hair(context)

        self._timer = context.window_manager.event_timer_add(0.2, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

def generic_update(self):
    global FORCE_UPDATE
    FORCE_UPDATE = True


def update_vg_cache(self, vg_type):
    generic_update(self)
    if vg_type == 'length':
        self.update_vg_mask['length'] = True
    elif vg_type == 'rotation':
        self.update_vg_mask['rotation'] = True
    elif vg_type == 'clump':
        self.update_vg_mask['clump'] = True
    elif vg_type == 'taper':
        self.update_vg_mask['taper'] = True
    elif vg_type == 'radius':
        #N: no need to update on gv_radius empty, since we deal with it on property update method
        self.update_vg_mask['radius'] = True
        particle_id = bpy.context.active_object.particle_systems.active_index
        ht_part_sys_props = bpy.context.active_object.ht_props.modal_hair.particle_system_modal_settings[particle_id]  # cos using self.active_obj gives random settings...
        FORCE_UPDATE = ht_part_sys_props.vg_radius != ''


class HTOOL_OT_CreateModalSettings(bpy.types.Operator):
    bl_label = "Create Interactive Comb Settings"
    bl_idname = "particles.create_settings"
    bl_description = "Create particle settings for interactive combing.\nWarninge: disable interactive combing or Blender may crash"
    bl_options = {"REGISTER", "UNDO"}

    hair_count: bpy.props.IntProperty(name='Hair Count', description='', default=20, min=5, soft_max=500)
    seed: bpy.props.IntProperty(name='seed', description='', default= 1, min=0, max=100)
    hair_segments: bpy.props.IntProperty(name='Hair Segments', description='', default=5, min=2, soft_max=20)
    hair_len: bpy.props.FloatProperty(name='Hair Length', description='', default=0.2, min=0, soft_max=1)


    def draw(self, context):
        layout = self.layout
        if self.particle_mod_generated:
            layout.prop(self, 'hair_count')
            layout.prop(self, 'hair_segments')
            layout.prop(self, 'hair_len')
            layout.prop(self, 'seed')

    def invoke(self, context, event):
        self.particle_mod_generated = False
        self.hair_len = context.active_object.dimensions.length/10
        return self.execute(context)

    def update_psys(self, context):
        psys_mod = context.active_object.modifiers[-1]
        # np.random.seed(len(context.active_object.modifiers))
        # seed = np.random.randint(999)
        psys_mod.particle_system.settings.type = 'HAIR'
        # bpy.ops.object.particle_system_add()
        psys_mod.particle_system.settings.count = self.hair_count
        psys_mod.particle_system.settings.hair_length = self.hair_len
        psys_mod.particle_system.settings.hair_step = self.hair_segments
        psys_mod.particle_system.seed = self.seed

        modal_hair_settings = context.active_object.ht_props.modal_hair
        modal_hair_settings.particle_system_modal_settings.add()
        bpy.ops.object.mode_set(mode='PARTICLE_EDIT')
        # bpy.ops.particle.select_all(action='SELECT')
        # context.active_object.particle_systems.active_index = part_settings_count

    def execute(self, context):
        if self.particle_mod_generated:
            self.update_psys(context)
            return {'FINISHED'}

        modal_hair_settings = context.active_object.ht_props.modal_hair
        # particle_acitve_idx = context.active_object.particle_systems.active_index
        particles_mod_cnt = len(context.active_object.particle_systems)
        part_settings_count = len(modal_hair_settings.particle_system_modal_settings)
        diff = part_settings_count -  particles_mod_cnt
        if diff < 0:  # idx is bigger that settings count, so add settings
            for _ in range(-diff):
                modal_hair_settings.particle_system_modal_settings.add()
        elif diff > 0:
            for _ in range(diff):
                modal_hair_settings.particle_system_modal_settings.remove(len(modal_hair_settings.particle_system_modal_settings)-1)
        else: # diff == 0 -> just add new particle_system_modal_settings and particle system
            if not self.particle_mod_generated:

                context.active_object.modifiers.new(name='Particle System', type='PARTICLE_SYSTEM')
                self.particle_mod_generated = True
                # context.active_object.data.update()
                # depsgraph = context.evaluated_depsgraph_get()
                # depsgraph.update()
                bpy.ops.ed.undo_push()
                self.update_psys(context)

        return {"FINISHED"}


class HTOOL_OT_DeleteModalSettings(bpy.types.Operator):
    bl_label = "Delete Interactive Comb Settings"
    bl_idname = "particles.delete_settings"
    bl_description = "Delete particle settings for interactive combing"
    bl_options = {"REGISTER", "UNDO"}

    # index: bpy.props.IntProperty(name='index', description='', default= 1, min=0)

    def execute(self, context):
        index = context.active_object.particle_systems.active_index
        bpy.ops.object.particle_system_remove()
        context.active_object.ht_props.modal_hair.particle_system_modal_settings.remove(index)
        context.active_object.ht_props.modal_hair.runModalHair
        return {"FINISHED"}

def save_settings(from_props, target_props):  # from grid_hair_settings
    # what exception could occur here??
    for d in from_props.bl_rna.properties.keys():
        if d in {'name', 'rna_type'}:
            continue
        if hasattr(target_props, d):
            # setattr(target_props, d, getattr(from_props, d))
            target_props[d] = getattr(from_props, d)  # to avoid runing prop update...
    return {"FINISHED"}

class HTOOL_OT_CopyModalSettings(bpy.types.Operator):
    bl_label = "Copy Interactive Comb Settings"
    bl_idname = "particles.copy_comb_settings"
    bl_description = "Copy particle settings for interactive combing"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        copy_buffer = context.scene.ht_props.copy_modal_hair
        index = context.active_object.particle_systems.active_index
        sel_settings = context.active_object.ht_props.modal_hair.particle_system_modal_settings[index]
        save_settings(sel_settings, copy_buffer)
        return {"FINISHED"}


class HTOOL_OT_PasteModalSettings(bpy.types.Operator):
    bl_label = "Paste Interactive Comb Settings"
    bl_idname = "particles.paste_comb_settings"
    bl_description = "Paste particle settings for interactive combing"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        copy_buffer = context.scene.ht_props.copy_modal_hair
        index = context.active_object.particle_systems.active_index
        sel_settings = context.active_object.ht_props.modal_hair.particle_system_modal_settings[index]
        save_settings(copy_buffer, sel_settings)
        return {"FINISHED"}

