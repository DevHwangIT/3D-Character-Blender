# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from ..utils.general_utils import assign_material, get_seam_edges
from os import path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from math import sqrt
import bmesh
from ..update_addon import get_addon_preferences
from mathutils import Vector
from .hair_geometry_nodes import get_hair_mod_list

import numpy as np
import bgl
import gpu
from gpu_extras.batch import batch_for_shader

is_rgb = {"AO": False, "DIFFUSE": True, "OPACITY": False, "NORMAL": True, "ROOT": False, "ID": False, "FLOW": True, "DIRECTIONAL": True, "DEPTH": False, "COLOR":True}

neutralBG_color = {
    "NORMAL": np.array([0.5, 0.5, 1.0]),
    "FLOW": np.array([0.5, 0.5, 0.0]),
    # "DIRECTIONAL": np.array([0.5, 1.0, 0.5]), #gives crappy green color - hard to remove
    "OPACITY": np.array([0.0, 0.0, 0.0])
    }

data_types = ['materials', 'node_groups']  # , 'textures' from gpro


def get_bake_file_path():
    if bpy.app.version < (3, 0):
        return path.dirname(__file__)+"\hair_bake.blend"
    else:
        return path.dirname(__file__)+"\hair_bake_3.0.blend"


def import_pass_mat(mat_pass_name):
    mat_sub_group = {'DIRECTIONAL': {'DIR_REMAP'}, 'ROOT': {'ROOT_REMAP'}, 'FLOW': {'FLOW_REMAP', 'Tangent'}} #node_groups that each pass mat is using
    original_datas = {}
    for attr in data_types:
        original_datas[attr] = {data_id.name: data_id for data_id in getattr(bpy.data, attr)}

    imported_datas_names = {}
    imported_datas_names['node_groups'] = []
    #* looks like bleder automatically imports material sub node-groups - and updates them too on reimport
    with bpy.data.libraries.load(get_bake_file_path()) as (data_from, data_to):  # __file__ path from were program was executed
        mats_to_import = [name for name in data_from.materials if name.startswith(mat_pass_name)]  # eg 'DIR' or 'DIR_CURVE'
        imported_datas_names['materials'] = mats_to_import[:]  #copy cos they change line below
        if len(mats_to_import) == 0:
            print(f'Failed to import {mat_pass_name} material from library.')
        else:
            data_to.materials = mats_to_import

    for attr, orig_data in original_datas.items():
        new_data_ids = getattr(data_to, attr)  # eg: data_to.collections
        data = getattr(bpy.data, attr)  # eg. bpy.data.collections
        for orig_name, old_data in orig_data.items():  # eg. for collections, objs, textures etc.
            if orig_name in imported_datas_names[attr]:
                new_data = new_data_ids[imported_datas_names[attr].index(orig_name)] #get imported ids by index, cos names may differ (eg += .001)
                print(f'remapping: {orig_name}:{new_data.name}')
                old_data.user_remap(new_data)
                new_data.name = orig_name
                data.remove(old_data)


class HTOOL_OT_ReimportMat(bpy.types.Operator):
    bl_label = "Update Material(s)"
    bl_idname = "material.update_pass_material"
    bl_description = "Update selected passes material from Hair Tool baking scene. Usefull to get new material version if it was updated in main baking scene"

    def execute(self, context):
        bake_settings = context.scene.ht_props.hair_bake_settings
        sel_passes = list(bake_settings.render_passes)
        for pass_name in sel_passes:
            import_pass_mat(pass_name)
        return {'FINISHED'}


def setup_pass(context, pass_name):
    ''' set pass material to hair objects and scene background'''
    bake_settings = context.scene.ht_props.hair_bake_settings
    render_objs = [obj for obj in bpy.data.objects if obj.type in {"MESH", "CURVE"}]
    if not bpy.data.materials.get(pass_name):
        import_pass_mat(pass_name)
    for obj in render_objs:
        hair_mods = get_hair_mod_list(obj)
        if hair_mods:
            mat = bpy.data.materials.get(pass_name)
            for hmod in hair_mods:
                hmod['Input_13'] = mat
            obj.update_tag()

        assign_material(obj, pass_name)
        if obj.particle_systems.keys():
            obj.show_instancer_for_render = False
            obj.show_instancer_for_viewport = False

        context.scene.render.film_transparent = bake_settings.preview_background == 'TRANSPARENT'

        def create_world_nodes():
            rgb_background_color_node = context.scene.world.node_tree.nodes.get("RGB")
            if not rgb_background_color_node:
                rgb_background_color_node = context.scene.world.node_tree.nodes.new("ShaderNodeRGB")
                world_out_node = context.scene.world.node_tree.nodes.get("World Output")
                if not world_out_node:
                    world_out_node = context.scene.world.node_tree.nodes.new("ShaderNodeOutputWorld")
                context.scene.world.node_tree.links.new(rgb_background_color_node.outputs[0], world_out_node.inputs[0])
            return rgb_background_color_node

        rgb_background_color_node = create_world_nodes()
        if pass_name in neutralBG_color:
            rgb_background_color_node.outputs[0].default_value = np.power(neutralBG_color[pass_name], 2.2).tolist()+[1]
        else:
            additional_color ={
                "AO": [1.0, 1.0, 1.0, 1.0],
                "ID": [0.26, 0.26, 0.26, 1],
                "COLOR": [0.26, 0.26, 0.26, 1]
            }
            if pass_name in additional_color:
                rgb_background_color_node.outputs[0].default_value = additional_color[pass_name]
            else:
                rgb_background_color_node.outputs[0].default_value = (0, 0, 0, 1)

vertex_shader = '''
    in vec2 position;
    in vec2 uv;

    out vec2 uvInterp;

    void main()
    {
        uvInterp = uv;
        gl_Position = vec4(position, 0.0, 1.0);
    }
'''

fragment_shader = '''
    uniform sampler2D image;
    uniform vec2 img_size;
    uniform int radius;
    uniform vec3 bg_color;
    uniform bool solid_bg;

    in vec2 uvInterp;

    out vec4 FragColor;

    vec4 blend_premultiplied(vec4 imgA, vec4 imgB){
      vec4 out_img = vec4(imgA.rgb * imgA.a, imgA.a) + (1.-imgA.a)*vec4(imgB.rgb * imgB.a, imgB.a); //* pretultiplied ver
      out_img.rgb = out_img.rgb / out_img.a;
      return out_img;
    }

    // vec2[] offset = vec2[](vec2(-1,0), vec2(1,0), vec2(0,1), vec2(0,-1), vec2(1,1), vec2(-1,1), vec2(1,-1), vec2(-1,-1));

    void main() {
        vec2 uv = uvInterp;
        vec4 img = texture(image, uv);
        vec4 out_img = vec4(0,0,0,0);

        if (img.a > 0.9){
            out_img = img;
        }else{
            float sample_weight = 0.;
            for (int r=1; r<=radius; r++){ //sample circle - with sample count ~ rad
              float sample_cnt = 9.*pow(float(r), .6);
              for(int i = 0; i < int(sample_cnt); i++){
                float alpha = 6.28 * float(i) /sample_cnt;
                vec2 uv_offset = uv + vec2(cos(alpha), sin(alpha))/img_size*float(r);
                if (uv_offset.x<0. || uv_offset.x>1. || uv_offset.y<0. || uv_offset.y>1.) // skip borders
                    break;
                vec4 img_sample = texture(image, uv_offset);
                out_img += img_sample*img_sample.a;
                sample_weight += img_sample.a;
              }
              if (sample_weight > 0.3*sample_cnt) // skip outer rad if got enough samples
                  break;
            }
            if (sample_weight > 0.)
                out_img = out_img/float(sample_weight);

            out_img.a = step(0.1, out_img.a);
            out_img.rgb = mix(bg_color, out_img.rgb, out_img.a); // use original background in black places
            out_img.rgb = mix(out_img.rgb, img.rgb, img.a); // overlay original image for using alpha
            if (solid_bg)
                out_img.a = 1.;
        }
        FragColor = vec4(pow(out_img.rgb, vec3(0.4545)), out_img.a);

}
'''

#shader = gpu.shader.from_builtin('2D_IMAGE')
shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
batch = batch_for_shader(
    shader, 'TRI_FAN',
    {
        "position": [ [-1,-1], [1,-1], [1,1], [-1,1] ],
#        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
        "uv": [ [0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0] ],
    },
)

def ht_channel_mixing(context):
    ''' Create compositing node tree and load baked imgs'''
    bake_settings = context.scene.ht_props.hair_bake_settings
    if bake_settings.output_format == 'PNG':
        ext = 'png'
    elif bake_settings.output_format == 'TARGA':
        ext = 'tga'
    else:
        ext = 'jpg'

    if 'ChannelMixing' not in bpy.data.node_groups.keys():
        bpy.ops.node.new_node_tree(type='TextureChannelMixing', name='ChannelMixing')
    node_tree = bpy.data.node_groups['ChannelMixing']
    addon_prefs = get_addon_preferences()
    for i, pass_name in enumerate(list(bake_settings.render_passes)):
        suffix = getattr(addon_prefs, pass_name.lower()+'_suffix', '')
        img_pass_name = bake_settings.hair_bake_file_name + suffix + "." + ext
        impPath = bpy.path.abspath(bake_settings.hair_bake_path + img_pass_name)
        if path.isfile(impPath):
            if img_pass_name in bpy.data.images.keys():
                img = bpy.data.images[img_pass_name]
                # img.reload()
            else:
                img = bpy.data.images.load(filepath=impPath)
            img_node = None
            for node in node_tree.nodes:
                if node.bl_idname == 'TextureMixInputTexture' and node.img.name == img_pass_name:
                    img_node = node
            if img_node is None:
                img_node = node_tree.nodes.new('TextureMixInputTexture')
                img_node.img = img  # also refreshes img...
                img_node.location[1] = i * 200
                img_node.width = 220

            # bpy.data.images.remove(img)
    # outputImg.filepath_raw = bpy.path.abspath(bake_settings.hair_bake_path + "Hair_compo." + ext)


def coll_recursive_sync_hide_rend(layer_col):
    ''' we can get eye hide icon only form view_layer coll '''
    for lay_sub_c in layer_col.children:
        lay_sub_c.collection.hide_render = lay_sub_c.hide_viewport
        coll_recursive_sync_hide_rend(lay_sub_c)

class HTOOL_OT_BakeHair(bpy.types.Operator):
    bl_idname = "object.bake_hair"
    bl_label = "Bake Hair"
    bl_description = "Bake Hair"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def run_padding(context, pass_name):
        bake_settings = context.scene.ht_props.hair_bake_settings
        if bake_settings.output_format == 'PNG':
            ext = 'png'
        elif bake_settings.output_format == 'TARGA':
            ext = 'tga'
        else:
            ext = 'jpg'

        addon_prefs = get_addon_preferences()
        padding_size = bake_settings.padding_size if bake_settings.padding_mode == 'FIXED' else int(int(bake_settings.bakeResolution_x)/64)

        suffix = getattr(addon_prefs, pass_name.lower()+'_suffix', '')
        img_pass_name = bake_settings.hair_bake_file_name + suffix + "." + ext
        impPath = bpy.path.abspath(bake_settings.hair_bake_path + img_pass_name)
        if path.isfile(impPath): #load bake from disk
            img = bpy.data.images[img_pass_name] if img_pass_name in bpy.data.images.keys() else bpy.data.images.load(filepath=impPath)
            img.reload() #relaod done in baking

        img_x, img_y = int(img.size[0]), int(img.size[1])
        if pass_name != 'OPACITY':
            if padding_size:
                if pass_name in neutralBG_color:
                    avg_col = neutralBG_color[pass_name]
                else:
                    pixels = np.array(img.pixels, dtype='f').reshape(img_x, img_y, 4)  # RGBA
                    valid_pixels = pixels[:, :, 3] > 0.3
                    avg_col = np.average(pixels[valid_pixels][:, :-1], axis=0)   # through x_row and y_cols

                #Load the image into an OpenGL texture. On success, image.bindcode will contain the OpenGL texture bindcode.
                #Colors read from the texture will be in scene linear color space and have premultiplied or straight alpha matching the image alpha mode
                # img.colorspace_settings.name = 'Linear' #or 'sRGB'
                if img.gl_load():
                    raise Exception()

                offscreen = gpu.types.GPUOffScreen(img_x, img_y)
                out_buffer = bgl.Buffer(bgl.GL_BYTE, img_x * img_y * 4)
                with offscreen.bind():
                    bgl.glActiveTexture(bgl.GL_TEXTURE0)
                    if True:
                        bgl.glBindTexture(bgl.GL_TEXTURE_2D, img.bindcode)
                    else:  # eg do second pass on previous output, in loop
                        #offscreen.color_texture  -  output offscreen buffer as image bytes...
                        bgl.glBindTexture(bgl.GL_TEXTURE_2D, offscreen.color_texture)  # load prev result back to GPUOffScreen

                    shader.bind()
                    shader.uniform_float("img_size", [img_x, img_y])
                    shader.uniform_int("radius", padding_size)
                    shader.uniform_int("image", 0)  # ? - loads GL_TEXTURE0 ??
                    # bg_color = shader.uniform_from_name("bg_color")
                    # shader.uniform_vector_float(bg_color, pack("2f", avg_col), 3)
                    shader.uniform_float("bg_color", np.power(avg_col, 2.2))
                    shader.uniform_bool("solid_bg", [bake_settings.preview_background != 'TRANSPARENT'])
                    batch.draw(shader)

                    #Write screen to out_buffer
                    bgl.glReadBuffer(bgl.GL_BACK)
                    bgl.glReadPixels(0, 0, img_x, img_y, bgl.GL_RGBA, bgl.GL_UNSIGNED_BYTE, out_buffer)
                offscreen.free()
                # img.gl_free()
                img.pixels = np.array(out_buffer).ravel()/255
                # img.pixels = np.power(np.array(out_buffer)/255, 0.454).ravel().tolist()

            else:
                pixels = np.array(img.pixels, dtype='f').reshape(img_x, img_y, 4)  # RGBA
                if pass_name in neutralBG_color:
                    avg_col = neutralBG_color[pass_name]
                else:
                    valid_pixels = pixels[:, :, 3] > 0.3
                    avg_col = np.average(pixels[valid_pixels][:, :-1], axis=0)   # through x_row and y_cols

                # float_mask = pixels[:, :, 3] > 0.001
                pixels[:, :, :-1] = pixels[:, :, :-1]*pixels[:, :, -1][:, :, None] + (1-pixels[:, :, -1])[:, :, None]*avg_col
                if bake_settings.preview_background != 'TRANSPARENT': #by default we always bake with transparency
                    pixels[:, :, -1] = 1
                img.pixels = pixels.ravel().tolist()  # faster with .ravel().tolist() ?

            img.save()

        elif pass_name == 'OPACITY':  # add alpha to opacity
            pixels = np.array(img.pixels, dtype=np.float16).reshape(img_x, img_y, 4)  # RGBA
            pixels[:, :, -1] = pixels[:, :, 0] #add alpha
            img.pixels = pixels.ravel().tolist()
            img.save()

        return {"FINISHED"}


    @staticmethod
    def unify_render_preview_settings(context, addon_prefs):
        if addon_prefs.view_render_object_sync:
            for obj in bpy.context.scene.objects:
                obj.hide_render = obj.hide_get()
            coll_recursive_sync_hide_rend(context.view_layer.layer_collection)
        if addon_prefs.view_render_phair_sync:
            particle_objs = [obj for obj in bpy.data.objects if obj.type == 'MESH' and len(obj.particle_systems)]
            for particle_obj in particle_objs:
                for particle_system in particle_obj.particle_systems:
                    particle_system.settings.rendered_child_count = particle_system.settings.child_nbr
                    particle_system.settings.render_step = particle_system.settings.display_step #power of 2
                    # particle_system.settings.display_step = 3

    def execute(self, context):
        bake_settings = context.scene.ht_props.hair_bake_settings
        if not bake_settings.hair_bake_path:
            self.report({'ERROR'}, f'Set baking path first. Cancelling')
            return {'CANCELLED'}
        addon_prefs = get_addon_preferences()

        render = context.scene.render
        render.image_settings.file_format = bake_settings.output_format
        render_path = bake_settings.hair_bake_path
        render_file_name = bake_settings.hair_bake_file_name
        render_quality = bake_settings.render_quality
        # render_size =
        render.resolution_x = int(bake_settings.bakeResolution_x)
        render.resolution_y = int(bake_settings.bakeResolution_y)
        render.resolution_percentage = 100
        render.image_settings.file_format = bake_settings.output_format
        back_film_transparent = render.film_transparent

        self.unify_render_preview_settings(context, addon_prefs)
        sel_passes = list(bake_settings.render_passes)
        import time

        start_time = time.time()
        padding_size = bake_settings.padding_size if bake_settings.padding_mode == 'FIXED' else int(int(bake_settings.bakeResolution_x)/64)

        for pass_name in sel_passes:
            setup_pass(context, pass_name)
            render.film_transparent = True if pass_name != 'OPACITY' else False #only solid for opacity map
            render.use_file_extension = True
            render.image_settings.color_depth = '8'
            context.scene.cycles.samples = 128*int(render_quality) if pass_name == "AO" else 16*int(render_quality)
            suffix = getattr(addon_prefs, pass_name.lower()+'_suffix', '')
            file_name = render_file_name + suffix
            render.filepath = render_path + file_name
            bpy.ops.render.render(write_still=True)  # we cant acess render reuslt
            full_file_name = file_name + '.' + render.image_settings.file_format.lower()
            if full_file_name in bpy.data.images.keys():
                bpy.data.images[full_file_name].reload()
                bpy.data.images[full_file_name].update()
            self.run_padding(context, pass_name)
        print(f'Total baking took --- {time.time() - start_time} seconds ---')

        # start_time = time.time()
        # print(f'Padding images took --- {time.time() - start_time} seconds ---')

        if bake_settings.hair_bake_composite: #use scene compositor not
            ht_channel_mixing(context)
        render.film_transparent = back_film_transparent
        return {"FINISHED"}


class HTOOL_OT_UVShapekey(bpy.types.Operator):
    bl_label = "Flatten to UV Shape key"
    bl_idname = "object.uv_to_shapekey_hair"
    bl_description = "Use objects UV to create flat Shape Key.\nThis operator will scale particle hair size to maintain strand length to scalp size ratio!\nTo un-flatten object run this operator again"

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH' and len(context.active_object.data.uv_layers) > 0

    @staticmethod
    def create_flat_shape(bm):
        shape_lay = bm.verts.layers.shape.get("uv_flat")
        if not shape_lay:
            shape_lay = bm.verts.layers.shape.new("uv_flat")

        seam_edges = get_seam_edges(bm)
        if seam_edges:
            bmesh.ops.split_edges(bm, edges=seam_edges)
        uv_layer = bm.loops.layers.uv.active
        bm.verts.ensure_lookup_table()
        loose_verts = []
        for vert in bm.verts:
            if vert.link_loops:
                co = vert.link_loops[0][uv_layer].uv
                vert[shape_lay] = Vector((co[0], co[1], 0))
            else:
                loose_verts.append(vert)
        for v in reversed(loose_verts):
            bm.verts.remove(v)

    def execute(self, context):
        obj = context.active_object
        back_deflect = context.scene.tool_settings.particle_edit.use_emitter_deflect #prevent hair stranigten on scaled objs....
        context.scene.tool_settings.particle_edit.use_emitter_deflect = False
        if not obj.data.uv_layers:  # create new one
            self.report({'ERROR'}, 'Object does not have UVs! Cancelling')
            return {"CANCELLED"}
        if not obj.data.shape_keys:
            obj.shape_key_add(name="Basis")
        bm = bmesh.new()
        bm.from_mesh(obj.data)

        if not bm.verts.layers.shape:
            bm.verts.layers.shape.new("Basis")
        # check if we are flattening the mesh to UV
        make_flat = False

        shapeKey = obj.data.shape_keys.key_blocks.get("uv_flat")
        if shapeKey:
            if shapeKey.value == 1:
                shapeKey.value = 0
            else:  # update existing flat shape
                self.create_flat_shape(bm)
                bm.to_mesh(obj.data)
                shapeKey.value = 1
                make_flat = True
        else:
            self.create_flat_shape(bm)
            bm.to_mesh(obj.data)
            make_flat = True

        if obj.particle_systems is None:  # create new one
            self.report({'WARNING'}, 'No active Particle Hair System found!')
            bm.free()
            return {"FINISHED"}

        if make_flat:  # use non flat bmesh?
            original_bvh = BVHTree.FromBMesh(bm)

        orig_face_areas = [f.calc_area() for f in bm.faces]

        # copy flat shape to temp bm
        shape_lay = bm.verts.layers.shape.get("uv_flat")
        for vert in bm.verts:
            vert.co = vert[shape_lay]

        if not make_flat:  # use non flat bm
            original_bvh = BVHTree.FromBMesh(bm)

        # and calculate scale factor from it
        flattened_face_areas = [f.calc_area() for f in bm.faces]
        total_scale_ratio = sqrt(sum(flattened_face_areas)/sum(orig_face_areas))
        if not make_flat:
            total_scale_ratio = 1/total_scale_ratio

        bm.free()
        shapeKey = obj.data.shape_keys.key_blocks["uv_flat"]
        shapeKey.value = make_flat

        print(f'final scale: {total_scale_ratio}')

        old_mode = context.mode
        back_active = None
        if obj.particle_systems[:]:
            back_active = obj.particle_systems.active_index

            for sys_id, particle_system in enumerate(obj.particle_systems):
                if context.mode == 'PARTICLE':  # exit particle edit mode
                    bpy.ops.particle.particle_edit_toggle()
                obj.particle_systems.active_index = sys_id
                psys_settings = particle_system.settings

                psys_settings.radius_scale *= total_scale_ratio
                psys_settings.clump_noise_size *= total_scale_ratio
                psys_settings.child_radius *= total_scale_ratio
                psys_settings.roughness_1 *= total_scale_ratio
                # psys_settings.roughness_1_size *= total_scale_ratio
                psys_settings.roughness_2 *= total_scale_ratio

                # psys_settings.roughness_endpoint *= total_scale_ratio
                # psys_settings.roughness_end_shape *= total_scale_ratio
                psys_settings.roughness_end_shape *= total_scale_ratio
                # psys_settings.roughness_2_size *= total_scale_ratio
                psys_settings.kink_amplitude *= total_scale_ratio
                psys_settings.kink_amplitude *= total_scale_ratio

                depsgraph = context.evaluated_depsgraph_get()
                obj_eval = obj.evaluated_get(depsgraph)
                psys_eval = obj_eval.particle_systems[sys_id]
                if psys_eval.settings.type != 'HAIR':
                    self.report({'INFO'}, f'{particle_system.name} Particle System is not Hair type! Skipping')
                    continue

                if len(psys_eval.particles) == 0:  # require more that three strands
                    self.report({'INFO'}, f'{particle_system.name} Particle System has zero strands! Skipping')
                    continue

                # find root strand face areas from bvh tree
                pointsList_hair = []

                faces_ids = []
                scale_fac = []
                for particle in psys_eval.particles:  # for strand point
                    loc, nrm, f_id, dist = original_bvh.find_nearest(particle.hair_keys[0].co)
                    faces_ids.append(f_id)
                    first_co = particle.hair_keys[0].co
                    face_scale_factor = sqrt(flattened_face_areas[f_id]/orig_face_areas[f_id]) if make_flat else sqrt(orig_face_areas[f_id]/flattened_face_areas[f_id])
                    scale_fac.append(face_scale_factor)
                    pointsList_hair.append([first_co+(hair_key.co-first_co)*total_scale_ratio for hair_key in particle.hair_keys])

                # print(f'face_scale_factor: {scale_fac} ')
                # print(f'face_scale_factorinv:  {[1/x for x in scale_fac]}')
                # write hair_keys.co
                depsgraph = context.evaluated_depsgraph_get()
                particleObj_eval = obj.evaluated_get(depsgraph)

                particle_sys_eval = particleObj_eval.particle_systems[sys_id]
                for i, points in enumerate(pointsList_hair):  # for strand point
                    # particle_sys_eval.particles[i].location = points[0]
                    for j, point in enumerate(points):  # for strand point
                        particle_sys_eval.particles[i].hair_keys[j].co = Vector(point)

                # to update hair co's
                bpy.ops.particle.particle_edit_toggle()
        if old_mode != obj.mode:  # to object mode,  if we were not in 'Comb mode'
            bpy.ops.particle.particle_edit_toggle()
        if back_active:
            obj.particle_systems.active_index = back_active
        context.scene.tool_settings.particle_edit.use_emitter_deflect = back_deflect
        return {"FINISHED"}



class HTOOL_OT_ReloadBakingFile(bpy.types.Operator):
    bl_idname = "object.reload_hair_baking"
    bl_label = "Reload Baking scene"
    bl_description = "Restores current bakings scene to the default HTool baking scene. Can be undone"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.label(text='Are you sure you want to reload Hair Baking scene?')
        self.layout.label(text='Content of current file will be overriden')

    def execute(self, context):
        import_bake_scene(None)
        # TODO: make sure it is no appended as linked data
        return {"FINISHED"}


class HTOOL_OT_OpenHairFile(bpy.types.Operator):
    bl_idname = "object.open_hair_bake"
    bl_label = "Open Baking scene"
    bl_description = "Open Baking scene. Save current file before executing this operator"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.label(text='Are you sure you want to open Hair Baking scene?')
        self.layout.label(text='Current file will be closed without saving')

    def execute(self, context):
        bpy.app.handlers.load_post.append(import_bake_scene)
        bpy.ops.wm.read_homefile(app_template="")
        # bpy.ops.wm.open_mainfile(filepath=path.dirname(__file__)+"/hair_bake.blend") # opens baking scene from HTool. But we do not want to override it
        return {"FINISHED"}


from bpy.app.handlers import persistent

@persistent
def import_bake_scene(dummy):
    old_scene = bpy.context.scene
    tmp = bpy.data.scenes.new('tmp')
    bpy.context.window.scene = tmp
    bpy.data.scenes.remove(old_scene, do_unlink=True)
    bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)

    #* looks like bleder automatically imports linked data
    print('Loading hair baking scene')
    try:
        with bpy.data.libraries.load(get_bake_file_path()) as (data_from, data_to):  # __file__ path from were program was executed
            data_to.scenes = ["BakingHair"]
            data_to.workspaces = ["Modeling"]
            data_to.materials = list(is_rgb.keys())

        # current_scene.user_remap(data_to.scenes['BakingHair'])
        bpy.context.window.scene = data_to.scenes[0]
        bpy.data.scenes.remove(tmp)
        for mat in bpy.data.materials:
            mat.use_fake_user = True
        bpy.context.window.workspace = data_to.workspaces[0]
        # manually hide Debug collection. Even though 'Old Method' collection is hidden correctly
        bpy.context.view_layer.layer_collection.children['HT_Helpers'].children['Debug'].hide_viewport = True
        # bpy.ops.object.mode_set(mode='OBJECT')
        try:
            bpy.data.libraries.remove(bpy.data.libraries['hair_bake.blend'])
        except Exception as e:
            print(e)
        try:
            bpy.data.libraries.remove(bpy.data.libraries['hair_bake_3.0.blend'])
        except Exception as e:
            print(e)
        print('Loaded ok')
        if import_bake_scene in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(import_bake_scene)
    except Exception as e:
        print(e)
        print('Failed to import baking scene')
        if import_bake_scene in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(import_bake_scene)
