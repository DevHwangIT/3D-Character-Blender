from nodeitems_utils import NodeCategory, NodeItem
import nodeitems_utils
import bpy
from bpy.types import NodeTree, Node, NodeSocket
import numpy as np
import math
from .hair_tree_update import ht_node_tree_update
from bpy.app.handlers import persistent
import logging
import sys
logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

# TODO: undo breaks cache.... maybe change hash(node) to hash(node.blname ...)
DATA_CACHE = {} #store computed node np data in here
NODES_IN_STATES = {} #mostly for detecting if any node.inputs = was unlinked
#Run it from root to leaves in order...
EXECUTE_QUEUE = []

@persistent
def restart_nodes(dummy):
    logging.debug(f' restart_nodes() handler')
    textureNodeTrees = [node_tree for node_tree in bpy.data.node_groups if node_tree.bl_idname == MyCustomTree.bl_idname]
    for node_tree in textureNodeTrees:
        global EXECUTE_QUEUE
        EXECUTE_QUEUE.clear()
        restart_node_tree(node_tree)


# Derived from the NodeTree base type, similar to Menu, Operator, Panel, etc.
class MyCustomTree(NodeTree):
    # Description string
    '''A custom node tree type that will show up in the node editor header'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TextureChannelMixing'
    # Label for nice name display
    bl_label = "Texture Channel Mixing"
    # Icon identifier
    bl_icon = 'NODETREE'

    def update(self):
        # seems to be called on link insert or removal. So good for detecting link removes - since there is no other way
        logging.debug(f'[MyCustomTree-{self.name}]: Update()')
        # ht_node_tree_update(self)

        input_link_removed = False
        changed_node = None
        def check_input_link_removed():
            for node in self.nodes:
                if node.name not in NODES_IN_STATES[self.name]: #init at exit
                    continue
                if len(NODES_IN_STATES[self.name][node.name]) != len(node.inputs):  # init at exit
                    continue
                for i, input_socket in enumerate(node.inputs):
                    if NODES_IN_STATES[self.name][node.name][i] != input_socket.is_linked and NODES_IN_STATES[self.name][node.name][i]:  # if change, and was connected previously
                        logging.debug(f'[MyCustomTree-{node.name}] - link removed changed')
                        build_and_run_nodes_update(node)
                        return
        if not NODES_IN_STATES: #when runing for first time blend file
            reset_link_states(self) # init it
            return
        check_input_link_removed()
        reset_link_states(self) #since nodeTree.update() it is called on link add or remove.



#* SOCKETS  ########################################################################################################
# Custom socket type
class BaseSocket():
    '''Common methods for child sockets classes'''

    @staticmethod
    def get_other_socket(socket):
        """
        get socket from another site of link conected to this socket
        """
        if not socket.is_linked:
            return None

        if socket.is_output:
            other = socket.links[0].to_socket
        else:
            other = socket.links[0].from_socket

        if other.node.bl_idname == 'NodeReroute':
            if not socket.is_output:
                return socket.get_other_socket(other.node.inputs[0])
            else:
                return socket.get_other_socket(other.node.outputs[0])
        else:
            return other

    @staticmethod
    def get_socket_hash(socket):
        """Id of socket used for  DATA_CACHE"""
        return hash(socket.id_data.name + socket.node.name + socket.identifier)

    def cache_set(self, data):
        """sets socket data for socket"""
        global DATA_CACHE
        s_id = self.get_socket_hash(self)
        socket_nodeGr = self.id_data.name
        if socket_nodeGr not in DATA_CACHE:
            DATA_CACHE[socket_nodeGr] = {}
        DATA_CACHE[socket_nodeGr][s_id] = data

    def get_cache(self, deepcopy=True):
        if self.is_linked and not self.is_output:  # check inputs for its cache
            linked_socket = self.get_other_socket(self)  # find socket other end of link
            s_id = self.get_socket_hash(linked_socket)  # hast(linkde_socked) - gives bad result on undo
            socket_nodeGr = linked_socket.id_data.name
            if socket_nodeGr not in DATA_CACHE:
                logging.debug('No cache found for node tree %s ' % (socket_nodeGr))
                restart_nodes(self)
                # maybe we should build one...
                # ht_node_tree_update(linked_socket.id_data)  #Takes Node Tree
                return None  # raise LookupError
            if s_id in DATA_CACHE[socket_nodeGr]:
                return DATA_CACHE[socket_nodeGr][s_id]
            # cant find socked s_id in cache? should not happend (but haapens with undo anyway) fixed...
            logging.debug(f'No cache: from {self.node.name}[{self.identifier}] to {linked_socket.node.name}[{linked_socket.identifier}]')
            # maybe try calculating node for which tere is no cache (can be empty input image maybe...)
            # linked_socket.node.execute_node(context)  # no cache  - maybe create it by calling node?
            return None
        else:
            return None


# Custom socket type
class SingleChannelSocket(NodeSocket, BaseSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'SingleChannelSocket'
    # Label for nice name display
    bl_label = "Single Channel Socket"

    def color_change(self, context):
        logging.debug(f'[{self.name}] - color_change()')
        build_and_run_nodes_update(self.node)

    color: bpy.props.FloatProperty(name="", description="", default=0.0, min=0, max=1, update=color_change)

    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, "color", text=text)

    # Socket color
    def draw_color(self, context, node):
        return (0.4, 0.4, 0.4, 1.0)


class RGBASocket(NodeSocket, BaseSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'RGBASocket'
    # Label for nice name display
    bl_label = "RGBA Socket"

    def color_change(self, context):
        logging.debug(f'[{self.name}] - color_change()')
        build_and_run_nodes_update(self.node)

    color: bpy.props.FloatVectorProperty(name="Color", subtype='COLOR', size=4, default=[1.0, 1.0, 1.0, 1.], min=0.0, max=1.0, update=color_change)

    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, "color", text=text)

    # Socket color
    def draw_color(self, context, node):
        return (0.8, 0.8, 0.0, 1.0)



#* NODES  ########################################################################################################
PREFIX = 'TextureMix'

# Mix-in class for all custom nodes in this tree type.
# Defines a poll function to enable instantiation.
def child_nodes(node):
    return [link.to_node for output in node.outputs if output.is_linked for link in output.links]

def get_max_parent_depth(node):
    max_depth = -1
    for input in node.inputs:
        if input.is_linked:
            for link in input.links:
                parent_depth = link.from_node.queue_depth
                max_depth = max(max_depth, parent_depth)
    return max_depth


def set_nodes_queue_depth(current_node):
    ''' setting node queue_depth - defines the order in which it will be executed '''
    max_parent_depth = get_max_parent_depth(current_node)
    if max_parent_depth > -1:
        current_node.queue_depth = max_parent_depth + 1
    else:  # we must be first node - node where update ocurred
        current_node.queue_depth = 0

    for child in child_nodes(current_node):
        set_nodes_queue_depth(child)


def reset_link_states(node_tree):
    global NODES_IN_STATES

    if node_tree.name not in NODES_IN_STATES.keys():
        NODES_IN_STATES[node_tree.name] = {}
    else:
        NODES_IN_STATES[node_tree.name].clear()

    for node in node_tree.nodes:
        if node.inputs[:]:  # any inputs
            NODES_IN_STATES[node_tree.name][node.name] = [in_sock.is_linked for in_sock in node.inputs]

def restart_node_tree(node_tree):
    reset_link_states(node_tree)
    inputNodes = [node for node in node_tree.nodes if node.bl_idname == InputTextureNode.bl_idname and node.img]
    for inNode in inputNodes:
        set_nodes_queue_depth(inNode)

    node_to_queue_depth = {node: node.queue_depth for node in node_tree.nodes if node.queue_depth > -1}
    sorted_queue = [node for node, depth in sorted(node_to_queue_depth.items(), key=lambda item: item[1]) if depth > -1]
    for n in sorted_queue:  # resete queued depth since we already got the nodes
        n.queue_depth = -1
    logging.debug(f"Restart node tree. execute list:\n - " + "\n - ".join([n.name for n in sorted_queue]))
    for node in sorted_queue:
        node.execute_node(bpy.context)


def build_execution_queue(changed_node):
    ''' Go to child nodes, and set depth to max parent depth+1. Then return node list sorted by queue place '''
    set_nodes_queue_depth(changed_node)

    node_tree = changed_node.id_data
    node_to_queue_depth = {node: node.queue_depth for node in node_tree.nodes if node.queue_depth > -1}
    sorted_queue = [node for node, depth in sorted(node_to_queue_depth.items(), key=lambda item: item[1]) ]
    logging.debug(f"Generated nodes list to execute:\n - " + "\n - ".join([n.name for n in sorted_queue]))
    for n in sorted_queue:  # resete queued depth since we already got the nodes
        n.queue_depth = -1
    global EXECUTE_QUEUE
    EXECUTE_QUEUE = sorted_queue


def build_and_run_nodes_update(changed_node):
    logging.debug(f'[{changed_node.name}] - Build and run nodes to update')
    build_execution_queue(changed_node) #builds list to global EXECUTE_QUEUE
    global EXECUTE_QUEUE
    for node in EXECUTE_QUEUE:  # ! should we actually run those on just waitn for update(self) to kick in?
        node.execute_node(bpy.context)
    EXECUTE_QUEUE.clear()

class ChannelMixingTreeNode:

    queue_depth: bpy.props.IntProperty(name='Queue Depth', description='', default=-1, min=-1, max=100)

    @classmethod
    def poll(cls, ntree):
        return ntree.bl_idname == 'TextureChannelMixing'

    def get_inputs_data(self):
        if not self.any_input_connected():
            return None, None
        # at least one input connected ---

        max_res = [0, 0] #max input np_image size
        input_data = {}
        for i, input_socket in enumerate(self.inputs):
            in_socket_data = input_socket.get_cache()  # Can be None, Float, RGBA_np, R_np
            if hasattr(in_socket_data, 'shape'):
                max_res[0] = max(max_res[0], in_socket_data.shape[0])
                max_res[1] = max(max_res[1], in_socket_data.shape[1])
            input_data[input_socket.name] = in_socket_data #name eg. r,g,b,a

        if all([v is None for v in input_data.values()]) or max_res == [0, 0]:  # seems connected but to inactive nodes...
            return None, None

        return input_data, max_res

    def any_input_connected(self):
        return any([inp.is_linked for inp in self.inputs])

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        logging.debug(f"Copying from node {node}")
        node_tree = self.id_data
        global NODES_IN_STATES
        NODES_IN_STATES[node_tree.name][self.name] = [False for in_sock in self.inputs]

    def free(self):
        logging.debug(f"Removing node {self}!")

    def insert_link(self, link):
        #! Damm, at this stage node.exec() see old state (before link was switched) so no point calling exec_queue
        #bo just build_execution_queue instead
        #* self is node that input link was changed?
        if self == link.to_node:
            logging.debug(f'[{self.name}] - insert_link() from {link.from_node.name} to {link.to_node.name}\nBuild list')
            build_execution_queue(self)
        #if self == link.from_node: # self == node on left of link (input node - so do not change)

    def socket_value_update(self, context):
        logging.debug(f'[{self.name}] - socket_value_update()')

    def update(self):
        #This shit is called randomly by all nodes, even if dog farts and has nothing to do with current self node
        # logging.debug(f'[{self.name}] - Update()')
        global EXECUTE_QUEUE #so we only use global list to execute required nodes.
        if self in EXECUTE_QUEUE:
            logging.debug(f'[{self.name}] Update() - run - EXECUTE_QUEUE')
            for node in EXECUTE_QUEUE:
                node.execute_node(bpy.context)
            EXECUTE_QUEUE.clear()

        #! On link remove there is no proper update event (all nodes run update like crazy. have to detect input link_states chante = where is one missing)
        #! handled in NodeTrree update.


class OutputTextureNode(Node, ChannelMixingTreeNode):
    '''A custom node'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = PREFIX+'OutputTexture'
    # Label for nice name display
    bl_label = "Output Texture"
    # Icon identifier
    bl_icon = 'SOUND'

    def execute_node(self, context):
        logging.debug(f'[{self.name}] - execute_node()')

        input_data, input_res = self.get_inputs_data()
        if input_data is None:
            return  # do not ouput anything
        if len(input_data['Image'].shape) == 3:  # rgba on input
            np_out_img = input_data['Image']  # use red for speed (same RBG color in bakes anyway)
        else:  # probably we plugged output of splitRBB node??
            np_out_img = np.empty((input_res[0], input_res[1], 4), dtype=np.float16)
            np_out_img[:] = input_data['Image'][:,:,None]  # so [x,y,4] = [x,y,1] - copies channel to RGBA
            np_out_img[:,:,3] = 1


        if self.output_format == 'PNG':
            suffix = 'png'
        elif self.output_format == 'TARGA':
            suffix = 'tga'
        else:
            suffix = 'jpg'

        imgName = self.img + '.'+suffix
        if imgName not in bpy.data.images.keys():
            outputImg = bpy.data.images.new(imgName, width=np_out_img.shape[0], height=np_out_img.shape[1], alpha=True, float_buffer=False)
        outputImg = bpy.data.images[imgName]
        if (outputImg.size[0], outputImg.size[1]) != (np_out_img.shape[0], np_out_img.shape[1]):
            outputImg.scale(np_out_img.shape[0], np_out_img.shape[1])
        # outputImg.file_format = outputImg.file_format

        # np_out_img = np.empty((input_res[0], input_res[1], 4), dtype=np.float16)
        #np_out_img[:, :, i] = np.resize(channel, (input_res[0], input_res[1]))
        outputImg.pixels[:] = np_out_img.ravel().tolist()  # should be fastest

    def build_update_nodes(self, context):
        build_and_run_nodes_update(self)

    img: bpy.props.StringProperty(name="Image", description="Output image name", default="Output",  update=build_update_nodes)
    img_path: bpy.props.StringProperty(name="Path", subtype='DIR_PATH', default="//textures/")

    output_format: bpy.props.EnumProperty(name="Format", description="Format", items=(('PNG', "PNG", ""),
                                            ('TARGA', "TGA", ""), ('JPEG', "JPEG", "") ), default='PNG', update=build_update_nodes)

    def init(self, context):
        self.inputs.new('RGBASocket', "Image")


    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.prop(self, "img_path")
        row = layout.row(align=True)
        row.prop(self, "img")
        op = row.operator('image.save_img', text='', icon='FILE_TICK')
        op.image_name = self.img
        op.image_path = self.img_path
        op.image_format = self.output_format
        layout.prop(self, "output_format")



class PaddingTextureNode(Node, ChannelMixingTreeNode):
    bl_idname = PREFIX+'TexturePadding'
    bl_label = "Add Padding"

    def execute_node(self, context):
        logging.debug(f'[{self.name}] execute_node()')

        input_data, input_res = self.get_inputs_data()
        if input_data is None:
            return  # do not ouput anything

        np_img = np.copy(input_data['Image'])

        def img_dilate(channel):
            window_shape = (3, 3)
            channel[~alpha] = np.nan  # mask out to
            channel_pad = np.pad(channel, pad_width=1, mode='edge')
            for _ in range(self.padding):
                view_shape = tuple(np.subtract(channel_pad.shape, window_shape) + 1) + window_shape  # cos img_dim - window +1
                arr_view = np.lib.stride_tricks.as_strided(channel_pad, view_shape, channel_pad.strides * 2)
                # convolved_matrix = np.einsum('hi,hikl->kl', kernel, submatrices)

                # img_np = np.max(arr_view, axis=(2,3)) #collapses (2,3) dim -> out (2,2)
                # img_np = np.maximum.reduce(arr_view, (2, 3)) #same as above
                aver_channel = np.nanmean(arr_view, axis=(2, 3))  # collapses (2,3) dim -> out (2,2)
                prev_nans = ~np.isnan(channel)
                aver_channel[prev_nans] = channel[prev_nans]  # replace prev step non_nan with before blur
                channel[:] = aver_channel[:]  # importantnt.
                channel_pad[1:-1, 1:-1] = channel
            # return channel

        def inpaint_img(pixels):
            invalid = pixels[:, :, 3] < 0.4
            in2 = pixels[:, :, 3] < 0.4
            # avg_col = np.average(pixels[~invalid][:,:-1], axis=0)  # through x_row and y_cols
            # pixels[invalid] = np.append(avg_col, 0.0)
            for i in range(self.padding):
                inv = np.copy(invalid)
                locs = [(0, -1, 1), (0, 1, -1), (1, -1, 1), (1, 1, -1)]
                for i in range(4):
                    # print("fill step:", i)
                    for l in locs:
                        inv_rolled = np.roll(inv, l[1], axis=l[0])  # rol +- right or down
                        target_ids = (inv_rolled != inv) & inv  # find ids where we will copy too
                        pixels[target_ids] = pixels[np.roll(target_ids, l[2], axis=l[0])]  # copy from same axis, but neg dir
                        inv[target_ids] = False

                invalid = inv

            #smooth
            pixels[in2] = (pixels[in2] + np.roll(pixels, -1, axis=0)[in2] + np.roll(pixels, 1, axis=0)[in2] +
                    np.roll(pixels, -1, axis=1)[in2] + np.roll(pixels, 1, axis=1)[in2]) / 5
            pixels[~invalid,3] = 1 #valid pixels alpha=1
            # return pixels

        # for i in range(3):
        #     #? does it change the input channels ? YES
        #     if channels[i] is not None:
        #         img_dilate(channels[i])

        # ? does it change the input channels ? YES
        inpaint_img(np_img)
        self.outputs['Image'].cache_set(np_img)

    def build_update_nodes(self, context):
        build_and_run_nodes_update(self)

    padding: bpy.props.IntProperty(name='Padding', description='', default=1, min=0, max=15,  update=build_update_nodes)
    def init(self, context):
        self.inputs.new('RGBASocket', "Image")
        self.outputs.new('RGBASocket', "Image")


    def draw_buttons(self, context, layout):
        layout.prop(self, 'padding')


class MixRGBATextureNode(Node, ChannelMixingTreeNode):
    bl_idname = PREFIX+'MixRGBA'
    bl_label = "Mix"

    def execute_node(self, context):
        logging.debug(f'[{self.name}] execute_node()')

        inp, input_res = self.get_inputs_data()
        if inp is None:
            return  # do not ouput anything

        for in_key, channel in inp.items():  # channel can be None, 3d_Float, np.array, 3d np.array
            if channel is None:  # fill with 1d input color
                inp[in_key] = np.array(self.inputs[in_key].color, dtype=np.float16)

        dim_diff = len(inp['ImageA'].shape) - len(inp['ImageB'].shape)
        if dim_diff > 0:
            inp['ImageB'] = inp['ImageB'][:,:,None] #? same as [:,:,None]
        elif dim_diff < 0:
            inp['ImageA'] = inp['ImageA'][:,:,None] #? same as [:,:,None]


        if self.mix_mode == 'MIX':
            # a * (1-b_alpha) + b * b_alpha  -> then factor this
            # mixed = inp['ImageA'] * (1-self.factor) + inp['ImageA']*(1-inp['ImageB'][:, :, 3])+inp['ImageB']*inp['ImageB'][:, :, 3] * self.factor
            #* mask_ImgB = inp['ImageB'][:, :, 3]
            mask = inp['ImageB'][:, :, inp['ImageB'].shape[2]-1,None] if len(inp['ImageB'].shape) == 3 else 1  # last dim is mask. Or solid color then 1
            mixed = inp['ImageA'] * (1-self.factor) + (inp['ImageA']*(1-mask)+inp['ImageB']*mask) * self.factor
            self.outputs['Image'].cache_set(mixed)
        else:
            if self.mix_mode == 'ADD':
                mixed = inp['ImageA'] + inp['ImageB']*self.factor

            elif self.mix_mode == 'MUL':
                mixed = inp['ImageA'] * (inp['ImageB']*self.factor + (1-self.factor))

            elif self.mix_mode == 'OVERLAY':
                mask = inp['ImageA'] >= 0.5  # generate boolean mask of everywhere inp['ImageA'] > 0.5
                mixed = np.empty_like(inp['ImageA'])  # generate an output container for the blended image
                # now do the blending
                mixed[~mask] = (2*inp['ImageA']*inp['ImageB'])[~mask]  # 2ab everywhere inp['ImageA']<0.5
                mixed[mask] = (1-2*(1-inp['ImageA'])*(1-inp['ImageB']))[mask]  # else this
                mixed = inp['ImageA'] * (1-self.factor) + mixed * self.factor

            mixed[:, :, 3] = inp['ImageA'][:, :, 3]  # do not multiply, add etc alpha
            if self.clamp:
                self.outputs['Image'].cache_set(np.clip(mixed, None, 1.))
            else:
                self.outputs['Image'].cache_set(mixed)

    def build_update_nodes(self, context):
        build_and_run_nodes_update(self)

    mix_mode: bpy.props.EnumProperty(name='Mix Mode',
                                    items=(('MIX', 'Mix', 'Mix'),
                                        ('ADD', 'Add', 'Add'),
                                        ('MUL', 'Multiply', 'Multiply'),
                                        ('OVERLAY', 'Overlay', 'Overlay')
                                        ), default='MIX', update=build_update_nodes)
    clamp: bpy.props.BoolProperty(name='Clamp', description='', default=False, update=build_update_nodes)
    factor: bpy.props.FloatProperty(name='Factor', description='', default=1.0, min=0, max=1, precision=2, subtype='FACTOR', update=build_update_nodes)

    def init(self, context):
        self.inputs.new('RGBASocket', "ImageA")
        self.inputs.new('RGBASocket', "ImageB")
        self.outputs.new('RGBASocket', "Image")

    def draw_buttons(self, context, layout):
        layout.prop(self,'clamp')
        layout.prop(self,'mix_mode', text='')
        layout.prop(self, 'factor')



class SetAlphaTextureNode(Node, ChannelMixingTreeNode):
    bl_idname = PREFIX+'SetAlpha'
    bl_label = "SetAlpha"

    def execute_node(self, context):
        logging.debug(f'[{self.name}] execute_node()')

        input_data, input_res = self.get_inputs_data()
        if input_data is None:
            return  # do not ouput anything

        #channel can be None, Float, np.array
        if input_data['Image'] is None:  # fill with input color
            np_out_img = np.empty((input_res[0], input_res[1], 4), dtype=np.float16)
            np_out_img[:,:,:] = np.array(self.inputs[0].color, dtype=np.float16)[None]
        else:
            # np_out_img[:, :, i] = np.resize(channel, (input_res[0], input_res[1])) #do we reed resize?
            if len(input_data['Image'].shape) == 3:  # x,y, (rgba) on input
                np_out_img = np.copy(input_data['Image'])# use red for speed (same RBG color in bakes anyway)
            else:  # probably (x,y) - singel channel
                np_out_img = np.empty((input_res[0], input_res[1], 4), dtype=np.float16)
                np_out_img[:,:,:-1] = input_data['Image'][:,:,None]
                np_out_img[:,:,-1] = 1

        if self.inputs['Alpha'].is_linked:
            if len(input_data['Alpha'].shape) == 3:  # x,y, (rgba) on input
                np_out_img[:, :, 3] = np.average(input_data['Alpha'][:, :, :-1], axis=2)  # use average RBG as alpha
            else: #probably (x,y) - singel channel
                np_out_img[:, :, 3] = input_data['Alpha'] # use red for speed (same RBG color in bakes anyway)
        else:
            np_out_img[:, :, 3] = np.average(self.inputs['Alpha'].color)

        self.outputs['Image'].cache_set(np_out_img)

    def init(self, context):
        self.inputs.new('RGBASocket', "Image")
        self.inputs.new('SingleChannelSocket', "Alpha")
        self.outputs.new('RGBASocket', "Image")

    def draw_buttons(self, context, layout):
        pass


class SeparateRGBATextureNode(Node, ChannelMixingTreeNode):
    bl_idname = PREFIX+'SeparateRGBA'
    bl_label = "Separate RGBA"
    bl_icon = 'SOUND'

    def execute_node(self, context):
        logging.debug(f'[{self.name}] execute_node()')

        input_data, input_res = self.get_inputs_data()
        if input_data is None:
            return #do not ouput anything

        for i, output in enumerate(self.outputs):
            output.cache_set(input_data['Image'][:, :, i])


    def init(self, context):
        self.inputs.new('RGBASocket', "Image")
        self.outputs.new('SingleChannelSocket', "R")
        self.outputs.new('SingleChannelSocket', "G")
        self.outputs.new('SingleChannelSocket', "B")
        self.outputs.new('SingleChannelSocket', "A")

    def draw_buttons(self, context, layout):
        pass


class CombineRGBATextureNode(Node, ChannelMixingTreeNode):
    bl_idname = PREFIX+'CombineRGBA'
    bl_label = "Combine RGBA"
    bl_icon = 'SOUND'

    def execute_node(self, context):
        logging.debug(f'[{self.name}] execute_node()')

        input_data, input_res = self.get_inputs_data()
        if input_data is None:
            return  # do not ouput anything

        np_out_img = np.empty((input_res[0], input_res[1], 4), dtype=np.float16)

        for i, (key, channel) in enumerate(input_data.items()):
            #channel can be None, Float, np.array
            if channel is None:  # fill with input color
                np_out_img[:, :, i] = self.inputs[i].color
            # np_out_img[:, :, i] = np.resize(channel, (input_res[0], input_res[1])) #do we reed resize?
            elif hasattr(channel, 'shape'): # we got np_array at input
                if len(channel.shape) == 3: # x,y, (rgba) on input
                    np_out_img[:, :, i] = channel[:,:,0] #use red for speed (same RBG color in bakes anyway)
                else: #probably (x,y) - singel channel
                    np_out_img[:, :, i] = channel
            else: #single color input - will be broadcasted auto to img.shape
                np_out_img[:, :, i] = channel

        self.outputs['Image'].cache_set(np_out_img)

    def init(self, context):
        self.inputs.new('SingleChannelSocket', "R")
        self.inputs.new('SingleChannelSocket', "G")
        self.inputs.new('SingleChannelSocket', "B")
        self.inputs.new('SingleChannelSocket', "A")
        self.outputs.new('RGBASocket', "Image")

    def draw_buttons(self, context, layout):
        pass


class InputTextureNode(Node, ChannelMixingTreeNode):
    '''A custom node'''
    bl_idname = PREFIX+'InputTexture'
    bl_label = "Input Texture"
    bl_icon = 'SOUND'

    def execute_node(self, context):
        logging.debug(f'[{self.name}] execute_node()')


        node_tree = self.id_data #get node tree, current node is in
        #Get biggest image size

        xMax = yMax = 0
        for node in node_tree.nodes:
            if node.bl_idname == PREFIX+'InputTexture' and node.img:
                xMax = max(node.img.size[0], xMax)
                yMax = max(node.img.size[1], yMax)

        if self.img:
            img = self.img

            img_was_scaled = False
            if (img.size[0], img.size[1]) != (xMax, yMax):
                back = np.array(img.pixels[:])
                old_size = img.size[:]
                img.scale(xMax, yMax)
                img_was_scaled = True
            np_img = np.array(img.pixels[:]).reshape(img.size[0], img.size[1], 4) #crap result - use padd
            if img_was_scaled:
                img.scale(old_size[0], old_size[1])
                img.pixels[:] = back.ravel().tolist()  # fastest? https://devtalk.blender.org/t/bpy-data-images-perf-issues/6459
                # img.reload() #! this may be clear generated imgs...

            self.outputs["Image"].cache_set(np_img)
        else:
            return

    def build_update_nodes(self, context):
        build_and_run_nodes_update(self)

    img: bpy.props.PointerProperty(name='Img', type=bpy.types.Image, update=build_update_nodes)

    def init(self, context):
        self.outputs.new('RGBASocket', "Image")

    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.prop_search(self, "img", bpy.data, "images", text='')
        if self.img:
            layout.template_icon(icon_value=self.img.preview.icon_id, scale=6.0)


### Node Categories ###
# Node categories are a python system for automatically
# extending the Add menu, toolbar panels and search operator.
# For more examples see release/scripts/startup/nodeitems_builtins.py


# our own base class with an appropriate poll function,
# so the categories only show up in our own tree type

class ImageNodeCategory(NodeCategory):
    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == 'TextureChannelMixing'


# all categories in a list
node_categories = [
    # identifier, label, items list
    ImageNodeCategory('InputNodes', "Input", items=[
        # our basic node
        NodeItem(PREFIX+"InputTexture"),
    ]),
    ImageNodeCategory('MixNodes', "Texture Nodes", items=[
        # the node item can have additional settings,
        # which are applied to new nodes
        # NB: settings values are stored as string expressions,
        # for this reason they should be converted to strings using repr()
        NodeItem(PREFIX+'MixRGBA'),
        NodeItem(PREFIX+'SetAlpha'),
        NodeItem(PREFIX+'SeparateRGBA'),
        NodeItem(PREFIX+'CombineRGBA'),
        NodeItem(PREFIX+"TexturePadding"),
    ]),
    # identifier, label, items list
    ImageNodeCategory('OutputNodes', "Output", items=[
        # our basic node
        NodeItem(PREFIX+"OutputTexture"),
    ]),
]



def registerNode():
    # nodeitems_utils.register_node_categories('CUSTOM_NODES', node_categories)
    nodeitems_utils.register_node_categories('CHANNEL_MIX', node_categories)
    bpy.app.handlers.load_post.append(restart_nodes)


def unregisterNode():
    # nodeitems_utils.unregister_node_categories('CUSTOM_NODES')
    nodeitems_utils.unregister_node_categories('CHANNEL_MIX')
    DATA_CACHE.clear()
    bpy.app.handlers.load_post.remove(restart_nodes)
