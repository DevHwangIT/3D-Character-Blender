# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
import math
import numpy as np
import mathutils
from mathutils import noise, Vector
from .material_operators import HTOOL_OT_CurvesUVRefresh
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty
from .resample2d import get2dinterpol_Catmull_Rom
from .utils.helper_functions import calc_exponent, calc_tanh, calc_pow_inverted
from .utils.curve_wrapper import SplineSimple, Splines
from .utils.general_utils import create_new_curve_obj
from .material_operators import import_default_hair_mat
from .hair_curve_helpers import get_obj_mesh_bvht
from .hair_curve_helpers import HTOOL_OT_CurvesTiltAlign
from .utils.general_utils import get_addon_preferences
from .profile_operations import generate_profile, update_profile


Island_is_cyclic = None

def my_get_sorted_loops(bm):
    ''' Get first row of sharp edges/verts per island'''
    bm.edges.ensure_lookup_table()
    remaining_edges_ids = [e.index for e in bm.edges if not e.smooth and e.is_boundary]
    edge_strips = []
    vert_strips = []

    while remaining_edges_ids:
        current_edge_loop = []
        current_vert_loop = []
        current_edge = bm.edges[remaining_edges_ids.pop()]
        current_edge_loop.append(current_edge)

        def follow_edge_loop(curr_edge, old_vert, add_right):
            while True:  # go vert0 way, till no lined edges (line stops)
                next_vert = curr_edge.other_vert(old_vert)
                next_edges = [link_e for link_e in next_vert.link_edges if not link_e.smooth and link_e.is_boundary and link_e != curr_edge]
                if add_right:
                    current_vert_loop.append(next_vert)
                else:
                    current_vert_loop.insert(0, next_vert)
                if next_edges and next_edges[0] not in current_edge_loop:  # just ignore if there are more linked edges selected. Maybe give error - bad selection
                    if add_right:
                        current_edge_loop.append(next_edges[0])
                        # current_vert_loop.append(next_vert)
                    else:
                        current_edge_loop.insert(0, next_edges[0])
                        # current_vert_loop.insert(0,next_vert)
                    remaining_edges_ids.remove(next_edges[0].index)
                    curr_edge = next_edges[0]
                    old_vert = next_vert  # right vert becomes left
                else:
                    break
        follow_edge_loop(current_edge, current_edge.verts[0], True)  # go in direction of vert 1
        follow_edge_loop(current_edge, current_edge.verts[1], False)  # go in direction of vert 0

        edge_strips.append(current_edge_loop)
        vert_strips.append(current_vert_loop)

    global Island_is_cyclic
    Island_is_cyclic = [vert_strip[0] == vert_strip[-1] for vert_strip in vert_strips]
    for is_cyclic, edge_strip in zip(Island_is_cyclic, edge_strips):
        if is_cyclic:
            edge_strip.append(edge_strip[0])
    return vert_strips, edge_strips

def getEdgesRing(edge):
    edgesRing = []
    edgesRing.append(edge)
    loop = edge.link_loops[0]
    while True:
        if len(loop.face.edges) != 4:  # ring only from quad
            break
        loop = loop.link_loop_next.link_loop_next
        edgesRing.append(loop.edge)
        if len(loop.link_loops) != 1:
            break
        loop = loop.link_loops[0]
    return edgesRing


def getEdgesRing_vert(edge, vert): # for left vert, get left vert from ring edge
    verts_rings = []
    verts_rings.append(vert.co.copy())
    loop = edge.link_loops[0]
    while True:
        if len(loop.face.edges) != 4: #ring only if quad
            break
        ring_loop = loop.link_loop_next.link_loop_next
        next_ring_vert = ring_loop.link_loop_next.vert if ring_loop.link_loop_next.link_loop_next.vert == vert else ring_loop.vert

        verts_rings.append(next_ring_vert.co.copy())
        if len(ring_loop.link_loops) != 1:
            break
        loop = ring_loop.link_loops[0]  # loop from next face. #? Break if len(loop.face.edges) != 4
        vert = next_ring_vert
    return verts_rings


def get_sorted_verts_co(obj):
    ''' Get verts rings from sharp edges '''
    depsgraph = bpy.context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    bm = bmesh.new()  # create an empty BMesh
    bm.from_mesh(obj_eval.data) #with mods
    selected_edges = [e for e in bm.edges if not e.smooth and e.is_boundary]  # get sharp boundary eges only
    if len(selected_edges) == 0:
        return 0

    verts_loops, edges_strips = my_get_sorted_loops(bm)  # list - island1Edges, island2Edges ...
    edge_ring_centers_List_per_island = []

    for islandEdgesLoop, island_verts in zip(edges_strips, verts_loops):  # for selected/sharp edge loops in island
        edge_ring_centers_List = []
        for i, edge in enumerate(islandEdgesLoop):  # create edge rings for sharp edge loops
            left_vert = edge.verts[0] if edge.verts[0] == island_verts[i] else edge.verts[1]  # else e.verts[1] == VertsLoops[i]
            verts_ring = getEdgesRing_vert(edge, left_vert)
            edge_ring_centers_List.append(verts_ring)

        #get last right vert...
        right_vert = edge.other_vert(left_vert)  # else e.verts[1] == VertsLoops[i]
        verts_ring = getEdgesRing_vert(edge, right_vert)
        edge_ring_centers_List.append(verts_ring)

        edge_ring_centers_List_per_island.append([list(i) for i in zip(*edge_ring_centers_List)])  # do transpose

    bm.free()
    # obj_eval.to_mesh_clear()
    return edge_ring_centers_List_per_island


def get_edge_ring_centers(obj):
    # settings = 'PREVIEW'
    depsgraph = bpy.context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    # me = obj_eval.to_mesh()
    bm = bmesh.new()  # create an empty BMesh
    bm.from_mesh(obj_eval.data)

    selected_edges = [e for e in bm.edges if not e.smooth and e.is_boundary]  # get sharp boundary eges only
    if len(selected_edges) == 0:
        return 0
    if len(selected_edges) == 1:
        return 1
    verts_strips, edges_strips = my_get_sorted_loops(bm)
    edge_ring_centers_List_per_island = []
    for islandEdgesLoop in edges_strips:  # for selected/sharp edge loops in island
        edge_ring_centers_List = []
        for loopEdge in islandEdgesLoop:  # create edge rings for sharp edge loops
            edgeRing = getEdgesRing(loopEdge)
            edge_ring_Centers = [(e.verts[0].co + e.verts[1].co)/2 for e in edgeRing]
            edge_ring_centers_List.append(edge_ring_Centers.copy())
        edge_ring_centers_List_per_island.append([list(i) for i in zip(*edge_ring_centers_List)])  # does the transpose

    bm.free()
    # obj_eval.to_mesh_clear()
    return edge_ring_centers_List_per_island


def get_islands_proportions(splinesInIslands):
    widthPerIsland = []
    lengthPerIsland = []
    for splines in splinesInIslands:  # for islands
        splinesTotalLen = 0
        splineTotalWidth = 0
        prevSpline = splines[0]
        for splineIndex, spline in enumerate(splines):
            prevPoint = spline[0]
            for pointIndex, point in enumerate(spline):
                splinesSpacing = Vector(spline[pointIndex]) - Vector(prevSpline[pointIndex])
                splineTotalWidth += splinesSpacing.length
                splinesLen = Vector(point) - Vector(prevPoint)
                splinesTotalLen += splinesLen.length
                prevPoint = point
            prevSpline = spline
        lengthPerIsland.append(splinesTotalLen / len(splines))  # len*numb of spliness / number of splines
        widthPerIsland.append(splineTotalWidth / len(splines[0]))  # width*pointsNumb / numb of points
    maxWidthX = max(widthPerIsland)
    maxLengthY = max(lengthPerIsland)
    NormalizedWidthXPerIsland = [xWidth / maxWidthX for xWidth in widthPerIsland]
    NormalizedLengthYPerIsland = [yWidth / maxLengthY for yWidth in lengthPerIsland]
    return NormalizedWidthXPerIsland, NormalizedLengthYPerIsland


class HTOOL_OT_CurvesFromsurface(bpy.types.Operator):
    bl_label = "Curves from grid surface"
    bl_idname = "object.curves_from_grid"
    bl_description = "Generate hair curves from grid type mesh object \n" \
                     "For operator to work one border loop must be marked as sharp"
    bl_options = {"REGISTER", "UNDO", "PRESET"}


    gen_method: bpy.props.EnumProperty(name="Generation Method", default="edge",
                                       items=(("edge", "Edge Centers", "Use edge rings centers for guiding curves"),
                                              ("vert", "Vertex position", "Use edge rings vertices for guiding curves")))
    hairType: bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                     items=(("BEZIER", "Bezier", ""),
                                            ("NURBS", "Nurbs", ""),
                                            ("POLY", "Poly", "")))
    # Radius: FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, soft_max=100)
    out_spl_count: IntProperty(name="Strands count", default=10, min=1, soft_max=400)
    uniform_strands: BoolProperty(name="Uniform Strands", description="Distribute strands uniformly", default=True)
    points_count: IntProperty(name="Points per strand", description="How many points generate for each strand", default=7, min=3, soft_max=20)
    uniform_points: BoolProperty(name="Uniform Points", description="Distribute points on strand uniformly", default=True)

    offset_tip: FloatProperty(name="Offset to tip", description="Move spline points more toward tip", default=0, min=0, max=1, subtype='PERCENTAGE')
    offset_root: FloatProperty(name="Offset to root", description="Move spline points more toward root", default=0, min=0, max=1, subtype='PERCENTAGE')

    randomize_spacing: FloatProperty(name="Randomize Spacing", description="Randomize spacing between strands", default=30, min=0, max=100, subtype='PERCENTAGE')
    shortenStrandLen: FloatProperty(name="Randomize Length", description="Shorten strand length", default=0.1, min=0, max=1, subtype='PERCENTAGE')
    len_seed: IntProperty(name="Seed", description="Randomize Length seed", default=1, min=1, max=1000)


    Seed: IntProperty(name="Seed", description="noise seed gives different hair flow for each value", default=1, min=1, max=1000)
    noise_amp: FloatProperty(name="Noise Amplitude", default=0.0, min=0.0, soft_max=10.0)
    freq: FloatProperty(name="Noise frequency", description="Gives more detail to hair flow. Higher frequency produces smaller detail on hair strands", default=0.5, min=0.0, soft_max=5.0)
    contrast: FloatProperty(name="Transition Contrast", description="Describes how fast noise, snap or offset influences strand over its length", default=0.5, min=0, soft_max=1)
    offset: FloatProperty(name="Transition Offset", description="Offset noise, snap or offset influence more toward the root (or tip) of strand", default=0.0, min=-1, max=1)

    noiseMixFactor: FloatProperty(name="Per strand noise", description="Blend additional noise for each strand to break uniform look", default=0.1, min=0, max=1, subtype='PERCENTAGE')
    noiseMixVsAdditive: BoolProperty(name="Mix / Add", description="Add or mix extra strand noise", default=False)
    mix_noise_seed: IntProperty(name="Seed", default=1, min=1, max=1000)
    strand_freq: FloatProperty(name="Frequency", description="Per strand noise frequency. Higher frequency produces samller detail on hair strands",  default=0.5, min=0.0, soft_max=5.0)

    offsetAbove: FloatProperty(name="Offset Above", description="Offset strands above source grid surface", default=0.0, min=-1.0, soft_max=1.0)

    snapAmount: FloatProperty(name="Snap Amount", default=0.0, min=0.0, max=1.0, subtype='PERCENTAGE')
    constrain: FloatProperty(name="Length Constrain", description="Constrain strand length to grid surface", default=1.0, min=0.0, max=1.0, subtype='PERCENTAGE')

    # generateRibbons: BoolProperty(name="Generate Ribbons", description="Add curve profile ot generated strands", default=False)
    alignToSurface: BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    clumps_effect: FloatProperty(name="Clumps", default=0, min=0, max=1, description="Clump hair together. Higher values produce bigger clumps", subtype='PERCENTAGE')
    clump_Seed: IntProperty(name="Seed", default=1, min=1, max=1000)
    clump_influence: FloatProperty(name="Clump influence", description="Clumping influence. 0 - disabled", default=1, min=0, max=1, subtype='PERCENTAGE')
    clump_falloff: FloatProperty(name="Clump fallof", description="Clumping influence over strand length", default=0, min=-1.0, max=1)
#! Props above are stored in ht_props.grid_hair_settings
#! store backup profile info in curve ht_props.profile_props
    strandWidth: FloatProperty(name="Strand Width", default=0.5, min=0.0, soft_max=10)
    set_profile: bpy.props.EnumProperty(name='Profile', description='',
        items=[
            ('ROUND', 'Round', 'Curves will have cylindrical profile'),
            ('OBJECT', 'Flat', 'Curves will have flat (ribbon) profile'),
            ('KEEP', 'Use Current', 'Do not change current curve profile')
        ], default='KEEP')

    init_profile: bpy.props.BoolProperty(name='', description='', default=True, options={'HIDDEN'})
    # new_gen_method: bpy.props.BoolProperty(name='new_gen_method', description='', default=True)

    yLengthPerIsland = []
    xWidthPerIsland = []
    diag_local = None
    run_from_curve = None
    source_grid_mesh = None
    # @classmethod #breaks undo
    # def poll(cls, context):
    #     return context.active_object.type == 'MESH'  # bpy.context.scene.render.engine == "CYCLES"
    # def invoke(self, context, event): #just shows prop pop-up but wont execute operator
    #     wm = context.window_manager
    #     return wm.invoke_props_dialog(self)

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        #replacing self with grid_hair_settings, wont update grid_hair_settings props. That is why use self
        layout = self.layout
        box = layout.box()
        box.label(text="Hair Settings:")
        col = box.column(align=True)
        # col.prop(self, 'new_gen_method')
        col.prop(self, 'gen_method')
        col.prop(self, 'hairType')
        # if not self.generateRibbons:
        #     col = box.column(align=True)
        #     col.prop(self, 'Radius')
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(self, 'out_spl_count')
        row.prop(self, 'uniform_strands', icon_only=True, emboss=True, icon='ARROW_LEFTRIGHT')
        row = col.row(align=True)
        row.prop(self, 'points_count')
        row.prop(self, 'uniform_points', icon_only=True, emboss=True, icon='ARROW_LEFTRIGHT')
        row = col.row(align=True)
        row.prop(self, 'offset_tip')
        row.prop(self, 'offset_root')
        col = box.column(align=True)
        row = col.row(align=True)
        split = row.split(factor=0.7, align=True)
        split.prop(self, 'clumps_effect')
        split.prop(self, 'clump_Seed')
        if self.clumps_effect:
            row = col.row(align=True)
            row.prop(self, 'clump_falloff')
            row = col.row(align=True)
            row.prop(self, 'clump_influence')

        col = box.column(align=True)
        col.prop(self, 'randomize_spacing')  # not really noise, but spline distance randomizaiton
        split = box.split(factor=0.7, align=True)
        split.prop(self, 'shortenStrandLen')
        split.prop(self, 'len_seed')


        col = box.column(align=True)
        col.label(text='Transitions')
        row = col.row(align=True)
        row.prop(self, 'contrast', text='Contrast')
        row.prop(self, 'offset', text='Offset')

        box.label(text="Noise Settings:")
        col = box.column(align=True)
        row = col.row(align=True)
        split = row.split(factor=0.7, align=True)
        split.prop(self, 'noise_amp')
        split.prop(self, 'Seed')
        if self.noise_amp:
            col.prop(self, 'constrain')
            # col.prop(self, 'noiseFalloff')
            col.prop(self, 'freq')
            #additional noise
            col = box.column(align=True)
            row = col.row(align=True)
            split = row.split(factor=0.6, align=True)
            split.prop(self, 'noiseMixFactor')
            split2 = split.split(factor=0.75, align=True)  # split right col, again
            split2.prop(self, 'mix_noise_seed')
            split2.prop(self, 'noiseMixVsAdditive', icon_only=True, emboss=True, icon='PLUS')
            col.prop(self, 'strand_freq')

        col = box.column(align=True)
        col.prop(self, 'snapAmount')
        col.prop(self, 'offsetAbove')

        col = box.column(align=True)
        col.prop(self, 'set_profile')
        if self.set_profile != 'KEEP':
            col.prop(self, 'strandWidth')
        col.prop(self, 'alignToSurface')

    @staticmethod
    def is_inside(p, bvht_tree, searchDistance):
        hitpoint, norm, face_index, distance = bvht_tree.find_nearest(p, searchDistance)  # max_dist = 10
        # hit, hitpoint, norm, face_index = obj.closest_point_on_mesh(p, 10)  # max_dist = 10
        vecP = hitpoint - p
        v = vecP.dot(norm)
        return v < 0.0

    def callInterpolation(self, verts2dListIsland, spl_count_normalized, pts_count_normalized, shortenStrandLen, width_m):
        if self.out_spl_count == 1:
            spl_count_normalized = -1

        if self.offset_tip or self.offset_root:
            offset_tip_tns = calc_pow_inverted(self.offset_tip+1, pts_count_normalized-1) #-1 cos when resample, we skip first segment
            offset_root_tip_tns = np.power(offset_tip_tns, self.offset_root+1)
        else:
            offset_root_tip_tns = None
        width_m=1
        return get2dinterpol_Catmull_Rom(verts2dListIsland, spl_count_normalized, pts_count_normalized, shortenStrandLen, self.Seed, self.uniform_strands, self.uniform_points, self.randomize_spacing*width_m/50, offset_root_tip_tns, self.len_seed)


    def resample_rad(self, target_pt_count):
        current_len = len(self.points_radii)
        if target_pt_count != current_len:  # assume both tilt ad rad have different pts count
            t_out_res = np.linspace(0, 1, target_pt_count)
            t_in = np.linspace(0, 1, current_len)
            return np.interp(t_out_res, t_in, self.points_radii)  # first arg len() = out len
        return self.points_radii

    def save_settings(self, target_obj):  # Tto object grid_hair_settings
        for d in self.properties.bl_rna.properties.keys():
            if d == 'rna_type':
                continue
            setattr(target_obj.ht_props.grid_hair_settings, d, getattr(self.properties, d))

    def load_settings(self, source_obj):  # from grid_hair_settings
        # what exception could occur here??
        for d in source_obj.ht_props.grid_hair_settings.bl_rna.properties.keys():
            if d in {'name', 'rna_type', 'was_created_from_grid'}:
                continue
            if hasattr(self.properties, d):
                setattr(self.properties, d, getattr(source_obj.ht_props.grid_hair_settings, d))


    def invoke(self, context, event):
        active_obj = context.active_object
        src_surf = None
        self.source_grid_mesh = None
        self.init_profile = True
        if active_obj.type == 'CURVE':
            if active_obj.ht_props.grid_hair_settings.was_created_from_grid and active_obj.ht_props.target_obj in bpy.data.objects.keys():  # obtain source grid surface, that hair was generated from
                self.run_from_curve = active_obj.name  # somewho if I refrence sourceSurface, then in execute it is lost. So use name instead

                polyline = active_obj.data.splines[0]
                points = polyline.bezier_points if polyline.type == 'BEZIER' else polyline.points
                pt_count = len(points)
                self.points_radii = np.ones(pt_count, 'f')
                # self.points_tilts = np.ones(pt_count, 'f')
                points.foreach_get('radius', self.points_radii) #this can break radius on some redo action

                self.init_profile = False
                self.set_profile = 'KEEP'
                self.strandWidth = active_obj.ht_props.profile_props.strandWidth
                src_surf = bpy.data.objects[active_obj.ht_props.target_obj]

            else:
                self.report({'INFO'}, 'Selected curve is not recognized as generated from grid surface. Cancelling')
                return {"CANCELLED"}
        elif active_obj.type == 'MESH':
            self.points_radii = np.ones(self.points_count, 'f')
            self.set_profile = 'OBJECT'
            for face in active_obj.data.polygons:
                if len(face.edge_keys) != 4:
                    self.report({'INFO'}, 'Non quad polygon detected. This operation works on quad only meshes')
                    return {"CANCELLED"}
            src_surf = active_obj

        if src_surf is None:
            self.report({'INFO'}, 'Select grid mesh type or generated curve hairs first. Cancelling')
            return {"CANCELLED"}
        if self.run_from_curve: #if operator wa executed on curve use its settigns
            self.load_settings(bpy.data.objects[self.run_from_curve]) #load settings from cure hairs
        else:
            self.load_settings(src_surf)  #else from target mesh
        # Get a BMesh representation
        me = src_surf.data
        bm = bmesh.new()  # create an empty BMesh
        bm.from_mesh(me)
        bm.edges.ensure_lookup_table()
        sharp_edges = [e for e in bm.edges if not e.smooth]
        if len(sharp_edges) == 0:
            self.report({'INFO'}, 'No edges marked as sharp! Mark one border edge loop as sharp')
            bm.free()
            return {"CANCELLED"}
        sharp_boundary_edges = [e for e in sharp_edges if e.is_boundary]
        if len(sharp_boundary_edges) == 0:
            self.report({'INFO'}, 'None of sharp edges are boundary edges! Mark one border edge loop as sharp')
            bm.free()
            return {"CANCELLED"}
        if len(sharp_boundary_edges) == 1: # for one plane wide ribbons
            self.gen_method = 'vert'
        bm.free()

        #start bbox fix - bbox fixed in blender 2.92
        if bpy.app.version < (2,92):
            src_surf.data.update()  # fixes bbox half size on undo when src_surf has mirror mod
            context.view_layer.update()  # fixes bbox half size on undo when src_surf has mirror mod
        self.diag_local = src_surf.dimensions.length / src_surf.matrix_world.to_scale().length  # world space, cos we make datail relative to real scale.

        self.depsgraph = context.evaluated_depsgraph_get()
        self.source_surf_bvh_w = get_obj_mesh_bvht(src_surf, self.depsgraph, applyModifiers=True, world_space=True)  # for tilt aliging and other
        self.depsgraph.update()
        self.source_surf_bvh_w_l = get_obj_mesh_bvht(src_surf, self.depsgraph, applyModifiers=True, world_space=False)
        # to normalize some values

        self.source_grid_mesh = src_surf.name  # somewho if I refrence sourceSurface, then in execute it is lost. So use name instead
        # hide source surface

        if get_addon_preferences().draw_grid_as_wire:
            src_surf.display_type = 'WIRE'
            src_surf.show_all_edges = True
        if bpy.app.version < (3, 0):
            src_surf.hide_render = True
            src_surf.cycles_visibility.camera = False
            src_surf.cycles_visibility.diffuse = False
            src_surf.cycles_visibility.glossy = False
            src_surf.cycles_visibility.transmission = False
            src_surf.cycles_visibility.scatter = False
            src_surf.cycles_visibility.shadow = False
        else:
            src_surf.visible_camera = False
            src_surf.visible_diffuse = False
            src_surf.visible_glossy = False
            src_surf.visible_transmission = False
            src_surf.visible_volume_scatter = False
            src_surf.visible_shadow = False

        if not bpy.context.scene.ht_props.last_hair_settings.material:
            import_default_hair_mat()
        bpy.ops.ed.undo_push()
        return self.execute(context)

    # @staticmethod
    # def noise_grad(pos):
    #     noise.noise_vector(pos, noise_basis='PERLIN_ORIGINAL') - noise.noise_vector(pos+Vector((0.1, 0, 0)), noise_basis='PERLIN_ORIGINAL')+
    #     noise.noise_vector(pos, noise_basis='PERLIN_ORIGINAL') - noise.noise_vector(pos+Vector((0, 0.1, 0)), noise_basis='PERLIN_ORIGINAL')+
    #     noise.noise_vector(pos, noise_basis='PERLIN_ORIGINAL') - noise.noise_vector(pos+Vector((0, 0, 0.1)), noise_basis='PERLIN_ORIGINAL')

    previous_hair_method = None
    def execute(self, context):
        src_surf = bpy.data.objects[self.source_grid_mesh]
        # prof = Profile()
        # prof.enable()
        if self.gen_method == 'edge' and self.gen_method != self.previous_hair_method:
            self.previous_hair_method = self.gen_method
            self.coLoopsPerIslandsList = get_edge_ring_centers(src_surf)
            #detect if any island was made on one ring only, and if so switch to another algorithm
            islands_center_count = [len(loop_centers[0]) == 1 for loop_centers in self.coLoopsPerIslandsList]
            if any(islands_center_count):
                self.gen_method = 'vert'
            else:
                self.yLengthPerIsland, self.xWidthPerIsland = get_islands_proportions(self.coLoopsPerIslandsList)
        if self.gen_method == 'vert' and self.gen_method != self.previous_hair_method:
            self.previous_hair_method = self.gen_method
            self.coLoopsPerIslandsList = get_sorted_verts_co(src_surf)
            self.yLengthPerIsland, self.xWidthPerIsland = get_islands_proportions(self.coLoopsPerIslandsList) # TODO: if one seg mesh - just add in the middle ring

        coLoopsPerIslandsList = self.coLoopsPerIslandsList
        # create the Curve Datablock
        if self.run_from_curve:
            curveOB = bpy.data.objects[self.run_from_curve]
            for spl in reversed(curveOB.data.splines):
                curveOB.data.splines.remove(spl)
        else:
            curveOB = create_new_curve_obj(src_surf.name+'_grid', src_surf)

         # to normalize some values - local space, cos we use BVHT local too. So normalize by scale.inv
        diag_local = self.diag_local if self.diag_local else src_surf.dimensions.length / src_surf.matrix_world.to_scale().length
        # world_scale = context.scene.unit_settings.scale_length
        # curveData.bevel_depth = 0.004 * diag_local * self.Radius

        sourceSurface_BVHT = self.source_surf_bvh_w_l
        searchDistance = 4 * diag_local  #bvht is in local space
        # cpow = calc_exponent(self.noiseFalloff)

        out_splines_per_island = [] #* islands_count # list of list of splines to write
        np.random.seed(self.Seed) #? different noise for each island
        for island_id,  edge_centers_rows in enumerate(coLoopsPerIslandsList):  # for islands
            if len(edge_centers_rows) == 2: # only two rows -> add in the middle avg row
                new_row = [first.lerp(last, 0.2) for first,last in zip(edge_centers_rows[0], edge_centers_rows[1])]
                edge_centers_rows.insert(1, new_row)

            island_width_mul = self.xWidthPerIsland[island_id]
            island_len_mul = self.yLengthPerIsland[island_id]
            #per island spl. count, and point count
            spl_count_normalized = max(round(self.out_spl_count * island_width_mul), 2)
            pts_count_normalized = max(round(self.points_count * island_len_mul), 2)
            is_cyclic = Island_is_cyclic[island_id]
            if is_cyclic: # +1 cos we will remove last one later on write_spl_
                spl_count_normalized += 1


            Centers_of_EdgeRingsInterpolated = self.callInterpolation(edge_centers_rows, spl_count_normalized, pts_count_normalized, self.shortenStrandLen, island_width_mul)
            island_proportion_fac = math.sqrt(island_width_mul**2 + island_len_mul**2) / 1.41
            # map coords to spline
            curve_pt_count = pts_count_normalized
            fallofs_tanh = calc_tanh(self.contrast*10, self.offset, curve_pt_count)
            out_splines_per_island.append([])

            #new generation method of noise - more fluid, use x(n) = noise + x(n-1)
            points_radii = self.resample_rad(curve_pt_count).tolist()
            for l, edgeRingCenters in enumerate(Centers_of_EdgeRingsInterpolated):  # for each strand/ring
                old_pos = Vector(edgeRingCenters[0])
                strand_pts = []
                for i, (fallof_tanh, edgeCenter) in enumerate(zip(fallofs_tanh.tolist(), edgeRingCenters)):  # for strand point
                    edgeCenter = Vector(edgeCenter)
                    noise.seed_set(self.Seed)
                    noiseVectorPerAllHair = noise.noise_vector(old_pos * self.freq / diag_local, noise_basis='PERLIN_ORIGINAL')
                    noise.seed_set(self.mix_noise_seed*7793197 + l)  # seed per strand/ring
                    noiseVectorPerStrand = noise.noise_vector(old_pos * self.strand_freq / diag_local, noise_basis='PERLIN_ORIGINAL')
                    if self.noiseMixVsAdditive:
                        noiseMix = noiseVectorPerAllHair + noiseVectorPerStrand * self.noiseMixFactor
                    else:
                        noiseMix = noiseVectorPerAllHair * (1 - self.noiseMixFactor) + noiseVectorPerStrand * self.noiseMixFactor

                    # island_width_mul - reduce noise amplitued for narrow islands...
                    out_pt = old_pos + noiseMix * fallof_tanh * self.noise_amp * island_proportion_fac * diag_local  # linear fallof
                    if self.snapAmount or self.offsetAbove:  # use sourceSurface_BVHT
                        snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT.find_nearest(out_pt, searchDistance)
                        if self.snapAmount:
                            if not snappedPoint:  # search radius is too small ...
                                snappedPoint = out_pt  # snap to itself...
                                normalSourceSurf = Vector((0, 0, 1))
                            # flip = 1 if (snappedPoint - noisedEdgeCenter).dot(normalSourceSurf) < 0 else -1
                            noisedEdgeCenter_proj_vec = out_pt - snappedPoint
                            project_dist = distance * normalSourceSurf.dot(noisedEdgeCenter_proj_vec.normalized())
                            out_pt += -1*normalSourceSurf*project_dist * self.snapAmount   # + noisedEdgeCenter * (1 - self.snapAmount)
                        if self.offsetAbove:
                            out_pt += 0.2 * self.offsetAbove * diag_local * normalSourceSurf * fallof_tanh
                    if self.constrain:
                        plane_no = edgeCenter - Vector(edgeRingCenters[i-1]) if i > 0 else Vector(edgeRingCenters[i+1]) - edgeCenter
                        plane_no.normalize()
                        dist = mathutils.geometry.distance_point_to_plane(out_pt, edgeCenter, plane_no)
                        out_pt = out_pt.lerp(out_pt - dist*plane_no, self.constrain)

                    dir_to_next_center = Vector(edgeRingCenters[i+1]) - edgeCenter if i < len(edgeRingCenters)-1 else edgeCenter - Vector(edgeRingCenters[i-1]) #replaces gravit
                    old_pos = out_pt + dir_to_next_center
                    strand_pts.append(out_pt)
                #? did we obtain raddi from oriinal spl
                write_spl_w = SplineSimple.from_vec_list(strand_pts, radii=points_radii) if self.run_from_curve else SplineSimple.from_vec_list(strand_pts)
                write_spl_w.orig_spl_type = self.hairType
                # write_spl_w.points_co.insert(0, Vector(edgeRingCenters[0]))
                out_splines_per_island[-1].append(write_spl_w)

            spl_count = spl_count_normalized
            if self.clumps_effect > 0 and spl_count > 1 and self.out_spl_count > 1:  # self.out_spl_count
                np.random.seed(self.clump_Seed + island_id*31)
                clumps_effect = max(int(spl_count * (1-self.clumps_effect)), 1)  # at least  clump to one strand
                # without repeating  len(avg_clupm_size) < len(tab)
                parent_strands = np.random.choice(range(spl_count), clumps_effect, replace=False)  # without repeating
                parent_resized = np.resize(parent_strands, spl_count)  # make it same len as spl_count, (repeast from first element...)
                # child_to_parent = np.sort(np.random.choice(parent_resized, spl_count, replace=False))
                child_to_parent = np.sort(parent_resized)
                child_to_parent[parent_strands] = parent_strands #remap parents to themeself
                clump_ids_int = child_to_parent.tolist()  # with repeating - get parents strands  out_spl_count times

                cpowTip = calc_exponent(self.clump_falloff)
                Fallof_tip = np.power(np.linspace(1, 0, curve_pt_count), cpowTip)
                for spl_id, (clump_id, w_spl) in enumerate(zip(clump_ids_int, out_splines_per_island[-1])):
                    if spl_id != clump_id:
                        for j, target_point in enumerate(out_splines_per_island[-1][clump_id].points):  # out_splines_per_island[-1][clump_id] - clump target spl_id
                            # Fallof_tip = math.pow((self.points_count-j) / self.points_count, cpowTip)
                            w_spl.points[j].co = target_point.co * (1-Fallof_tip[j]) * self.clump_influence + \
                                w_spl.points[j].co * (self.clump_influence * (Fallof_tip[j] - 1) + 1)
        write_id = 0
        for island_id,out_splines in enumerate(out_splines_per_island):
            is_cyclic = Island_is_cyclic[island_id]
            spl_last = len(out_splines)-1
            for i,w_spl in enumerate(out_splines):
                if is_cyclic and i == spl_last:
                    continue
                w_spl.write_to_blender_spl(curveOB, write_id)
                write_id += 1
        # create Object
        curveOB.ht_props.target_obj = src_surf.name  # store source surface for snapping oper
        curveOB.matrix_world = src_surf.matrix_world
        if self.init_profile:
            if self.set_profile == 'KEEP':
                self.set_profile = 'OBJECT'
            generate_profile(curveOB, self.set_profile, strandWidth=self.strandWidth, write_profile_props = True)
            curveOB.ht_props.use_auto_uv = True
        else:
            if self.set_profile != 'KEEP':
                generate_profile(curveOB, self.set_profile, strandWidth=self.strandWidth, write_profile_props=True)
        HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(curveOB)
        if self.alignToSurface:
            HTOOL_OT_CurvesTiltAlign.align_curve_tilt(context, self.depsgraph, curveOB, self.source_surf_bvh_w, resetTilt=True, onlySelection=False)
        self.save_settings(curveOB)
        curveOB.ht_props.grid_hair_settings.was_created_from_grid = True
        curveOB.ht_props.curly_hair_settings.was_created_from_curls = False
        self.save_settings(src_surf)
        # prof.disable()  # don't profile the generation of stats
        # prof.dump_stats('curve_from_grid.stats')
        # with open('grod_curve_output.txt', 'wt') as output:
        #     stats = Stats('curve_from_grid.stats', stream=output)
        #     stats.sort_stats('cumulative', 'time')
        #     stats.print_stats()
        return {"FINISHED"}
