# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from bpy.props import FloatProperty, BoolProperty, IntProperty
import math
import numpy as np
import copy
from mathutils import kdtree, Vector, Euler
from mathutils.bvhtree import BVHTree
from .utils.helper_functions import calc_exponent, angle_signed, get_obj_mesh_bvht, fallof_smoothstep, remap_linear_step, gold_random, clamp, remap_smooth, smooth_threshold
from .utils.hair_common import HTool_ClassCommon
from .profile_operations import generate_profile, update_profile
from .utils.curve_wrapper import Splines, get_tips_pts, ChainIK, get_len_masked
from .resample2d import parallel_transport_TNB



class HTOOL_OT_SelectRootTip(bpy.types.Operator):
    bl_label = "Select tips/roots"
    bl_idname = "curve.select_tips"
    bl_description = "Select tips/roots"
    bl_options = {"REGISTER", "UNDO"}

    limit_sel: bpy.props.EnumProperty(name='Limit Selection', description='Limit selection by some conditions. Helps to randomize selection',
        items=[
            ('DISABLED', 'Disabled', 'Disabled'),
            ('RANDOM', 'Random', '(De)select hair endings randomly'),
            ('LENGTH', 'By length', '(De)select hair endings by length treshold limit'),
        ], default='DISABLED')

    roots: BoolProperty(name="Roots", description="Roots", default=False)
    extend: BoolProperty(name="Extend", description="Extend selection", default=False)
    seed: IntProperty(name="Seed", default=2, min=1, max=500)
    percentage: IntProperty(name="Percentage", description="Selection percent", default=50, min=0,
                                   max=100, subtype='PERCENTAGE')
    len_threshold: bpy.props.FloatProperty(name='Length threshold', description='Select only strands longer than give threshold value', default= 0.5, min=0, max=1)
    margin: bpy.props.FloatProperty(name='Tolerance', description='Smooth out selection transition by increasing length threshold tolerance', default=0.0, min=0, max=1.0)
    invert: bpy.props.BoolProperty(name='Invert', description='', default=False)

    def check(self, context): #DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'extend', toggle=True)
        layout.label(text='Limit Selection')
        row = layout.row(align=True)
        row.prop(self, 'limit_sel', expand=True)
        col = layout.column(align=True)
        if self.limit_sel == 'RANDOM':
            col.prop(self, 'percentage')
            col.prop(self, 'seed')
        elif self.limit_sel == 'LENGTH':
            row = col.row(align=True)
            row.prop(self, 'len_threshold')
            row.prop(self, 'invert', icon='CLIPUV_DEHLT', icon_only=True)
            col.prop(self, 'margin')
            if self.margin > 0:
                col.prop(self, 'seed')

    def invoke(self, context, event):
        curve_obj = context.active_object
        self.called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        if self.called_from_ht_wspace:
            self.tip_ids = []
            offset = context.scene.ht_props.select_offset
            active_end = context.scene.ht_props.active_end
            for spl in curve_obj.data.splines:
                pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                last_pid = len(pts)-1
                p_id = clamp(last_pid - offset, 0, last_pid) if active_end == "TIPS" else clamp(offset, 0, last_pid)
                self.tip_ids.append(p_id)

        self.seed = curve_obj.ht_props.uv_seed
        sel_splines = Splines(curve_obj, onlySelection=False, spline_type='SIMPLE')
        euclid_len = np.array([s.euclidean_len for s in sel_splines.splines])
        self.len_norms = euclid_len/np.max(euclid_len)
        return self.execute(context)

    def execute(self, context):
        curve_obj = context.active_object
        if curve_obj.type != 'CURVE':
            self.report({'INFO'}, 'Works only on curves')
            return {"CANCELLED"}

        index = 0 if self.roots else -1
        spl_cnt = len(curve_obj.data.splines)
        if not self.extend: # DESELCT all
            for spl in curve_obj.data.splines:
                if spl.type in {'NURBS', 'POLY'}:
                    for p in spl.points:
                        p.select = False
                else:
                    for p in spl.bezier_points:
                        p.select_control_point = False

        if self.limit_sel == 'RANDOM':
            sel_ids = []
            np.random.seed(self.seed)
            gold_seed = np.random.rand()  # (0,1) range
            pick_cnt = int(spl_cnt*self.percentage/100)  # pick %
            remaining_splines = [i for i in range(spl_cnt)]
            for i in range(pick_cnt):  # pick half of elements, for blending sel to non_sel strands...
                rd = gold_random(i, gold_seed) * spl_cnt  # low discrepancy sampling
                idx = int(rd//1)
                sel_ids.append(remaining_splines[idx])
                del(remaining_splines[idx])
                spl_cnt -= 1

        elif self.limit_sel == 'LENGTH':
            sel_ids = get_len_masked(self.len_norms, self.len_threshold, self.margin, seed=self.seed)
            if self.invert:
                all_ids = [i for i in range(len(curve_obj.data.splines))]
                sel_ids = list(set(all_ids)-set(sel_ids)) #invert by sub
        else: #disabled
            sel_ids = [i for i in range(len(curve_obj.data.splines))]
        if not hasattr(self, 'called_from_ht_wspace'):
            self.called_from_ht_wspace = False

        for i in sel_ids:
            if self.called_from_ht_wspace:  # use tip pt idx
                index = self.tip_ids[i] # for spl[i] , we have one tip pt
            polyline = curve_obj.data.splines[i]
            if polyline.type in {'NURBS','POLY'}:
                polyline.points[index].select = True
            else:
                polyline.bezier_points[index].select_control_point = True
        if self.called_from_ht_wspace:
            bpy.context.area.tag_redraw()
        return {"FINISHED"}


class HTOOL_OT_HairSelectAll(bpy.types.Operator):
    bl_idname = "curve.hair_select_all"
    bl_label = "(de)Select hair alll"
    bl_description = "(de)Select hair alll"
    bl_options = {'REGISTER', "UNDO"}

    select: bpy.props.BoolProperty(name='Select', description='Select All', default=True)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def execute(self, context):
        curve_obj = context.active_object
        _, tip_pts, _ = get_tips_pts(context, curve_obj, world_space=True, only_sel=False)

        for spl in curve_obj.data.splines:
            pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
            sel_mask = [False]*len(pts)
            if spl.type in {'NURBS', 'POLY'}:
                pts.foreach_set('select', sel_mask)
            else:
                pts.foreach_set('select_control_point', sel_mask)

        for pt in tip_pts:
            try:
                pt.select = self.select
            except Exception as e:
                pt.select_control_point = self.select
        return {'FINISHED'}


class HTOOL_OT_SelectNextPrev(bpy.types.Operator):
    bl_label = "Select netx/previous"
    bl_idname = "curve.ht_select_next"
    bl_description = "Select next/previous"
    bl_options = {"REGISTER", "UNDO"}

    previous: BoolProperty(name="Previous", description="Select Next/Previous point", default=False)
    extend: BoolProperty(name="Extend", description="Extend selection", default=False)

    def execute(self, context):
        curve_obj = context.active_object
        if curve_obj.type != 'CURVE':
            self.report({'INFO'}, 'Works only on curves')
            return {"CANCELLED"}

        curveData = curve_obj.data
        for polyline in curveData.splines:  # for strand point
            length = len(polyline.points) if polyline.type == 'NURBS' or polyline.type == 'POLY' else len(polyline.bezier_points)
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                for i,point in enumerate(polyline.points):
                    if not point.hide and point.select:
                        next_p = max(min(i+1,length-1),0)
                        prev_p = max(min(i-1,length-1),0)
                        index = prev_p if self.previous else next_p
                        if not self.extend:
                            point.select = False
                        polyline.points[index].select = True
                        break
            else:
                for i,point in enumerate(polyline.bezier_points):
                    if not point.hide and point.select:
                        next_p = max(min(i+1,length-1),0)
                        prev_p = max(min(i-1,length-1),0)
                        index = prev_p if self.previous else next_p
                        if not self.extend:
                            point.select = False
                        polyline.bezier_points[index].select = True
                        break
        return {"FINISHED"}


# for custom ui curve mapping panel - wont work in f6 props
def myNodeTree():
    if 'HairToolCurveTmp' not in bpy.data.node_groups:
        ng = bpy.data.node_groups.new('HairToolCurveTmp', 'ShaderNodeTree')
    return bpy.data.node_groups['HairToolCurveTmp'].nodes


def myCurveData(curve_name):
    if curve_name not in myNodeTree().keys():
        cn = myNodeTree().new('ShaderNodeRGBCurve')
        cn.mapping.initialize()
        cn.name = curve_name
    return myNodeTree()[curve_name]

class HTOOL_OT_CurvesTaperRadius(bpy.types.Operator):
    bl_label = "Taper Curve"
    bl_idname = "object.curve_taper"
    bl_description = "Taper Curve radius over length"
    bl_options = {"REGISTER"}

    strand_width: FloatProperty(name="Profile width", description="Strands profile width", default=0.5, min=0.0, soft_max=10)
    MainRadius: FloatProperty(name="Main Radius", description="Main Radius", default=1, min=0, soft_max=4)
    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=False)

    def invoke(self, context, event):  # make selection only false, if obj mode
        Curve = context.active_object
        if Curve.type != 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        if Curve.ht_props.profile_props:  # use init settings if  they are != defaults, else use stored values
            self.strand_width = Curve.ht_props.profile_props.strandWidth
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.onlySelection = True if Curve.mode == 'EDIT' else called_from_ht_wspace
        self.sel_splines = Splines(Curve, self.onlySelection, spline_type='FLAT')

        curv_node = myCurveData('taper_mapping')
        curv_node.mapping.initialize()
        curv_node.mapping.curves[3].points[0].location = Vector((1, 0))
        curv_node.mapping.curves[3].points[1].location = Vector((0, 1))
        curv_node.mapping.update()
        return context.window_manager.invoke_props_dialog(self)
        # return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'strand_width')
        layout.prop(self, 'MainRadius')
        self.layout.template_curve_mapping(bpy.data.node_groups['HairToolCurveTmp'].nodes["taper_mapping"], "mapping")


    def execute(self, context):
        active_obj = context.active_object
        radius_list_to_len = {} # spline len : radius list

        taper_mapping = bpy.data.node_groups['HairToolCurveTmp'].nodes['taper_mapping']
        for polyline in self.sel_splines.splines:  # for strand point
            curveLenght = polyline.length
            if curveLenght not in radius_list_to_len.keys():
                # x = np.linspace(0, 1, curveLenght)
                rad = np.array([taper_mapping.mapping.evaluate(taper_mapping.mapping.curves[3], x/(curveLenght-1)) for x in range(curveLenght)], 'f')
                radius_list_to_len[curveLenght] = self.MainRadius * rad.clip(0, 1)  # apply fallof

            polyline.points_radii = radius_list_to_len[curveLenght]
            polyline.write_rad_to_blender_spl(active_obj, polyline.orig_spl_id)

        if self.strand_width != active_obj.ht_props.profile_props.strandWidth:  # use init settings if  they are != defaults, else use stored values
            update_profile(active_obj, strandWidth=self.strand_width)
        active_obj.data.update_tag()
        context.area.tag_redraw()
        # bpy.context.window_manager.popup_menu(draw_popup, title="Greeting", icon='INFO')
        return context.window_manager.invoke_props_dialog(self)
        # return {"FINISHED"}


class HTOOL_OT_CurvesTiltAlign(bpy.types.Operator):
    bl_label = "Align curve tilt "
    bl_idname = "object.curves_align_tilt"
    bl_description = "Align curve tilt so that it is aligned to target object surface"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    resetTilt: BoolProperty(name="Reset Tilt", description="Reset Tilt before aligning it to surface", default=False)
    align_target_bvht = None
    depsgraph = None

    def invoke(self, context, event):  # make selection only false, if obj mode
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        if Curve.ht_props.target_obj not in bpy.data.objects.keys():
            self.report({'INFO'}, 'No target to align to')
            return {"CANCELLED"}
        align_target = bpy.data.objects[Curve.ht_props.target_obj]
        self.depsgraph = context.evaluated_depsgraph_get()
        self.align_target_bvht = get_obj_mesh_bvht(align_target, self.depsgraph, applyModifiers=True, world_space=True)

        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.onlySelection = True if Curve.mode == 'EDIT' else called_from_ht_wspace
        return self.execute(context)

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        if Curve.ht_props.target_obj not in bpy.data.objects.keys(): #cos when run from another operator it may skip init..
            self.report({'INFO'}, 'No target to align to')
            return {"CANCELLED"}
        if not self.depsgraph:
            self.depsgraph = context.evaluated_depsgraph_get()
        if self.align_target_bvht is None: #cos sometimes invoke may be skipped??
            align_target = bpy.data.objects[Curve.ht_props.target_obj]
            self.align_target_bvht = get_obj_mesh_bvht(align_target, self.depsgraph, applyModifiers=True, world_space=True)
        self.align_curve_tilt(context,self.depsgraph,  Curve, self.align_target_bvht,  self.resetTilt, self.onlySelection)
        # self.execute_slow_ParallelTransport(context)
        return {"FINISHED"}

    @staticmethod
    def find_nearest(p, bvht_tree, searchDistance):
        hitpoint, norm, face_index, distance = bvht_tree.find_nearest(p, searchDistance)  # max_dist = 10
        # hit, hitpoint, norm, face_index = obj.closest_point_on_mesh(p, 10)  # max_dist = 10
        vecP = hitpoint - p
        v = vecP.dot(norm)
        return hitpoint, norm, face_index, distance, v < 0.0  # v<0 = = is inside volume?


    @staticmethod
    def resetTiltFunction(context, curveData, onlySelection = False):
        for polyline in curveData.splines:  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                if onlySelection:
                    selection_test = [0] * len(polyline.points)
                    polyline.points.foreach_get('select', selection_test)
                    if not any(selection_test):
                        continue  # if not even one pointis selected
                polyline.points.foreach_set('tilt', [0] * len(polyline.points))
            else:
                if onlySelection:
                    selection_test = [0] * len(polyline.bezier_points)
                    polyline.bezier_points.foreach_get('select_control_point', selection_test)
                    if not any(selection_test):
                        continue  # if not even one point is selected
                polyline.bezier_points.foreach_set('tilt', [0] * len(polyline.bezier_points))
        # curveData.splines.update()
        return

    @staticmethod
    def get_tangents(me, index, is_last):
        selected_vert = me.vertices[index]
        if is_last:
            prev = me.vertices[index - 3]
            tangent = selected_vert.co - prev.co
        else:
            nextVert = me.vertices[index + 3]
            tangent = nextVert.co - selected_vert.co
        return tangent.normalized()

    @staticmethod
    def align_curve_tilt(context, depsgraph, curve, align_target_bvht, resetTilt=False, onlySelection=False):
        unit_scale = context.scene.unit_settings.scale_length
        curve.data.transform(curve.matrix_world)
        if resetTilt:
            HTOOL_OT_CurvesTiltAlign.resetTiltFunction(context, curve.data, onlySelection)
        depsgraph.update()

        backup_bevel_mode = curve.data.bevel_mode
        bevel_obj_back = curve.data.bevel_object  # backup

        curve.data.bevel_object = None  # zero out to prevent changing default one
        curveResU = curve.data.resolution_u  # backup
        curv_size = curve.dimensions.length * unit_scale  # to normalize some values
        #! this seems to crash in 2.92... (broken undo in blender)
        generate_profile(curve, 'OBJECT', strandResV=1, strandResU=curveResU, strandWidth=0.01 * curv_size, strandPeak=0, write_profile_props=False)  # for temp curve for tangent and normals
        # depsgraph = context.evaluated_depsgraph_get() #so align sees new geo with temp profle
        depsgraph.update()
        curve_eval = curve.evaluated_get(depsgraph) # now with temp profile
        meFromCurve = curve_eval.to_mesh()  #mesh from curve with modifiers

        # bpy.data.meshes.new_from_object(Curve_eval) #debug mesh
        meshVertCount = len(meFromCurve.vertices)
        kdMeshFromCurve = kdtree.KDTree(meshVertCount)
        for i, v in enumerate(meFromCurve.vertices):
            kdMeshFromCurve.insert(v.co, i)
        kdMeshFromCurve.balance()
        curveData = curve.data

        unitsScale = context.scene.unit_settings.scale_length
        searchDistance = 200 / unitsScale
        angleFlipFix = [-2 * math.pi, -math.pi, 2 * math.pi, math.pi]

        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        for i, polyline in enumerate(curveData.splines):  # for strand point
            points = polyline.bezier_points if polyline.type == 'BEZIER' else polyline.points
            pointsNumber = len(points)
            if onlySelection:
                spline_selection_mask = np.zeros(pointsNumber, dtype=np.bool)
                if polyline.type == 'BEZIER':
                    points.foreach_get('select_control_point', spline_selection_mask)
                else:
                    points.foreach_get('select', spline_selection_mask)
                if not any(spline_selection_mask):
                    continue  # if not even one pointis selected
                elif called_from_ht_wspace: # mark whole spline as selected if called from ht workspace tool
                    spline_selection_mask.fill(1)

            # helper for tangetnt function (to detect last point on cuve)
            prevAngle = 0
            corrective_angles = np.zeros(pointsNumber, dtype=np.float16)
            current_tilt = np.zeros(pointsNumber, dtype=np.float16)
            points.foreach_get('tilt', current_tilt)

            for j, curvePoint in enumerate(points):  # for strand point
                #pointOnMeshLoc, normSnapTarget, face_index, distance, isInside
                pointOnMeshLoc, normSnapTarget, _, _, isInside = \
                    HTOOL_OT_CurvesTiltAlign.find_nearest(curvePoint.co.xyz, align_target_bvht, searchDistance)

                # get vertex closest to spline point (for normal) from temp spline representation
                co, index, dist = kdMeshFromCurve.find(curvePoint.co.xyz)
                curveNormal = meFromCurve.vertices[index].normal

                vecSurfaceHit = -1*normSnapTarget   # less accurate but faster...
                # vecSurfaceHit = curvePoint.co.xyz - pointOnMeshLoc #* this is not ok, hair is outside target surface. Then tilt align resutl is harsh
                # if isInside:  # if curve point is outside snapSurface flip it
                #     vecSurfaceHit *= -1

                if index+3 < meshVertCount:  # for last spline just use prvevangle
                    tangent = HTOOL_OT_CurvesTiltAlign.get_tangents(meFromCurve, index, j == pointsNumber - 1)  # for bezier we can gets handles for tanget
                    biTangentCurve = tangent.cross(curveNormal)
                    vectSurfHitProjected90 = tangent.cross(vecSurfaceHit)
                    vectSurfHitProjectedToTangent = vectSurfHitProjected90.cross(tangent)
                    # angle = biTangentCurve.angle(vectSurfHitProjectedToTangent)  #unsigned angle 0 - 180
                    angle = angle_signed(biTangentCurve, vectSurfHitProjectedToTangent,
                                              tangent) - math.pi / 2  # a,b, vN  - signed -180 to 180
                    if j > 1 and abs(prevAngle - angle) > math.pi / 2:  # try fixing random flips in ribbons surface
                        fix = [fix_angle for fix_angle in angleFlipFix if abs(prevAngle - fix_angle - angle) < math.pi / 2]
                        if len(fix) > 0:
                            angle += fix[0]
                    corrective_angles[j] = angle
                    prevAngle = angle
                else:
                    corrective_angles[j] = prevAngle
            # current_tilt = current_tilt + corrective_angles
            if pointsNumber >= 4:
                corrective_angles[1] = (corrective_angles[2] + corrective_angles[3]) / 2
                corrective_angles[0] = (corrective_angles[1] + corrective_angles[2]) / 2
            elif pointsNumber == 3:
                corrective_angles[0] = (corrective_angles[1] + corrective_angles[2]) / 2
            if onlySelection:
                current_tilt[spline_selection_mask] += corrective_angles[spline_selection_mask]
            else:
                current_tilt += corrective_angles
            points.foreach_set('tilt', current_tilt.ravel())  # in radians
            # manually smooth first two points cos they are usually broken

        curve_eval.to_mesh_clear()
        temp_profile_data = curve.data.bevel_object.data
        bpy.data.objects.remove(curve.data.bevel_object)
        bpy.data.curves.remove(temp_profile_data)

        curve.data.bevel_object = bevel_obj_back  # restore old bevel obj
        if backup_bevel_mode:
            curve.data.bevel_mode = backup_bevel_mode
        curve.data.transform(curve.matrix_world.inverted())

        if curve.rotation_euler != Euler((0.0, 0.0, 0.0), 'XYZ') or min(curve.scale[:]) < 0:  # fix rot if curve rot is non 0,0,0, or scele x,y,z <0
            override = {'selected_editable_objects': [curve]}
            if curve.data.users > 1:
                curve.data = curve.data.copy()
            bpy.ops.object.transform_apply(override, location=False, rotation=True, scale=False) #! apply  scale breaks /changes pts radius

        # if was_edit:
        #     bpy.ops.object.mode_set(mode="EDIT")

    #slower han hack aboves...
    def execute_slow_ParallelTransport(self, context):
        ''' #not  somewhat worse than hack method...'''
        snapTargetName = context.active_object.ht_props.target_obj
        snapTarget = bpy.data.objects[snapTargetName]
        Curve = context.active_object

        #apply transformation to prevetn 90 deg offset bug
        snapTarget.data.transform(snapTarget.matrix_world)
        if Curve.mode == 'EDIT':  # to make transfrom() work in edit mode
            bpy.ops.object.mode_set(mode="OBJECT")
            Curve.data.transform(Curve.matrix_world)
            bpy.ops.object.mode_set(mode="EDIT")
        else:
            Curve.data.transform(Curve.matrix_world)

        if self.resetTilt:
            self.resetTiltFunction(Curve.data)

        curveData = Curve.data
        snapTarget_BVHTOOL_tree = BVHTree.FromObject(snapTarget, context.evaluated_depsgraph_get())  # render eg use subsurf render settin

        for i, polyline in enumerate(curveData.splines):  # for strand point
            strand_len = len(polyline.bezier_points) if polyline.type == 'BEZIER' else len(polyline.points)
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                if self.onlySelection:
                    spline_selection_mask = np.zeros(strand_len, dtype=np.bool)
                    polyline.points.foreach_get('select', spline_selection_mask)
                    if not any(spline_selection_mask):
                        continue  # if not even one pointis selected
                points_co = [p.co for p in polyline.points]
                points = polyline.points
            else:
                if self.onlySelection:
                    spline_selection_mask = np.zeros(strand_len, dtype=np.bool)
                    polyline.bezier_points.foreach_get('select_control_point', spline_selection_mask)
                    if not any(spline_selection_mask):
                        continue  # if not even one point is selected
                points_co = [p.co for p in polyline.bezier_points]
                points = polyline.bezier_points
              # helper for tangetnt function (to detect last point on cuve)
            prevAngle = 0
            corrective_angles = np.zeros(strand_len, dtype=np.float16)
            current_tilt = np.zeros(strand_len, dtype=np.float16)
            points.foreach_get('tilt', current_tilt)
            (T, N, B) = parallel_transport_TNB(points_co)
            strand_Ts = [Vector((i)) for i in T]
            strand_Ns = [Vector((i)) for i in N]
            strand_Bs = [Vector((i)) for i in B]
            for j, (point_T, point_N, p_B, curvePoint) in enumerate(zip(strand_Ts, strand_Ns, strand_Bs, points)):  # for strand point
                # pointOnMeshLoc, normSnapTarget, face_index, distance, isInside = self.find_nearest(curvePoint.co.xyz, snapTarget_BVHTOOL_tree, 11)
                biTangentCurve = point_T.cross(point_N)
                pointOnMeshLoc = align_target_bvht.data.splines[i].points[j].co.xyz
                vecSurfaceHit = curvePoint.co.xyz - pointOnMeshLoc
                # if isInside:  # if curve point is outside snapSurface flip it
                #     vecSurfaceHit *= -1
                vectSurfHitProjected90 = point_T.cross(vecSurfaceHit)
                vectSurfHitProjectedToTangent = vectSurfHitProjected90.cross(point_T)
                # angle = biTangentCurve.angle(vectSurfHitProjectedToTangent)  #unsigned angle <0, 180>
                angle = angle_signed(biTangentCurve, vectSurfHitProjectedToTangent, point_T) - math.pi / 2  # a,b, vN  - signed (-180, 180)
                corrective_angles[j] = angle + 1.57  # add 90deg fix
                prevAngle = angle
            if strand_len >= 4:
                corrective_angles[1] = (corrective_angles[2] + corrective_angles[3]) / 2
                corrective_angles[0] = (corrective_angles[1] + corrective_angles[2]) / 2
            elif strand_len == 3:
                corrective_angles[0] = (corrective_angles[1] + corrective_angles[2]) / 2
            if self.onlySelection:
                current_tilt[spline_selection_mask] += corrective_angles[spline_selection_mask]
            else:
                current_tilt = corrective_angles
            points.foreach_set('tilt', current_tilt)  # in radians
            # manually smooth first two points cos they are usually broken

        snapTarget.data.transform(snapTarget.matrix_world.inverted())
        if Curve.mode == 'EDIT':  # to make transfrom() work in edit mode
            bpy.ops.object.mode_set(mode="OBJECT")
            Curve.data.transform(Curve.matrix_world.inverted())
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            bpy.ops.object.mode_set(mode="EDIT")
        else:
            Curve.data.transform(Curve.matrix_world.inverted())
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        return {"FINISHED"}


class HTOOL_OT_EmbedRoots(bpy.types.Operator):
    bl_label = "Embed Roots"
    bl_idname = "object.embed_roots"
    bl_description = "Embed Roots into target mesh"
    bl_options = {"REGISTER", "UNDO"}

    embed: FloatProperty(name="Embed roots", description="Radius for bezier curve", default=0, min=0, max=10)
    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=False)

    # diagonal_local = None
    def invoke(self, context, event):  # make selection only false, if obj mode
        obj = context.active_object
        if obj.mode == 'EDIT':
            self.onlySelection = True
        elif obj.mode == 'OBJECT':
            self.onlySelection = False
        # self.diagonal_local =  obj.dimensions.length/obj.matrix_world.to_scale().length
        return self.execute(context)

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        snapTargetName = Curve.ht_props.target_obj
        if not snapTargetName or snapTargetName not in bpy.data.objects.keys():
            self.report({'INFO'}, 'No target to snap to')
            return {"CANCELLED"}
        snapTargetName = Curve.ht_props.target_obj
        snapTarget = bpy.data.objects[snapTargetName]
        #FIXED:  why context.depsgrap.objects is empty on redo? Fixed with 'USE_EVAL_DATA'
        sourceSurface_BVHT = get_obj_mesh_bvht(snapTarget, context.evaluated_depsgraph_get())
        # self.diagonal_local = self.diagonal_local if self.diagonal_local else Curve.dimensions.length/Curve.matrix_world.to_scale().length
        self.embed_strands_roots(context, Curve, sourceSurface_BVHT, self.embed, self.onlySelection)
        return {"FINISHED"}

    @staticmethod
    def embed_strands_roots(context, Curve, sourceSurface_BVHT, embed, onlySelection):
        Curve.data.transform(Curve.matrix_world)

        for i, polyline in enumerate(Curve.data.splines):  # for strand point
            if onlySelection:
                selection_test = [0] * len(polyline.points)
                polyline.points.foreach_get('select', selection_test)
                if not any(selection_test): continue  # if not even one pointis selected
            points = polyline.points if polyline.type == 'NURBS' or polyline.type == 'POLY' else polyline.bezier_points
            snappedPoint, normalChildRoot, rootHitIndex, distance = sourceSurface_BVHT.find_nearest(points[0].co.xyz, 100)
            diff = points[0].co.xyz - points[1].co.xyz
            diff.normalize()
            diff_dot_norm = abs(diff.dot(normalChildRoot))  # the more diff faces the target normal, the smaller this is
            points[0].co.xyz += (diff * 0.6 * diff_dot_norm - normalChildRoot * (1 - diff_dot_norm)) * embed  # do childStrandRootNormal to move it more into mesh surface
        Curve.data.transform(Curve.matrix_world.inverted())
        # snapTarget.data.transform(snapTarget.matrix_world.inverted())


class HTOOL_OT_CurvesTiltRandomize(bpy.types.Operator):
    bl_label = "Randomize tilt"
    bl_idname = "object.curves_randomize_tilt"
    bl_description = "Change curve tilt, can be used for currly hair"
    bl_options = {"REGISTER", "UNDO"}

    reset_first: BoolProperty(name="Reset on init", description="Clear old tilt before randimizing it", default=True)
    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    tilt: FloatProperty(name="Max Tilt Angle", description="Maximum tilt angle applied to strands", default=1.5, min=-100, max=100, step=145, subtype='ANGLE')
    min_tilt: FloatProperty(name="Min Tilt", description="Minimal tilt angle (described as % \of max tilt) applied to strands", default=0.5, min=0, max=1, subtype='PERCENTAGE')
    tilt_transition_fallof: FloatProperty(name="Transition falloff", description="Describes tilt influence strength over strand length", default=0, min=0, max=1, subtype='PERCENTAGE')
    root_influence: FloatProperty(name="Root Influence", description="Strength of tilt shift induced on strand roots", default=0, min=0, max=1, subtype='PERCENTAGE')
    randomDirection: BoolProperty(name="Flip Direction", description="Flip tilt direction angle randomly from CW to CCW", default=False)
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=500)

    def save_settings(self, target_obj):  # to object  rand_tilt_settings
        for d in self.properties.bl_rna.properties.keys():
            if d == 'rna_type':
                continue
            setattr(target_obj.ht_props.rand_tilt_settings, d, getattr(self.properties, d))

    def load_settings(self, source_obj):  # from  braid_settings
        for d in source_obj.ht_props.rand_tilt_settings.bl_rna.properties.keys():
            if d in {'name', 'rna_type', 'is_braid'}:
                continue
            setattr(self.properties, d, getattr(source_obj.ht_props.rand_tilt_settings, d))

    def invoke(self, context, event):  # make selection only false, if obj mode
        if context.active_object.mode == 'EDIT':
            self.onlySelection = True
        elif context.active_object.mode == 'OBJECT':
            self.onlySelection = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.load_settings(context.active_object)  # so load cached settings
        return self.execute(context)

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        np.random.seed(self.Seed*149)
        spline_count = len(Curve.data.splines)
        randTiltList = np.random.rand(spline_count)
        cpow = calc_exponent(self.tilt_transition_fallof)
        randDir = np.random.choice([1,-1],spline_count) if self.randomDirection else np.ones(spline_count, dtype=np.int)
        np.random.seed(self.Seed+12)
        called_from_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        for i, polyline in enumerate(Curve.data.splines):  # for strand point
            points = polyline.points if polyline.type == 'NURBS' or polyline.type == 'POLY' else polyline.bezier_points
            pointsNumber = len(points)
            if self.onlySelection:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = [point for point in points if point.select]
                else:  # bezier
                    points = [point for point in points if point.select_control_point]
                if called_from_wspace and points: #any pts selected in spline?
                    points = polyline.points if polyline.type == 'NURBS' or polyline.type == 'POLY' else polyline.bezier_points

            for j, curvePoint in enumerate(points):  # for strand point
                strand_Fallof = math.pow(j / pointsNumber, cpow)
                min_angle_factor  = self.tilt/2 * randDir[i] * randTiltList[i] * (1-self.min_tilt) + 1*self.min_tilt
                randomizedAngle = self.tilt * randDir[i] * (min_angle_factor *  (strand_Fallof * (1 - self.root_influence) + self.root_influence))
                if self.reset_first:
                    curvePoint.tilt = randomizedAngle  # in radians
                else:
                    curvePoint.tilt += randomizedAngle  # in radians
        self.save_settings(Curve)
        return {"FINISHED"}

interpolation_items = (("LINEAR", "Linear", ""),
                       ("BSPLINE", "Bspline", ""),
                       ("CARDINAL", "Cardinal", ""))

class HTOOL_OT_CurvesSmooth(bpy.types.Operator):
    '''np didnt improve situation much'''
    bl_label = "Smooth curve"
    bl_idname = "object.curves_smooth"
    bl_description = "Smooth curve points"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    smooth: IntProperty(name="Smooth iterations", default=1, min=0, soft_max=20)

    offset: bpy.props.FloatProperty(name="Transition Offset", description="Moves straighten influence toward the roots of strands", default=1, min=0, max=1)
    contrast: bpy.props.FloatProperty(name="Transition Contrast",
                                      description="Increase straighten effect transition contrast along strand length. Low values give smoother transition", default=0.5, min=0, soft_max=1)

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def smooth3d(self, splines_points, selection_mask=None, use_fallof = False):
        '''Smooth by averging a[n-1]+ a[n]+ a[n+1]/3 - by x,y,z,1 axis'''
        if len(selection_mask)>0:
            for points, selection in zip(splines_points, selection_mask):
                if np.any(selection):
                    sel_points = points[selection]
                    avg = (sel_points[2:, :] + sel_points[:-2, :] + 4*sel_points[1:-1, :])/6
                    if use_fallof: #lerp no smooth to smooth using smoothstep fallof
                        strength = fallof_smoothstep(self.contrast, self.offset, points.shape[0]-2)
                        sel_points[1:-1, :] = avg*strength[:, None] + sel_points[1:-1, :]*(1-strength)[:, None] #basically lerp
                    else:
                        sel_points[1:-1, :] = avg #basically lerp
                    points[selection] = sel_points
        else:
            for points in splines_points:
                avg = (points[2:, :] + points[:-2, :] + 4*points[1:-1, :])/ 6
                if use_fallof:
                    strength = fallof_smoothstep(self.contrast, self.offset, points.shape[0]-2)
                    points[1:-1, :] = avg*strength[:, None] + sel_points[1:-1, :]*(1-strength)[:, None]
                else:
                    points[1:-1, :] = avg


    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'onlySelection')
        layout.prop(self, 'smooth')
        layout.prop(self, 'offset')
        layout.prop(self, 'contrast')

    def invoke(self, context, event):  # make selection only false, if obj mode
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        if Curve.mode == 'EDIT':
            self.onlySelection = True
            self.offset = 1
        elif Curve.mode == 'OBJECT':
            self.onlySelection = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        return self.execute(context)

    def execute(self, context):
        Curve = context.active_object
        splines_points = []
        splines_sel_points = []
        called_from_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        for polyline in Curve.data.splines:
            pointCount = len(polyline.points)
            points = np.zeros(pointCount*4, dtype=np.float32) #x,y,z,1
            polyline.points.foreach_get('co', points)
            points.shape = (pointCount,4)
            splines_points.append(points)
            if self.onlySelection is True:
                selection = np.zeros(pointCount, dtype=np.bool) #x,y,z,1
                polyline.points.foreach_get('select', selection)
                if called_from_wspace and np.any(selection):
                    selection.fill(True)
                splines_sel_points.append(selection)

        for i in range(self.smooth):
            self.smooth3d(splines_points, splines_sel_points, called_from_wspace)

        for polyline, new_points in zip(Curve.data.splines,splines_points):
            polyline.points.foreach_set('co', new_points.ravel())
        Curve.data.update_tag()
        context.area.tag_redraw()
        return {"FINISHED"}

class HTOOL_OT_CurvesTiltSmooth(bpy.types.Operator):
    bl_label = "Smooth tilt"
    bl_idname = "object.curves_smooth_tilt"
    bl_description = "Smooth curve tilt"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    strength: IntProperty(name="Smooth strength", default=3, min=0, max=10)

    def invoke(self, context, event):  # make selection only false, if obj mode
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)


    @staticmethod
    def smooth1d(splines_points, selection_mask=None):
        '''Smooth by averging a[n-1]+ a[n]+ a[n+1]/3 - by x,y,z,1 axis'''
        if len(selection_mask) > 0:
            for points, selection in zip(splines_points, selection_mask):
                sel_points = points[selection]
                sel_points[1:-1] = (sel_points[2:] + sel_points[:-2] + 4 * sel_points[1:-1]) / 6
                points[selection] = sel_points
        else:
            for points in splines_points:
                points[1:-1] = (points[2:] + points[:-2] + 4 * points[1:-1]) / 6

    def execute(self, context):
        Curve = context.active_object
        self.run_smooth_titl(context, Curve, self.strength, self.onlySelection)
        return {"FINISHED"}

    @staticmethod
    def run_smooth_titl(context, Curve, strength, onlySelection):
        splines_points = []
        splines_sel_points = []
        for polyline in Curve.data.splines:
            pointCount = len(polyline.points)
            points = np.zeros(pointCount, dtype=np.float32)  # x,y,z,1
            polyline.points.foreach_get('tilt', points)
            splines_points.append(points)
            if onlySelection is True:
                selection = np.zeros(pointCount, dtype=np.bool)  # x,y,z,1
                polyline.points.foreach_get('select', selection)
                splines_sel_points.append(selection)
        for i in range(strength):
            HTOOL_OT_CurvesTiltSmooth.smooth1d(splines_points, splines_sel_points)
        for polyline, new_points in zip(Curve.data.splines, splines_points):
            polyline.points.foreach_set('tilt', new_points.ravel())
        Curve.data.update_tag()
        context.area.tag_redraw()


class HTOOL_OT_CurvesTiltReset(bpy.types.Operator):
    bl_label = "Reset curve tilt"
    bl_idname = "object.curves_reset_tilt"
    bl_description = "Reset curve tilt"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        for polyline in Curve.data.splines:  # just nurbs and polyline
            curveTiltList = np.zeros(len(polyline.points), dtype= np.float16)
            polyline.points.foreach_set('tilt', curveTiltList)
        Curve.data.update_tag()
        return {"FINISHED"}


class HTOOL_OT_HairStraighten(bpy.types.Operator):
    bl_idname = "curve.hair_straighten"
    bl_label = "Hair Straighten"
    bl_description = "Curve Hair Transform (more, rotate, scale tips) with IK"
    bl_options = {'REGISTER','UNDO'}

    repeat: bpy.props.IntProperty(name='Strength', description='', default= 2, min=1, soft_max=10)
    offset: bpy.props.FloatProperty(name="Transition Offset", description="Moves straighten influence toward the roots of strands", default=0.5, min=0, max=1)
    contrast: bpy.props.FloatProperty(name="Transition Contrast", description="Increase straighten effect transition contrast along strand length. Low values give smoother transition", default=0.5, min=0, soft_max=1)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def invoke(self, context, event):
        curve_obj = context.active_object
        # self.snap_surface = bpy.data.objects[curve_obj.ht_props.target_obj] if curve_obj.ht_props.target_obj else None
        # if self.snap_surface:
        #     self.depsgraph = context.evaluated_depsgraph_get()
        #     self.snap_surface_BVHT = get_obj_mesh_bvht(self.snap_surface, self.depsgraph, applyModifiers=True, world_space=True)
        particleObj = context.active_object
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = called_from_ht_wspace

        splines = curve_obj.data.splines
        if called_from_ht_wspace:
            self.sel_spl_ids, _, _ = get_tips_pts(context, curve_obj, world_space=False, only_sel=True)
        else:
            self.sel_spl_ids = []
            for i, spl in enumerate(splines):
                pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                any_pt_sel = any([p.select for p in pts]) if spl.type in {'NURBS', 'POLY'} else any([p.select_control_point for p in pts])
                if any_pt_sel:
                    self.sel_spl_ids.append(i)

        if not self.sel_spl_ids:
            self.sel_spl_ids = [i for i in range(len(splines))]

        self.orign_ik_chains = []
        for sp_id in self.sel_spl_ids:
            spl = splines[sp_id]
            pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
            self.orign_ik_chains.append(ChainIK(pts))

        return self.execute(context)


    def execute(self, context):
        curve_obj = context.active_object
        def write_pts(pts, moved_pts):
            for p, m_p in zip(pts, moved_pts):
                p.co.xyz = m_p
        # clump_falloff = context.scene.ht_props.clump_falloff
        ik_chains = [copy.deepcopy(ik_ch) for ik_ch in self.orign_ik_chains] #makes it work correctly with redoo
        for i in range(self.repeat):
            for sp_id, ik_chain in zip(self.sel_spl_ids, ik_chains):
                spl = curve_obj.data.splines[sp_id]
                pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                ik_chain.straighten_ik_chain(self.contrast, self.offset)
                moved_pts = ik_chain.get_pts()
                write_pts(pts, moved_pts)
        return {"FINISHED"}


class HTOOL_OT_CurvesRadiusSmooth(bpy.types.Operator):
    bl_label = "Smooth radius"
    bl_idname = "object.curves_smooth_radius"
    bl_description = "Smooth curve radius"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    strength: IntProperty(name="Smooth strength", default=5, min=1, soft_max=10)

    def invoke(self, context, event):  # make selection only false, if obj mode
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
            self.onlySelection = called_from_ht_wspace
        return self.execute(context)

    @staticmethod
    def smooth(pts_rad, repeat):
        np_rad = np.array(pts_rad, 'f')
        for i in range(repeat):
            smooth_inner = np.convolve(np_rad, [0.33, 0.33, 0.33], 'valid')  # skips boundary
            np_rad[1:-1] = smooth_inner
            # center=np.apply_along_axis(np.convolve, axis=1, arr=np_rad, v=[1/3, 1/3, 1/3], mode='valid')
            # pts_rad[:, 1:-1] = center[:]
        return list(np_rad)

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        for i, polyline in enumerate(Curve.data.splines):  # for strand point
            points = polyline.points if polyline.type == 'NURBS' or polyline.type == 'POLY' else polyline.bezier_points
            if self.onlySelection:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = [point for point in points if point.select]
                else:  # bezier
                    points = [point for point in points if point.select_control_point]
                if called_from_ht_wspace and points:
                    points = polyline.points if polyline.type == 'NURBS' or polyline.type == 'POLY' else polyline.bezier_points
            if points and len(points)>2:
                curveRadiusList = [curvePoint.radius for curvePoint in points]
                smoothedRaadius = self.smooth(curveRadiusList, self.strength)
                for j, curvePoint in enumerate(points):  # for strand point
                    curvePoint.radius = smoothedRaadius[j]
        return {"FINISHED"}


class HTOOL_OT_CurveRadiusByLength(bpy.types.Operator, HTool_ClassCommon):
    bl_label = "Radius from length"
    bl_idname = "curve.radius_by_length"
    bl_description = "Radius from strand length"
    bl_options = {"REGISTER", "UNDO"}

    min_radius: bpy.props.FloatProperty(name='Min Radius', description='', default= 0.5, min=0, max=1.0)
    max_radius: bpy.props.FloatProperty(name='Max Radius', description='', default= 1.0, min=0, max=1.0)
    len_threshold: bpy.props.FloatProperty(name='Transition threshold', description='Radius change will affect only strands close to given length threshold', default= 0.5, min=0, max=1)
    margin: bpy.props.FloatProperty(name='Transition Smoothness', description='Smooth out affected strand radius chagne transition', default=1.0, min=0, max=1.0)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'


    def invoke(self, context, event):
        curve_obj = context.active_object
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.only_selected = True if curve_obj.mode == 'EDIT' else called_from_ht_wspace
        s_splines = Splines(curve_obj, onlySelection=self.only_selected, spline_type='SIMPLE')

        euclid_len = np.array([s.euclidean_len for s in s_splines.splines])
        mx = np.max(euclid_len)
        mi = np.min(euclid_len)
        if abs(mx - mi) < 0.02:
            self.len_norms = np.ones(s_splines.length)
        else:
            self.len_norms = (euclid_len - mi)/(mx-mi) # remap <mi, mx> into <0, 1> range
        self.ssplines = s_splines
        self.load_settings(curve_obj.ht_props.radius_from_length_settings)
        return self.execute(context)

    def execute(self, context):
        curve_obj = context.active_object
        len_threshold = smooth_threshold(self.len_norms, 1-self.len_threshold, self.margin/2)
        len_remapped = (self.max_radius - self.min_radius)* len_threshold + self.min_radius  # remap (0, 1) to new (mi, mx)
        for polyline, new_len in zip(self.ssplines.splines, len_remapped):
            for p in polyline.points:
                p.radius = new_len
            polyline.write_rad_to_blender_spl(curve_obj, polyline.orig_spl_id)
        self.save_settings(curve_obj.ht_props.radius_from_length_settings)

        return {"FINISHED"}


class HTOOL_OT_CurveRadiusFromUVWidth(bpy.types.Operator, HTool_ClassCommon):
    bl_label = "Radius from UV Width"
    bl_idname = "curve.radius_by_uv_width"
    bl_description = "Links strands radius to its UV region width"
    bl_options = {"REGISTER", "UNDO"}

    min_radius: bpy.props.FloatProperty(name='Min Radius', description='Minimal UV width multiplier', default= 0.0, min=0, max=1.0)
    falloff: bpy.props.FloatProperty(name='Falloff', description='Negative -> bias strands widht toward narrower strands, positive -> more toward wider. Default 0 - linear', default=0.0, min=-1.0, max=1.0)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def invoke(self, context, event):
        curve_obj = context.active_object
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.only_selected = True if curve_obj.mode == 'EDIT' else called_from_ht_wspace
        s_splines = Splines(curve_obj, onlySelection=self.only_selected, spline_type='SIMPLE')
        self.ssplines = s_splines
        # self.load_settings(curve_obj.ht_props.radius_from_length_settings)
        self.load_settings(curve_obj.ht_props.rad_uv_props)
        return self.execute(context)

    @staticmethod
    def radius_from_uv_width(curve_obj, use_multiplier=False):
        """
        Args:
            curve_obj ():
            use_multiplier ():  - option to multiply existing strand radius
        """

        rad_uv_props = curve_obj.ht_props.rad_uv_props
        first_mat = curve_obj.material_slots[0].material
        widths = []
        for hair_uv_data in first_mat.ht_props.hair_uv_points:
            x1, y1 = hair_uv_data.start_point
            x2, y2 = hair_uv_data.end_point
            width = abs(x2 - x1)
            widths.append(width)
        max_width = max(widths)
        min_width = min(widths)
        if abs(max_width - min_width) < 0.02: # we wont see any difference anyway
            return

        widths = np.array(widths)
        widths_01 = remap_linear_step(widths, min_width, max_width)
        cpow = calc_exponent(-rad_uv_props.falloff)
        widths_01_pow = np.power(widths_01, cpow)
        # normalized_widths = [w/max_width for w in widths]
        min_width_norm = min_width/max_width
        width_min_to_1 = widths_01_pow * (1 - min_width_norm) + min_width_norm  # remap (0, 1) to (min, 1)
        width_min_radius = (width_min_to_1 - 1)*(1 - rad_uv_props.min_radius) + 1
        normalized_widths = width_min_radius.tolist()

        # for polyline in self.ssplines.splines:
        random_flip_x = 2 if bpy.context.preferences.addons['hair_tool'].preferences.flipUVRandom else 1
        for spl in curve_obj.data.splines:
            mat_idx = spl.material_index
            uvRectIndex = mat_idx//random_flip_x  # full part of modulo
            width = normalized_widths[uvRectIndex]
            if use_multiplier:
                for p in spl.points:
                    p.radius *= width
            else:
                for p in spl.points:
                    p.radius = width
            # polyline.write_rad_to_blender_spl(curve_obj, polyline.orig_spl_id)
        # self.save_settings(curve_obj.ht_props.radius_from_length_settings)


    def execute(self, context):
        curve_obj = context.active_object
        self.save_settings(curve_obj.ht_props.rad_uv_props)
        self.radius_from_uv_width(curve_obj)
        return {"FINISHED"}

class HTOOL_OT_CutWithMesh(bpy.types.Operator):
    bl_label = "Slice using mesh"
    bl_idname = "curve.slice_with_mesh"
    bl_description = "Slice curve using mesh. First select mesh and curves for slicing, then run the operator\nYou have option to change direction of slicing (slice to strands roots or tips)"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=False)
    flip_dir: bpy.props.BoolProperty(name='Flip Direction', description='', default=False)

    @classmethod
    def poll(cls, context):
        return context.active_object and len(context.selected_objects)>1

    def invoke(self, context, event):  # make selection only false, if obj mode
        sel_curves = [o for o in context.selected_objects if o.type=='CURVE']
        sel_meshes = [o for o in context.selected_objects if o.type=='MESH']
        if not sel_curves:
            self.report({'WARNING'}, 'Add curve object to selection')
            return {"CANCELLED"}
        if not sel_meshes:
            self.report({'WARNING'}, 'Add mesh type of object to selection')
            return {"CANCELLED"}
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.onlySelection = True if context.mode == 'EDIT_CURVE' else called_from_ht_wspace

        self.sel_splines = []
        for c in sel_curves:
            has_shape_key = c.data.shape_keys != None
            if not has_shape_key:
                self.sel_splines.append(Splines(c, self.onlySelection, spline_type='SIMPLE'))
        if has_shape_key:
            self.report({'WARNING'}, 'Curves with shape keys will be skipped')

        cutter = sel_meshes[0]
        self.depsgraph = context.evaluated_depsgraph_get()
        self.cutter_bvht = get_obj_mesh_bvht(cutter, self.depsgraph, applyModifiers=True, world_space=True)
        bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        return self.execute(context)


    def execute(self, context):
        sel_curves = [o for o in context.selected_objects if o.type=='CURVE' and not o.data.shape_keys] #NOTE: make sure sel_curve mathes self.sel_splines
        for sel_splines, curve_obj in zip(self.sel_splines, sel_curves):
            mv_inv = curve_obj.matrix_world.inverted()
            sspline = copy.deepcopy(sel_splines)
            for spl_idx, polyline in enumerate(sspline.splines):  # for strand point
                if self.flip_dir:
                    prev_pt = curve_obj.matrix_world @ polyline.points[-1].co
                    for i,pt in reversed(list(enumerate(polyline.points[:-1]))):
                        pt_co = curve_obj.matrix_world @ pt.co
                        dir = pt_co - prev_pt
                        seg_len = dir.length
                        loc, normal, f_index, distance = self.cutter_bvht.ray_cast(prev_pt, dir) # we hit world space
                        if loc:
                            if distance < 0.3 * seg_len:
                                sspline.splines[spl_idx].points = polyline.points[i+1:]
                                sspline.splines[spl_idx].points[0].co = mv_inv @ loc
                                break
                            elif distance < seg_len:
                                sspline.splines[spl_idx].points = polyline.points[i:]
                                sspline.splines[spl_idx].points[0].co = mv_inv @ loc
                                break
                        prev_pt = pt_co
                else:
                    prev_pt = curve_obj.matrix_world @ polyline.points[0].co
                    for i,pt in enumerate(polyline.points[1:]):
                        pt_co = curve_obj.matrix_world @ pt.co
                        dir = pt_co - prev_pt
                        seg_len = dir.length
                        loc, normal, f_index, distance = self.cutter_bvht.ray_cast(prev_pt, dir) # we hit world space
                        if loc:
                            if distance < 0.3 * seg_len:
                                sspline.splines[spl_idx].points = polyline.points[:i+1]
                                sspline.splines[spl_idx].points[-1].co = mv_inv @ loc
                                break
                            elif distance < seg_len:
                                sspline.splines[spl_idx].points = polyline.points[:i+2]
                                sspline.splines[spl_idx].points[-1].co = mv_inv @ loc
                                break

                        prev_pt = pt_co

            sspline.write_splines_to_blender(curve_obj)

        # curve_obj.data.update_tag()
        # context.area.tag_redraw()
        return {'FINISHED'}
