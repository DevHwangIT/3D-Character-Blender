# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Based on Blenders builtin Curve simplify addon modified by JOSECONSCO

"""
This script simplifies Curve objects and animation F-Curves.
"""
# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python35\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb

import bpy
from .utils.curve_wrapper import Splines, Point
from copy import deepcopy
import mathutils
from mathutils import Vector
from math import sin, pow

EU_LEN = 0  # to  make simplify_RDP independent on spl lenght (normalize kindo of)
def euclidean_len(points):
    prev_co = points[0]
    total_len = 0
    for p in points:
        total_len += (p - prev_co).length
        prev_co = p
    return total_len
    
def point_line_dist(point1, point2, pointn):
    cut_pt, _ = mathutils.geometry.intersect_point_line(pointn, point1, point2)
    return (cut_pt - pointn).length

def iterate(points, out_pt_ids, error):
    new = []
    for newIndex in range(len(out_pt_ids) - 1):
        furthest_pt = 0
        max_dist = 0
        for i, point in enumerate(points[out_pt_ids[newIndex] + 1: out_pt_ids[newIndex + 1]]):
            current_dist = point_line_dist(points[out_pt_ids[newIndex]], points[out_pt_ids[newIndex + 1]], point)
            if current_dist > max_dist:
                max_dist = current_dist
                if max_dist >= error:
                    furthest_pt = i + 1 + out_pt_ids[newIndex]
        if furthest_pt:
            new.append(furthest_pt)
    return False if new == [] else new

### Ramer-Douglas-Peucker algorithm ###
def simplify_RDP(splineVerts, error):
    ''' Return simplified verts ids '''
    err = error/100
    out_pt_ids = [0, len(splineVerts) - 1]
    new = 1
    global EU_LEN
    EU_LEN = euclidean_len(splineVerts)
    if EU_LEN < 0.0001:
        return out_pt_ids
    while new is not False:
        new = iterate(splineVerts, out_pt_ids, err*EU_LEN)
        if new:
            out_pt_ids += new
            out_pt_ids.sort()
    return out_pt_ids


class HTOOL_OT_CURVE_OT_csimplify(bpy.types.Operator):
    bl_idname = "object.curve_simplify"
    bl_label = "Simplify Curves"
    bl_description = "Simplify Curves"
    bl_options = {'REGISTER', 'UNDO'}

    error: bpy.props.FloatProperty(name="Error", description="Maximum allowed distance error in Blender Units", min=0, max=10, default=0.0, precision=2)
    onlySelection: bpy.props.BoolProperty(name="Only Selected", description="Affect only selected points", default=True)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def invoke(self, context, event):
        curve_obj = context.active_object
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.onlySelection = True if curve_obj.mode == 'EDIT' else called_from_ht_wspace
        self.sel_splines = Splines(curve_obj, onlySelection=self.onlySelection, spline_type='SIMPLE')
        bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        return self.execute(context)

    def execute(self, context):
        curve = context.active_object
        backup_mat_indices = [spline.material_index for spline in curve.data.splines]
        splines = deepcopy(self.sel_splines)  # do not change the init/original curve
        for spline in splines.splines:
            if len(spline.points) > 1 or len(spline.bezier_points) > 1:  # skip single points
                out_pt_ids = simplify_RDP([p.co for p in spline.points], self.error)
                spline.points = [spline.points[idx] for idx in out_pt_ids]

        splines.write_splines_to_blender(curve)
        for i, newSpline in enumerate(curve.data.splines):  # restore mat to new splines
            newSpline.material_index = backup_mat_indices[i]
        # bpy.ops.object.curve_uv_refresh()
        return {'FINISHED'}

        



