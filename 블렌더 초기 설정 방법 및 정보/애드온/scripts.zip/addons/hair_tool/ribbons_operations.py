# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
from .utils.general_utils import link_child_to_collection, unlink_from_scene
from .material_operators import writeHairUvToMesh,  import_node_group, HTOOL_OT_CurvesUVRefresh


def shape_transfer(context, src_obj, target_obj):
    #transfer shapekeys
    if src_obj.data.shape_keys:
        context.view_layer.update()
        context.view_layer.objects.active = target_obj
        if target_obj.data.shape_keys:
            for shape in target_obj.data.shape_keys.key_blocks:
                shape.value = 0

        sourceShapesValuesBackup = []
        for shape in src_obj.data.shape_keys.key_blocks:
            sourceShapesValuesBackup.append(shape.value)
            shape.value = 0

        if not target_obj.data.shape_keys:
            target_obj.shape_key_add(name=src_obj.data.shape_keys.key_blocks[0].name, from_mix=False)

        shape_names = [s.name for s in src_obj.data.shape_keys.key_blocks]
        for i, shape_name in enumerate(shape_names):  # key_blocks['Key 1'].data[0].co
            if i == 0:
                continue
            src_obj.data.shape_keys.key_blocks[shape_name].value = 1

            # target_skey = target_obj.data.shape_keys.key_blocks.get(shape_name)
            if shape_name in target_obj.data.shape_keys.key_blocks.keys():
                target_skey = target_obj.data.shape_keys.key_blocks[shape_name]
            else:
                target_skey = target_obj.shape_key_add(name=shape_name, from_mix=False)

            depsgraph = context.evaluated_depsgraph_get()
            obj_eval = src_obj.evaluated_get(depsgraph)
            mesh_shape = obj_eval.to_mesh()
            if len(mesh_shape.vertices) == len(target_skey.data):
                for s_vert in mesh_shape.vertices:
                    target_skey.data[s_vert.index].co = s_vert.co

            obj_eval.to_mesh_clear()
            src_obj.data.shape_keys.key_blocks[shape_name].value = 0

        for backup, shape in zip(sourceShapesValuesBackup, src_obj.data.shape_keys.key_blocks):
            shape.value = backup


class HTOOL_OT_CurvesToMeshRibbons(bpy.types.Operator):
    bl_label = "Curve ribbons to mesh ribbons"
    bl_idname = "object.curve_to_mesh_ribbon"
    bl_description = 'Convert curve ribbons to mesh hair cards. You can go back to curve mode using "Mesh Ribbons to Curve Ribbons"'
    bl_options = {"REGISTER", "UNDO"}

    # refresh_material: bpy.props.BoolProperty(name='Update mesh material', description='Update mesh ribbon material, or skip this step (sometimes you may just want to update mesh ribbons geometry)', default=True)

    def invoke(self, context, event):
        sel_curves = [obj for obj in context.selected_objects if obj.type == 'CURVE' and not(obj.data.bevel_object is None and obj.data.bevel_depth == 0)]
        if not sel_curves:
            self.report({'INFO'}, 'Select at least one curve hair object first! Cancelling')
            return {"CANCELLED"}
        return self.execute(context)


    def copyMaterialFromCurveToMesh(self, curve_parent, mesh_child):
        #TODO: wa may remove mat.ht_props.linked_mesh_mat in future since ver. 2.3.3  linked_mesh_mat == parentCurve.mat[0]
        mesh_child.ht_props.is_curve = False # helper switch for hair mat
        # if len(curve_parent.data.materials) == 0:
        #     return
        # if not self.refresh_material and len(mesh_child.data.materials) > 0:#skip mat refresh if any exist
        #     return
        while len(mesh_child.data.materials) > 0:  # remove redundant mats above 1
            oldMat = mesh_child.data.materials[-1]
            mesh_child.data.materials.pop()
            if oldMat.users == 0:
                bpy.data.materials.remove(oldMat)
        for f in mesh_child.data.polygons:
            f.material_index = 0
        current_linked_mmat = curve_parent.data.materials[0].ht_props.linked_mesh_mat if len(curve_parent.data.materials) else None
        # NOTE: detect curves that are also pointing to same current_linked_mmat, but  curve.mat != curve_parent.mat => if so: unlink current_linked_mmat
        if current_linked_mmat:
            for c_data in bpy.data.curves:
                if c_data.materials and c_data.materials[0]:
                    mat = c_data.materials[0]  # if we find second curve mat, that links to current_mmat, then clean linked_mesh mat.
                    if mat != curve_parent.data.materials[0] and mat.ht_props.linked_mesh_mat and mat.ht_props.linked_mesh_mat == current_linked_mmat:
                        curve_parent.data.materials[0].ht_props.linked_mesh_mat = None
                        current_linked_mmat = None

        parent_first_mat = curve_parent.data.materials[0] if curve_parent.data.materials else None
        if parent_first_mat:
            # convert old OffsetNode  (after ver 2.3.3)
            offset_node = parent_first_mat.node_tree.nodes['OffsetNode']  # created in update_mapping_nodes
            if 'Location' not in offset_node.inputs.keys():  # update to the one with tilt input...
                HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(curve_parent, refresh_everything=True)

            if current_linked_mmat and parent_first_mat != current_linked_mmat:
                current_linked_mmat.user_remap(parent_first_mat)

            mesh_child.data.materials.append(parent_first_mat)
            curve_parent.data.materials[0].ht_props.linked_mesh_mat = parent_first_mat


    def transfer_vg(self, src_obj, target_data):
        ''' copy vertex group weights from old mesh'''
        if len(src_obj.vertex_groups) == 0: # does old hair_mesh has vgroups? If so transfer them
            return []
        back_vg_names = []
        for vg in src_obj.vertex_groups:
            back_vg_names.append(vg.name)
        bm = bmesh.new()
        bm.from_mesh(target_data)
        bm.faces.ensure_lookup_table()
        dlayer = bm.verts.layers.deform.verify()
        bm.verts.ensure_lookup_table()
        src_data = src_obj.data
        for v_idx in range(len(bm.verts)):
            if v_idx >= len(src_data.vertices):
                break
            for g in src_data.vertices[v_idx].groups:
                bm.verts[v_idx][dlayer][g.group] = g.weight
        if len(bm.verts) != len(src_data.vertices):
            self.report({'WARNING'}, '[Hair Tools] Vertex count was changed. Restored vertex weighs may be corrupted.')
        for v in bm.verts:
            g = v[dlayer]
            print(g.items())
        bm.to_mesh(target_data)
        bm.free()
        return back_vg_names

    def createMeshFromCurve(self, context, parentCurve, mesh_hair_child=None):
        depsgraph = context.evaluated_depsgraph_get()
        parentCurve_eval = parentCurve.evaluated_get(depsgraph)

        meshFromCurve = bpy.data.meshes.new_from_object(parentCurve_eval)
        if mesh_hair_child:
            prev_vg_names = self.transfer_vg(mesh_hair_child, meshFromCurve)
            mesh_hair_child.data = meshFromCurve
            for vg_name in prev_vg_names:  # NOTE: vgroups wont show unless we do this
                mesh_hair_child.vertex_groups.new(name=vg_name)

            child_mesh_obj = mesh_hair_child
        else:
            child_mesh_obj = bpy.data.objects.new(parentCurve.name + "_mesh", meshFromCurve)
        link_child_to_collection(parentCurve, child_mesh_obj)
        child_mesh_obj.select_set(True)

        # bpy.context.view_layer.objects.active = meshObjFromCurve
        child_mesh_obj.use_fake_user = False
        child_mesh_obj.ht_props.hair_settings.hair_mesh_parent = parentCurve.name
        parentCurve.ht_props.hair_settings.hair_curve_child = child_mesh_obj.name
        child_mesh_obj.matrix_world = parentCurve.matrix_world

        parentCurve.use_fake_user = True

        # this for braids -> if curv hair have curve deform modifier, then assign this mod  to generated mesh braids
        self.curve_deform_braid(parentCurve, child_mesh_obj)
        writeHairUvToMesh(self, context, depsgraph, child_mesh_obj, parentCurve)
        self.copyMaterialFromCurveToMesh(parentCurve, child_mesh_obj)
        # if parentCurve.name == active_obj_name:
        context.view_layer.objects.active = child_mesh_obj

        # apply curve deform mod
        for mod in parentCurve.modifiers:
            if mod.type == 'CURVE':
                guide_curve = mod.object
                bpy.ops.object.modifier_apply(modifier=mod.name)
                unlink_from_scene(guide_curve)

        child_mesh_obj.hide_viewport = False
        shape_transfer(context, parentCurve, child_mesh_obj)
        unlink_from_scene(parentCurve)

    @staticmethod
    def curve_deform_braid(parentCurve, meshObjFromCurve):
        # this for braids -> if curv hair have curve deform modifier, then assign this mod  to generated mesh braids
        parent_curv_mod_curv_deform = [mod for mod in parentCurve.modifiers if mod.type == 'CURVE']
        if len(parent_curv_mod_curv_deform) > 0:
            mesh_mod_curv_deform = [mod for mod in meshObjFromCurve.modifiers if mod.type == 'CURVE']
            if len(mesh_mod_curv_deform) > 0:
                mesh_mod_curv_deform[0].object = parent_curv_mod_curv_deform[0].object
            else:
                mod = meshObjFromCurve.modifiers.new("BraidDeform", 'CURVE')
                mod.object = parent_curv_mod_curv_deform[0].object
                mod.deform_axis = 'NEG_Z'

    def execute(self, context):
        sel_curves = [obj for obj in context.selected_objects if obj.type == 'CURVE' and not(obj.data.bevel_object is None and obj.data.bevel_depth == 0)]
        active_obj_name = context.active_object.name if context.active_object else ''

        braid_deform_curves = [mod.object for obj in context.selected_objects for mod in obj.modifiers if mod.type == 'CURVE' and mod.object] #exclude braid deformers from conversion
        for sel_curve in sel_curves:
            if sel_curve in braid_deform_curves:
                continue
            mesh_child_name = sel_curve.ht_props.hair_settings.hair_curve_child
            if mesh_child_name and bpy.data.objects.get(mesh_child_name):
                mesh_hair_child = bpy.data.objects.get(mesh_child_name)
                self.createMeshFromCurve(context, sel_curve, mesh_hair_child)
                if mesh_hair_child.ht_props.target_obj:
                    if mesh_hair_child.ht_props.used_uv_pick:
                        bpy.ops.object.uv_sample_from_target()
                    if mesh_hair_child.ht_props.used_weight_pick:
                        bpy.ops.object.weight_sample_from_target()
            else:
                self.createMeshFromCurve(context, sel_curve)
        return {"FINISHED"}


class HTOOL_OT_MeshRibbonsToCurve(bpy.types.Operator):
    bl_label = "Mesh ribbons to curve ribbons"
    bl_idname = "object.ribbon_convert"
    bl_description = "Revert mesh ribbons to curve ribbons"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def switch_mesh_to_curve_ribbon(context, selected_mesh_hair, set_active=True):
        if selected_mesh_hair.ht_props.hair_settings.hair_mesh_parent:  # switch to spline hair obj
            curve_hair = bpy.data.objects.get(selected_mesh_hair.ht_props.hair_settings.hair_mesh_parent)
            if curve_hair:
                if curve_hair.name not in context.scene.objects.keys():
                    link_child_to_collection(selected_mesh_hair, curve_hair)
                else:  # possibly already linked because mesh ribbon was duplicated, then duplicate source curve too
                    curve_hair = curve_hair.copy()  # copies dupli_group property(empty), but group property is empty (users_group = None)
                    selected_mesh_hair.ht_props.hair_settings.hair_mesh_parent = curve_hair.name
                    curve_hair.data = curve_hair.data.copy()
                    link_child_to_collection(selected_mesh_hair, curve_hair)
                curve_hair.matrix_world = selected_mesh_hair.matrix_world
                curve_hair.use_fake_user = False
                selected_mesh_hair.use_fake_user = True
                unlink_from_scene(selected_mesh_hair)  # hide mesh object
                if set_active:
                    curve_hair.select_set(True)
                    context.view_layer.objects.active = curve_hair
                curve_hair.ht_props.hair_settings.hair_curve_child = selected_mesh_hair.name  # set child in just in case curve name was changed

                # apply curve deform mod
                for mod in curve_hair.modifiers:
                    if mod.type == 'CURVE':
                        link_child_to_collection(curve_hair, mod.object)
            else:
                return False
        return True


    def execute(self, context):
        sel_curves = [obj for obj in context.selected_objects if obj.type == 'MESH']
        for selected_mesh_hair in sel_curves:
            sucess = self.switch_mesh_to_curve_ribbon(context, selected_mesh_hair)
            if not sucess:
                self.report({'ERROR'}, f"Cant switch to curve ribbons. Target curve {selected_mesh_hair.ht_props.hair_settings.hair_mesh_parent} is missing!")
        return {"FINISHED"}

