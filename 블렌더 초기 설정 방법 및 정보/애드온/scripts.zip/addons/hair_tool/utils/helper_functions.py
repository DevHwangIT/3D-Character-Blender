# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO
import bpy
import math
import bmesh
import numpy as np
from mathutils.bvhtree import BVHTree
from mathutils.geometry import interpolate_bezier


def clamp(x, l, u):
    return l if x < l else u if x > u else x

def get_fallof_fun(fallof_type):
    if fallof_type == 'SHARP':
        return lambda a: a ** 2
    elif fallof_type == 'ROOT':
        return lambda a: math.sqrt(a)
    elif fallof_type == 'SMOOTH': #scaled cosine
        return lambda a: 0.5*(math.cos((1-a) * 3.14)+1)
    elif fallof_type == 'INVERSE_SQUARE':
        return lambda a: 1-(a+1)**2
    elif fallof_type == 'SPHERE':
        return lambda a: math.sqrt(1-(1-a)**2)
    elif fallof_type == 'CONSTANT':
        return lambda a: 1 if a > 0 else 0
    else:
        return lambda a: a

def calc_exponent(cpow):  # defined also in curves_from_grid
    if cpow < 0:  # (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
        cpow = 1 + cpow * 0.8  # for negative map <-1,0> to <0.2, 1>
    else:
        cpow = 1 + 4 * cpow  # for positive map   <0, 1> to <1 , 5 >
    return cpow


def calc_pow(cpow, point_count):  # _/
    x = np.linspace(0, 1, point_count)
    return np.power(x, cpow)


def calc_pow_inverted(cpow, point_count):  # ^\ - eg for gravity like fallof if 2
    x = np.linspace(1, 0, point_count) # 1-x
    return 1-np.power(x, cpow)  # move below x line, then flip #-1*(np.power(x, cpow)-1)


def smoothstep(mi, mx, point_count):
    x = (np.linspace(0, 1, point_count, endpoint=True)-mi)/(mx-mi) #remap (mi, mx) to (0, 1). then use smoothstep on it
    return np.where(x < 0, 0, np.where(x <= 1, (x*x*(3 - 2 * x)), 1))


def fallof_smoothstep(contrast, offset, point_count):
    ''' renurn point_count weights '''
    offset = (1-offset)*2 - 1  # remap (0,1) to (-1,1) - (no_straight, max_straight effect)
    con_delta = (1-0.45*contrast) - (0.45*contrast)  # add left and right marging to min,max for smoothstep
    mi = clamp(0.45*contrast + offset, .0-con_delta, 1)
    mx = clamp((1-0.45*contrast) + offset, .0, 1.+con_delta)  # 0.1 margin to right
    return smoothstep(mi, mx, point_count)


def remap_smooth(x, mi, mx):
    ''' based on smoothstep but for float '''
    x = (x-mi)/(mx-mi)  # remap (0, 1) to (mi, mx) then use smoothstep on it
    return np.where(x < 0, 0, np.where(x <= 1, (x*x*(3 - 2 * x)), 1))

def remap_linear_step(x, mi, mx):
    ''' based on smoothstep but for float '''
    x = (x-mi)/(mx-mi)  # remap (0, 1) to (mi, mx) then use smoothstep on it
    return np.where(x < 0, 0, np.where(x <= 1, x, 1))

def smooth_threshold(x, threshold, margin):  # based on smoothstep
    if margin > 0:
        y = (x+margin-threshold) / (2*margin)
        return np.where(y <= 0, 0, np.where(y <= 1, np.sqrt(y), 1))
    else:
        return np.where(x < threshold, 0, 1)

inv_g = 1.0/1.6180339887498948482 # 1/gold_ratio
def gold_random(i, seed):
    ''' seed in (0,1) range '''
    return (seed + i*inv_g) % 1


def calc_tanh(contrast, offset, point_count):
    x = np.linspace(0, 1, point_count)
    return 0.5*(np.tanh(contrast*(x + offset - 0.5))+1)  # remap from (-1, 1) to (0, 1) by  0.5*(x + 1)


def gravity_fallof(factor, point_count): # _/^^
    x = np.linspace(0, 1, point_count)
    return factor*(1 - np.power(x-1, 2)) + (1 - factor)*x  # 1 -​(x -​1) ^​2


def expand_cols_np(in_array, shape_diff, ones=False):
    # https://stackoverflow.com/a/8505658/13588868
    rows_cnt = in_array.shape[0]
    if ones:
        return in_array[:, :shape_diff] if shape_diff < 0 else np.c_[in_array, np.ones((rows_cnt, shape_diff))]
    else:
        return in_array[:, :shape_diff] if shape_diff < 0 else np.c_[in_array, np.zeros((rows_cnt, shape_diff))]

def resample_linear(points, target_pt_count):
    if len(points) != target_pt_count:
        t_out_res = np.linspace(0, 1, target_pt_count)
        t_in = np.linspace(0, 1, len(points))
        return np.interp(t_out_res, t_in, points)
    return points

def bvh_from_mesh(mesh, mat_world = False):
    bm = bmesh.new()   # create an empty BMesh
    bm.from_mesh(mesh)   # with modifiers
    if mat_world:
        bm.transform(mat_world)
        bm.normal_update()
    bvh = BVHTree.FromBMesh(bm)  # ? not required to get with mod: obj.evaluated_get(depsgraph)
    bm.free()  # free and prevent further access
    return bvh

def get_obj_mesh_bvht(obj, depsgraph, applyModifiers=True, world_space=True):
    if applyModifiers:
        if world_space:
            # #? wont work eg with shrink wrap mod, but fast....
            # obj.data.transform(obj.matrix_world)
            # depsgraph.update() #fixes bad transformation baing applied to obj
            # bvh = BVHTree.FromObject(obj, depsgraph)  #? not required to get with mod: obj.evaluated_get(depsgraph)
            # obj.data.transform(obj.matrix_world.inverted())
            # return bvh

            #* better but slower - even 5-10 times (0.05 sec), wont work on non meshes (curves?)
            obj_eval = obj.evaluated_get(depsgraph)
            bm = bmesh.new()   # create an empty BMesh
            bm.from_mesh(obj_eval.to_mesh())   # with modifiers
            bm.transform(obj.matrix_world)
            bm.normal_update()
            bvh = BVHTree.FromBMesh(bm)  # ? not required to get with mod: obj.evaluated_get(depsgraph)
            bm.free()  # free and prevent further access
            obj_eval.to_mesh_clear()
            return bvh
        else:
            return BVHTree.FromObject(obj, depsgraph) #with modes
    else:
        if world_space:
            # 4 times slower than data.transform
            #bvh1 =  BVHTree.FromPolygons([obj.matrix_world @ v.co for v in obj.data.vertices], [p.vertices for p in obj.data.polygons])
            #bmesh - same time as data.transform
            obj.data.transform(obj.matrix_world)
            bvh = BVHTree.FromPolygons([v.co for v in obj.data.vertices], [p.vertices for p in obj.data.polygons])
            obj.data.transform(obj.matrix_world.inverted())
            return bvh
        else:
            return BVHTree.FromPolygons([v.co for v in obj.data.vertices], [p.vertices for p in obj.data.polygons])


def get_curve_points(polyline):
    if polyline.type == 'NURBS' or polyline.type == 'POLY':
        return [point.co.xyz for point in polyline.points]
    else:
        pts_count = len(polyline.bezier_points)
        if pts_count > 6:
            return [point.co.xyz for point in polyline.bezier_points]
        pointsList = []
        res = 4 if pts_count <= 3 else 3  # reduce resampling quality for more points
        for i in range(pts_count-1):
            inter = interpolate_bezier(polyline.bezier_points[i].co.xyz, polyline.bezier_points[i].handle_right.xyz,
                                       polyline.bezier_points[i+1].handle_left.xyz, polyline.bezier_points[i+1].co.xyz, res)
            pointsList.extend(inter[:-1])
        pointsList.append(inter[-1])
        return pointsList

def get_sel_splines_ids(curveObj):
    selectedSplines = []
    for spl_id, polyline in enumerate(curveObj.data.splines):
        if polyline.type == 'BEZIER':
            if any(point.select_control_point for point in polyline.bezier_points) and len(polyline.bezier_points) > 1:
                selectedSplines.append(spl_id)
        else:
            if any(point.select for point in polyline.points) and len(polyline.points) > 1:
                selectedSplines.append(spl_id)
    return selectedSplines


def add_driver(source, target, prop, dataPath, index=-1, negative=False, func=''):
    ''' Add driver to source prop (at index), driven by target dataPath '''
    d = source.driver_add(prop, index).driver if index != -1 else source.driver_add(prop).driver
    v = d.variables.new()
    v.name = prop
    v.targets[0].id = target
    v.targets[0].data_path = dataPath

    d.expression = func + "(" + v.name + ")" if func else v.name
    d.expression = d.expression if not negative else "-1 * " + d.expression


def angle_signed(vA, vB, vN):
    '''angle betwen a - b, is vN space '''
    a = vA.normalized()
    b = vB.normalized()
    adotb = a.dot(b)  # not sure why but cos(x) goes above 1, and below -1   if a= -b
    if a.dot(b) > 1:
        adotb = 1
    elif a.dot(b) < -1:
        adotb = -1
    angle = math.acos(adotb)
    cross = a.cross(b)
    if vN.dot(cross) < 0:  # // Or > 0
        angle = -angle
    return angle
