# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from os import path
import bmesh
from .utils.general_utils import link_obj_to_same_collections, import_node_group, unlink_from_scene, get_nested_node_groups, remap_node_groups
import random
from .utils.helper_functions import gold_random
from mathutils import Vector
import numpy as np

# DONE: add convert to meshs (with uv bake)
# DONE: drav UV box - make corner dragging better
# DONE: add different modes of mesh triangulation for hair mesh  - make steps interactive...
# DONE: re-import/refresh short_hair node gr
# DONE: convert to mesh and back
# TODO: UV width to rad -finish

short_hair_node_group = 'ShortHairGN'
short_hair_mod_name = 'Short Hair'
SHORT_HAIR_BLEND_FILE = path.dirname(__file__)+"\short_hair_geo_nodes.blend"


def import_short_hair_mat(mat_name, force_update=False):
    old_mat = bpy.data.materials.get(mat_name)
    if not old_mat or force_update:
        with bpy.data.libraries.load(SHORT_HAIR_BLEND_FILE) as (data_from, data_to):
            data_to.materials = [mat for mat in data_from.materials if mat == mat_name]

        if old_mat:
            old_mat.user_remap(data_to.materials[0])
            data_to.materials[0].name = mat_name

        return data_to.materials[0]
    else:
        return old_mat

def get_node_group(node_name):
    node_group = bpy.data.node_groups.get(node_name)
    if not node_group:
        import_node_group(node_name, lib_file=SHORT_HAIR_BLEND_FILE)    # XXX: does it actually works (node.name vs node.node_tree.name)
        node_group = bpy.data.node_groups.get(node_name)
    return node_group


def get_short_hair_mod(obj):
    guide_curve_mod = [m for m in obj.modifiers if m.type=='NODES' and m.node_group.name == short_hair_node_group]
    return guide_curve_mod[0] if guide_curve_mod else None

def three_d_bincount_add(out ,e_k, weights):
    out[:,0] += np.bincount(e_k, weights[:,0], out.shape[0])
    out[:,1] += np.bincount(e_k, weights[:,1], out.shape[0])
    out[:,2] += np.bincount(e_k, weights[:,2], out.shape[0])

def new_bincount(out, e_k, weights = None):
    out += np.bincount(e_k, weights, out.shape[0])


class HTOOL_OT_SetupShortHair(bpy.types.Operator):
    bl_idname = "object.setup_short_hair"
    bl_label = "Setup Short Hair"
    bl_description = "Great for animal fur but not only\nTo comb generated hair use sculpting tool on generated GUIDE object (it is drawn as bounding box)\nOnly for Blender 3.1 and above!"
    bl_options = {"REGISTER","UNDO"}

    smoothing: bpy.props.IntProperty(name="Initial Mesh Smoothing", description='Smooth hair base geometry - helps to even out generated hair distribution and normals', default= 1, min=0, max=6)
    apply_modifiers: bpy.props.BoolProperty(name="Apply Modifiers", description='Apply existing modifiers when generating hair base mesh', default= True)
    topology: bpy.props.EnumProperty(name='Remeshing Mode', description='Topology of generated base mesh has big influence on hair look and density',
        items=[
            ('KEEP', 'Use original', 'Keep mesh topology unchanged'),
            ('CELLS_TRIS', 'Triangulated Cells', 'Build mesth topology from Triangulated Veronoi cells. Gives nicest, even triangulation, but quite high-poly'),
            ('DIAMOND', 'Diamonds', 'Build topology from Diamond cells, lowpoly but not as even as Cells topology'),
            ('DIAMOND_TRIS', 'Triangulated Diamonds', 'Same As Diamond, gives slightly more tris, but with more even haircards density'),
        ], default='CELLS_TRIS')
    boundary: bpy.props.EnumProperty(name='Boundary', description='Pick smooth or shapr of boundary edges',
        items=[
            ('ALL', 'Smooth', 'Smooth boundary edges, when subdividing geometry'),
            ('PRESERVE_CORNERS', 'Keep Sharp', 'Keep share boundary edges, when subdividing geometry'),
        ], default='PRESERVE_CORNERS')


    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'apply_modifiers', icon='MODIFIER')
        layout.prop(self, 'topology')
        if self.topology != 'KEEP':
            layout.prop(self, 'smoothing')
            if self.topology == 'CELLS_TRIS':
                if bpy.app.version >= (3, 2, 0):
                    layout.prop(self, 'boundary')

    def numpy_smooth(self,bm, smooth=0.4, iters=5):
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        o_normal = np.array([vert.normal for vert in bm.verts])
        o_co =  np.array([vert.co for vert in bm.verts])
        vert_count =  len(bm.verts)

        edge_keys = np.array([[edge.verts[0].index, edge.verts[1].index] for edge in  bm.edges])
        freeze_verts = np.array([vert.is_boundary or not vert.is_manifold for vert in bm.verts]) #manifold for pocket sewing edges

        p_co = np.copy(o_co) #current new vertex position
        b_co_sum_neighbors = np.copy(o_co) #current new vertex position

        #sum edges that have vert X  and either end of edge (Va, Vb)
        v_connections = np.zeros(vert_count, dtype=np.float32)
        new_bincount(v_connections, edge_keys[:,1] )
        new_bincount(v_connections, edge_keys[:,0])

        alpha = 0.5   # Iriginal Vert co influence
        beta = 1 - smooth # 1 - smooth strength
        for _ in range(iters):
            q_co = np.copy(p_co) #prevoius iteration vert position
            p_co.fill(0)
            b_co_sum_neighbors.fill(0)
            #calc average position weighted...
            three_d_bincount_add(p_co, edge_keys[:,1], q_co[edge_keys[:,0]])
            three_d_bincount_add(p_co, edge_keys[:,0], q_co[edge_keys[:,1]])

            p_co = p_co / v_connections[:,None]   #new aver posision
            b_co = p_co - (alpha*o_co + (1-alpha) * q_co)  # difference

            #average of neibors vert differences
            three_d_bincount_add(b_co_sum_neighbors, edge_keys[:, 1], b_co[edge_keys[:, 0]])
            three_d_bincount_add(b_co_sum_neighbors, edge_keys[:, 0], b_co[edge_keys[:, 1]])

            p_co[freeze_verts] = q_co[freeze_verts] # not selected ver - reset to original pos o_co

            #project p_normal* p_normal.dot(b_sum)  # u(u dot v)  - projection of v on u
            #TO prevent border vert slide ahead of loop (caused by sum_b being to big.., so reduce it by projecting on vert normal)
            #projected b_sum on normal  - helps also stabilize noise...
            b_sum_projected_to_normal = np.einsum('ij,i->ij', o_normal, np.einsum('ij,ij->i', o_normal, b_co_sum_neighbors/v_connections[:, None]))
            p_co = p_co - (beta*b_co + (1-beta) * b_sum_projected_to_normal)
            p_co[freeze_verts] = q_co[freeze_verts]  # not selected ver - reset to original pos o_co

        for v in bm.verts:
            v.co = p_co[v.index]

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and not obj.ht_props.short_hair_props.is_short_hair

    def veronoi_cells_topo(self, bm):
        sel_verts = [v for v in bm.verts if len(v.link_edges) != 3]
        bm.select_mode = {'VERT', 'EDGE'}
        for v in bm.verts:
            v.select = False
        for v in sel_verts:
            v.select = True
        bm.select_flush_mode()
        bm.select_mode = {'EDGE'}
        del_edges = [e for e in bm.edges if e.select]
        bmesh.ops.dissolve_edges(bm, edges=del_edges, use_verts=True, use_face_split=True)
        bmesh.ops.poke(bm, faces=bm.faces, offset=0.1, center_mode='MEAN_WEIGHTED', use_relative_offset=True)
        # self.numpy_smooth(bm, smooth=0.5, iters=3, only_selected=False) # because smooth in subdivide_edges is not worksing...


    def diamond_topo(self, bm):
        bmesh.ops.poke(bm, faces=bm.faces, offset=0.1, center_mode='MEAN_WEIGHTED', use_relative_offset=True)
        # we will  dissolve edges with verts that have more than 4 edges
        sel_verts = [v for v in bm.verts if len(v.link_edges) > 4]
        bm.select_mode = {'VERT', 'EDGE'}
        for v in bm.verts:
            v.select = False
        for v in sel_verts:
            v.select = True
        bm.select_flush_mode()
        bm.select_mode = {'EDGE'}
        del_edges = [e for e in bm.edges if e.select]
        bmesh.ops.dissolve_edges(bm, edges=del_edges, use_verts=False, use_face_split=True)
        # remaining_sel_verts = [v for v in bm.verts if v.select]
        self.numpy_smooth(bm)
        # bmesh.ops.smooth_vert(bm, verts=remaining_sel_verts, factor=.8, mirror_clip_x=False, mirror_clip_y=False, mirror_clip_z=False, clip_dist=0.0, use_axis_x=True, use_axis_y=True, use_axis_z=True)
        # bmesh.ops.smooth_laplacian_vert(bm, verts=remaining_sel_verts, lambda_factor=3, lambda_border=1.5, use_x=True, use_y=False, use_z=False, preserve_volume=True)

    def vert_crease(self, obj):
        if bpy.app.version >= (3, 2, 0):
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            crease_lay = bm.verts.layers.crease.active # note: new in 3.2
            if not crease_lay:
                crease_lay = bm.verts.layers.crease.new()
                for _,v in enumerate(bm.verts):
                    if v.is_boundary:
                        v[crease_lay] = 1
                        # crease_data.data[i].value # get crease data
                bm.to_mesh(obj.data)
                bm.free()



    def rebuild_topo(self, obj):
        if self.topology == 'CELLS_TRIS': #we do this manually before bm, since there is no working bmesh subdivide smoothing
            obj.modifiers.new('TriangulateSH', 'TRIANGULATE')
            sub_surf_mod = obj.modifiers.new('SubShortHair', type='SUBSURF')
            # select all boundary vertices

            # NOTE: we can access, write to bmesh vert[crease_lay].val so this hack
            # crease_data = obj.data.vertex_creases[0]
            # TODO: use new bmesh vert crease api
            # for i in range(len(obj.data.vertices)):
            #     crease_data.data[i].value # get crease data

            if self.boundary == "PRESERVE_CORNERS": # because of triangulation some corners will be smooth. So we have to
                self.vert_crease(obj)

            sub_surf_mod.boundary_smooth = self.boundary

            sub_surf_mod.use_limit_surface = False
            sub_surf_mod.use_creases = True
            bpy.ops.object.modifier_apply(modifier='TriangulateSH')
            bpy.ops.object.modifier_apply(modifier='SubShortHair')

        me = obj.data
        bm = bmesh.new()   # create an empty BMesh
        bm.from_mesh(me)   # fill it in from a Mesh

        if self.topology == 'DIAMOND':
            self.diamond_topo(bm)
        elif self.topology == 'DIAMOND_TRIS':
            self.diamond_topo(bm)
            bmesh.ops.triangulate(bm, faces=bm.faces, quad_method='SHORT_EDGE', ngon_method='BEAUTY')
        elif self.topology == 'CELLS_TRIS':
            self.veronoi_cells_topo(bm)
            # bmesh.ops.triangulate(bm, faces=bm.faces, use_beauty=True)
        bm.to_mesh(me)
        bm.free()

        # additional post process since Cells uses Subsurf and shrinkgs geo
        #  (project on base, and smooth)
        if self.topology == 'CELLS_TRIS':
            project_mod = obj.modifiers.new('ProjectToBase', type='SHRINKWRAP')
            project_mod.target = self.base_obj
            project_mod.wrap_method = 'PROJECT'
            project_mod.wrap_mode = 'OUTSIDE'
            project_mod.subsurf_levels = self.boundary != "PRESERVE_CORNERS" # smooth if nnot preserve corners
            project_mod.use_negative_direction = False
            bpy.ops.object.modifier_apply(modifier='ProjectToBase')
            me = obj.data
            bm = bmesh.new()   # create an empty BMesh
            bm.from_mesh(me)
            # self.numpy_smooth(bm, iters=1, smooth=0.4)
            bm.to_mesh(me)
            bm.free()


    def execute(self, context):
        if bpy.app.version < (3, 1, 0):
            self.report({'ERROR'}, "This operation requires Blender 3.1 or higher")
            return {'CANCELLED'}
        obj = context.active_object
        self.base_obj = obj
        obj.select_set(False)

        hair_obj = obj.copy() #  short hair mod will remove base geo, so we need to copy it
        hair_obj.name = obj.name + '_short_hair'
        hair_obj.data = hair_obj.data.copy()

        if self.smoothing and self.topology != 'KEEP':
            me = hair_obj.data
            bm = bmesh.new()   # create an empty BMesh
            bm.from_mesh(me)   # fill it in from a Mesh
            self.numpy_smooth(bm, iters=self.smoothing)
            bm.to_mesh(me)
            bm.free()  # free and prevent further access

        link_obj_to_same_collections(obj, hair_obj)
        context.view_layer.objects.active = hair_obj
        hair_obj.select_set(True)

        if self.topology != 'KEEP':
            if self.apply_modifiers:
                bpy.ops.object.convert(target="MESH")
            self.rebuild_topo(hair_obj)

        # clear old materials
        for _ in range(len(hair_obj.data.materials)):
            mat = hair_obj.data.materials[-1]
            hair_obj.data.materials.pop() #new
            if mat and mat.users == 0:
                bpy.data.materials.remove(mat)

        guide_obj = hair_obj.copy()
        guide_obj.data = guide_obj.data.copy()
        seg_guide_ng = bpy.data.node_groups.get(short_hair_node_group)
        if not seg_guide_ng:
            seg_guide_ng = import_node_group(short_hair_node_group, SHORT_HAIR_BLEND_FILE)
            seg_guide_ng.use_fake_user = True

        short_hair_mod = hair_obj.modifiers.new(name=short_hair_mod_name, type='NODES')
        short_hair_mod.node_group = seg_guide_ng

        guide_obj.name = obj.name + '_hair_guide'
        guide_obj.display_type = 'BOUNDS' # 'WIRE'

        link_obj_to_same_collections(obj, guide_obj)
        short_hair_mod['Input_6'] = guide_obj # Deformer
        short_hair_mod['Output_10_attribute_name'] = 'UVMapGN' # Deformer
        short_hair_mod['Output_27_attribute_name'] = 'UV_Base' # Deformer
        short_hair_mod['Output_14_attribute_name'] = 'ColGN' # Deformer
        guide_obj.shape_key_add(name='Base')
        deform_key = guide_obj.shape_key_add(name='Deformer')
        guide_obj.active_shape_key_index = 1
        deform_key.value = 1

        # short_hair_mod['Input_7'] = 0.1  # Initial Length

        hair_mat_name = 'ShortHairMaterial'
        short_hair_mat = bpy.data.materials.get(hair_mat_name)
        if not short_hair_mat:
            short_hair_mat = import_short_hair_mat(hair_mat_name)
            short_hair_mat.use_fake_user = True
        hair_obj.data.materials.append(short_hair_mat)
        hair_obj.ht_props.short_hair_props.is_short_hair = True
        # XXX:
        # obj.material_slots[0].link = 'OBJECT'
        # guide_obj.material_slots[0].link = 'OBJECT'

        bpy.ops.object.geometry_nodes_input_attribute_toggle(prop_path="[\"Input_11_use_attribute\"]", modifier_name="Short Hair")
        short_hair_mod['Input_11_attribute_name'] = 'UV_Start'

        bpy.ops.object.geometry_nodes_input_attribute_toggle(prop_path="[\"Input_12_use_attribute\"]", modifier_name="Short Hair")
        short_hair_mod['Input_12_attribute_name'] = 'UV_End'
        start_uv_attr = hair_obj.data.attributes.get('UV_Start')
        if not start_uv_attr:
            start_uv_attr = hair_obj.data.attributes.new('UV_Start', 'FLOAT2','EDGE')
            start = (0,0)
            for edge in hair_obj.data.edges:
                start_uv_attr.data[edge.index].vector = start
        end_uv_attr = hair_obj.data.attributes.get('UV_End')
        if not end_uv_attr:
            end_uv_attr = hair_obj.data.attributes.new('UV_End', 'FLOAT2','EDGE')
            end = (1,1)
            for edge in hair_obj.data.edges:
                end_uv_attr.data[edge.index].vector = end
        update_all_edges_uvs(hair_obj)
        context.view_layer.objects.active = guide_obj
        guide_obj.select_set(True)
        return {'FINISHED'}



def set_uv_edge(obj, e_idx,  uv_start, uv_end):
    start_uv_attr = obj.data.attributes.get('UV_Start')
    if not start_uv_attr:
        start_uv_attr = obj.data.attributes.new('UV_Start', 'FLOAT2','EDGE')
    end_uv_attr = obj.data.attributes.get('UV_End')
    if not end_uv_attr:
        end_uv_attr = obj.data.attributes.new('UV_End', 'FLOAT2','EDGE')
    start_uv_attr.data[e_idx].vector = uv_start
    end_uv_attr.data[e_idx].vector = uv_end

def assing_sel_uv_boxes_to_edges(obj, sel_edges_ids, boxes_ids, seed):
    random.seed(seed)
    g_seed = random.random()  #cos we need float..
    box_cnt = len(boxes_ids)
    first_mat = obj.material_slots[0].material
    # switch to Edit mode if not already
    # if obj.mode != 'EDIT':
    #     bpy.ops.object.mode_set(mode='EDIT')
    for e_idx in sel_edges_ids:
        rand_idx = int(gold_random(e_idx, g_seed)*box_cnt)
        picked_box = boxes_ids[rand_idx]
        hair_uv_data = first_mat.ht_props.hair_uv_points[picked_box]
        set_uv_edge(obj, e_idx, hair_uv_data.start_point, hair_uv_data.end_point)
    # if obj.mode != 'OBJECT':
    #     bpy.ops.object.mode_set(mode='OBJECT')

def update_all_edges_uvs(obj):
    first_mat = obj.material_slots[0].material
    uvBoxes = len(first_mat.ht_props.hair_uv_points)
    boxes_ids = [int(box) for box in range(uvBoxes)]
    all_edges = [i for i in range(len(obj.data.edges))]
    assing_sel_uv_boxes_to_edges(obj, all_edges, boxes_ids, obj.ht_props.uv_seed)


BOX_ITEMS  = []
def uv_box_items(self, context):
    obj = context.active_object
    first_mat = obj.material_slots[0].material
    uvBoxes = len(first_mat.ht_props.hair_uv_points)
    global BOX_ITEMS
    if len(BOX_ITEMS) != uvBoxes:
        BOX_ITEMS = [(str(i), f'UV box {i}','') for i in range(uvBoxes)]
    return BOX_ITEMS

class HTOOL_OT_SetShortHairUvRegion(bpy.types.Operator):
    bl_idname = "hair.set_short_hair_uv_region"
    bl_label = "Set UV Region"
    bl_description = "Set selected edges UVs to specific region by its ID number"
    bl_options = {"REGISTER", "UNDO"}

    uv_regions: bpy.props.EnumProperty(name='UV Region ID', description='Pick UV region that will be assinged to selected strands',
                                   items=uv_box_items,  options={'ENUM_FLAG'})
    seed: bpy.props.IntProperty(name="Seed", description='Randomize how UV regions are assigned per selected strand',  default=0, min=0, max=1000)

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.ht_props.short_hair_props.is_short_hair and len(obj.data.materials)

    def draw(self, context):
        layout = self.layout
        if len(self.uv_regions) > 1:
            layout.prop(self, 'seed')
        layout.label(text='Select UVs that will be assigned to strands:')
        layout.prop(self, 'uv_regions')

    def invoke(self, context, event):
        global BOX_ITEMS
        BOX_ITEMS.clear()
        curve_obj = context.active_object
        self.uv_regions = set() #deselect by default all mats...
        self.seed = curve_obj.ht_props.uv_seed
        return self.execute(context)

    def execute(self, context):
        if not self.uv_regions:
            return {"FINISHED"}
        obj = context.active_object
        boxes_ids = [int(box) for box in self.uv_regions]
        bm = bmesh.from_edit_mesh(obj.data)
        sel_edges = [e.index for e in bm.edges if e.select]
        #switch to object mode or else attribute write will fail
        bpy.ops.object.mode_set(mode='OBJECT')
        assing_sel_uv_boxes_to_edges(context.active_object, sel_edges, boxes_ids, self.seed)
        obj.ht_props.uv_seed = self.seed
        bpy.ops.object.mode_set(mode='EDIT')

        return {"FINISHED"}


# operator of updating short_hair_node_group
class HTOOL_OT_UpdateShortHairNodeGroup(bpy.types.Operator):
    bl_idname = "hair.update_short_hair_node_group"
    bl_label = "Update Short Hair Node Group"
    bl_description = "Update (or Reset) Short Hair modifier node group,\nUsefull when you want to grab latest version of Short Hair modifier, after addon update"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        original_mats = {m.name: m for m in bpy.data.materials}
        original_node_groups = {node_group.name: node_group for node_group in bpy.data.node_groups}
        seg_guide_ng = import_node_group(short_hair_node_group, SHORT_HAIR_BLEND_FILE, force_update=True)
        seg_guide_ng.use_fake_user = True

        new_mat = None
        for m in bpy.data.materials:
            if m.name not in original_mats:
                new_mat = m
                print(new_mat)
                break

        hair_mat_inner_node_groups = get_nested_node_groups(new_mat.node_tree)
        remap_node_groups(hair_mat_inner_node_groups, original_node_groups)

        remap_node_groups([new_mat], original_mats, data_type='materials')
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and obj.ht_props.short_hair_props.is_short_hair:
                short_hair_mod = obj.modifiers.get('ShortHair')
                if short_hair_mod:
                    short_hair_mod['Output_10_attribute_name'] = 'UVMapGN' # Deformer
                    short_hair_mod['Output_27_attribute_name'] = 'UV_Base' # Deformer
                    short_hair_mod['Output_14_attribute_name'] = 'ColGN' # Deformer
        # short_hair_mat_name = 'ShortHairMaterial'
        # if new_mat:
        #     for obj in bpy.data.objects:
        #         short_hair_mod = obj.modifiers.get(short_hair_mod_name)
        #         if short_hair_mod:
        #             short_hair_mod['Input_16'] = new_mat.name
        return {"FINISHED"}


# oferator wthat will apply modifiers, and write uv attribute to uv
class HTOOL_OT_ConvertShortHairToMesh(bpy.types.Operator):
    bl_idname = "hair.convert_short_hair_to_mesh"
    bl_label = "Convert Short Hair To Mesh"
    bl_description = "Apply Short Hair modifier and write uvs"
    bl_options = {"REGISTER", "UNDO"}

    # @classmethod
    # def poll(self, context):  # make selection only false, if obj mode
    #     obj = context.active_object
    #     return obj and obj.type == 'MESH'

      # free and prevent further access

    @staticmethod
    def write_col_attrib(obj):
        gn_col = obj.data.attributes.get('ColGN')
        if not gn_col:
            return
        col_array = np.empty((len(gn_col.data)*4), dtype=np.float32)
        gn_col.data.foreach_get('color', col_array)

        mesh_vcol = obj.data.vertex_colors.get('Col')
        if not mesh_vcol:
            mesh_vcol = obj.data.vertex_colors.new(name='Col')
        mesh_vcol.data.foreach_set("color", np.power(col_array, 1/2.2))
        #for f in obj.data.polygons:
        #   for loop_idx in f.loop_indices:
        #      mesh_vcol.data[loop_idx].color = gn_col.data[loop_idx].color

        # bm = bmesh.new()   # create an empty BMesh
        # me = obj.data
        # bm.from_mesh(me)   # fill it in from a Mesh
        # color_layer = bm.loops.layers.color.get("Col")
        # if not color_layer:
        #     color_layer = bm.loops.layers.color.new("Col")
        #
        # for v in bm.verts:
        #     for loop in v.link_loops:
        #          loop[color_layer] = np.power(gn_col.data[v.index].color[:], 1/2.2)
        # bm.to_mesh(me)
        # bm.free()  # free and prevent further access
        #
    @staticmethod
    def write_uv_attrib(obj):
        # XXX: create uvs before acessing UVMapGN or writing wont work
        default_uv = obj.data.uv_layers.get('UVMap')
        if not default_uv:
            default_uv = obj.data.uv_layers.new()

        # XXX: has to be second after uv_lays.get or write error.
        gn_uv = obj.data.attributes.get('UVMapGN')
        if not gn_uv:
            print('Cant Read UVMapGN attribute. Make sure shorth hair modifier UVs output is set to "UVMapGN"')
            return

        # write gn_uv to numpy array
        uv_array = np.empty((len(gn_uv.data)*3), dtype=np.float32)
        gn_uv.data.foreach_get('vector', uv_array)

        # remove every third element form numpy array
        uv_array = uv_array.reshape((len(gn_uv.data), 3))
        uv_array = uv_array[:, :2] # only copy x,y  (first 2 elements)

        # write uvs using foreach_set
        default_uv.data.foreach_set('uv', uv_array.ravel())
        # for f in obj.data.polygons:
        #    for loop_idx in f.loop_indices:
        #        default_uv.data[loop_idx].uv = gn_uv.data[loop_idx].vector.xy



        base_uv = obj.data.uv_layers.get('HairTool_UV')
        if not base_uv:
            base_uv = obj.data.uv_layers.new(name='HairTool_UV')

        gn_uv_base = obj.data.attributes.get('UV_Base')
        if not gn_uv_base:
            print('Cant Read UV_Base attribute. Make sure shorth hair modifier UVs output is set to "UV_Base"')
            return

        # write gn_uv_base to numpy array
        uv_array = np.empty((len(gn_uv_base.data)*3), dtype=np.float32)
        gn_uv_base.data.foreach_get('vector', uv_array)

        # remove every third element form numpy array
        uv_array = uv_array.reshape((len(gn_uv_base.data), 3))
        uv_array = uv_array[:, :2] # only copy x,y  (first 2 elements)

        # write uvs using foreach_set
        base_uv.data.foreach_set('uv', uv_array.ravel())

    def short_hair_mod_apply(self, context, obj):
        short_hair_mod = obj.modifiers.get(short_hair_mod_name)
        if not short_hair_mod:
            return
        target_obj = obj.copy()
        target_obj.data = obj.data.copy()
        target_obj.name = obj.name+'_short_hair'
        link_obj_to_same_collections(obj, target_obj)
        target_obj.ht_props.short_hair_props.is_short_hair = False
        target_obj.ht_props.short_hair_props.is_short_hair_output = True

        unlink_from_scene(obj)
        obj.use_fake_user = True

        context.view_layer.objects.active = target_obj
        target_obj.select_set(True)
        bpy.ops.object.modifier_apply(modifier="Short Hair")

        #NOTE:  GNodes mod creates additional mat slot. Remove first one (empty)
        bpy.ops.object.material_slot_remove()
        self.write_uv_attrib(target_obj)
        self.write_col_attrib(target_obj)
        target_obj.ht_props.short_hair_props.hair_base_mesh = obj.name

        guide_obj = short_hair_mod['Input_6'] # Deformer
        if guide_obj:
            guide_obj.use_fake_user = True
            unlink_from_scene(guide_obj)


    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH' and obj.ht_props.short_hair_props.is_short_hair:
                short_hair_mod = obj.modifiers.get(short_hair_mod_name)
                if not short_hair_mod:
                    self.report({'ERROR'}, f'{short_hair_mod_name} modifier not found. Skipping {obj.name}')
                    continue
                self.short_hair_mod_apply(context, obj)

            self.report({'INFO'}, f'{obj.name} converted to mesh')

        return {"FINISHED"}


# operator to restore short hair base mesh
class HTOOL_OT_RestoreShortHairBaseMesh(bpy.types.Operator):
    bl_idname = "object.restore_short_hair_base_mesh"
    bl_label = "Restore Short Hair Base Mesh"
    bl_description = "Restore short hair base mesh"

    @classmethod
    def poll(self, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.ht_props.short_hair_props.hair_base_mesh

    def execute(self, context):
        short_hair_converted = context.active_object
        # bring back base mesh
        base_obj_name = short_hair_converted.ht_props.short_hair_props.hair_base_mesh
        base_mesh = bpy.data.objects.get(base_obj_name)
        if not base_mesh:
            return {"CANCELLED"}

        link_obj_to_same_collections(short_hair_converted, base_mesh)
        base_mesh.matrix_world = short_hair_converted.matrix_world
        base_mesh.use_fake_user = False
        base_mesh.select_set(True)

        context.view_layer.objects.active = base_mesh

        short_hair_mod = base_mesh.modifiers.get(short_hair_mod_name)
        if short_hair_mod:
            guide_obj = short_hair_mod['Input_6'] # Deformer
            if guide_obj:
                guide_obj.use_fake_user = True

                link_obj_to_same_collections(short_hair_converted, guide_obj)
                guide_obj.matrix_world = short_hair_converted.matrix_world
                guide_obj.use_fake_user = False
                guide_obj.select_set(True)

        bpy.data.objects.remove(short_hair_converted)

        return {'FINISHED'}

