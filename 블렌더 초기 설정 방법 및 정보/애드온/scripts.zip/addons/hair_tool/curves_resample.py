# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import numpy as np
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty)
from mathutils import Vector
from copy import deepcopy
from statistics import median
from .material_operators import HTOOL_OT_CurvesUVRefresh
# from .resample2d import interpol_Catmull_Rom_splines
from .utils.curve_wrapper import Splines, Point
from .utils.helper_functions import calc_pow_inverted, clamp


class HTOOL_OT_CurvesResample(bpy.types.Operator):
    bl_label = "Resample"
    bl_idname = "object.curve_resample"
    bl_description = "Change amount of points on curve"
    bl_options = {"REGISTER", "UNDO"}


    # bezierRes: IntProperty(name="Bezier resolution", default=3, min=1, max=12)
    out_pts_count: IntProperty(name="Points per strand", default=8, min=3, soft_max=20)
    uniformPointSpacing: BoolProperty(name="Uniform spacing", description="Distribute stand points with uniform spacing", default=False)
    equalPointCount: BoolProperty(name="Equal point count", description="Give all cures same points count \n"
                                   "If disabled shorter curves will have less points", default=False)
    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=False)
    offset_tip: FloatProperty(name="Offset to tip", description="Move spline points more toward tip",
                                   default=0, min=0, max=1, subtype='PERCENTAGE')
    offset_root: FloatProperty(name="Offset to root", description="Move spline points more toward root",
                                   default=0, min=0, max=1, subtype='PERCENTAGE')
    scale_strand: FloatProperty(name="Strand Length", description="Increase or decrease strand lenght in %",
                                   default=100, min=0, max=200, subtype='PERCENTAGE')
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'out_pts_count')
        layout.prop(self, 'uniformPointSpacing')
        layout.prop(self, 'equalPointCount')
        layout.prop(self, 'onlySelection')
        layout.prop(self, 'offset_tip')
        layout.prop(self, 'offset_root')
        if not self.uniformPointSpacing:
            layout.prop(self, 'scale_strand')

    def invoke(self, context, event):
        curve_obj = context.active_object
        self.scale_strand = 100
        # if curve_obj.data.splines[0].type == 'NURBS':
        #     self.nurbs_order = curve_obj.data.splines[0].order_u

        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.onlySelection = True if curve_obj.mode == 'EDIT' else called_from_ht_wspace

        self.sel_splines = Splines(curve_obj, onlySelection=self.onlySelection, spline_type='FLAT')
        self.out_pts_count = round(median([s.length for s in self.sel_splines.splines]))
        bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        return self.execute(context)

    def execute(self, context):
        if self.uniformPointSpacing: #disable strand length adjustment for uniform spacing
            self.scale_strand = 100
        curve_obj = context.active_object
        splines = deepcopy(self.sel_splines)
        if self.offset_tip or self.offset_root:
            offset_tip_tns = calc_pow_inverted(self.offset_tip+1, self.out_pts_count)
            custom_tns = np.power(offset_tip_tns, self.offset_root+1)*self.scale_strand/100
        else:
            custom_tns = np.linspace(0, self.scale_strand/100, self.out_pts_count)

        splines.resample_splines(res=self.out_pts_count, uniform_spacing=self.uniformPointSpacing, same_point_count=self.equalPointCount, tn_fallof=custom_tns)
        splines.write_splines_to_blender(curve_obj)

        if curve_obj.data.taper_object:  #? to fix mat_overrides
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(curve_obj, refresh_everything=False) #only refresh mat slot ids
        return {"FINISHED"}


class HTOOL_OT_CurvesLength(bpy.types.Operator):
    bl_label = "Adjust Length"
    bl_idname = "object.curve_length"
    bl_description = "Change hair strand length"
    bl_options = {"REGISTER", "UNDO"}

    # bezierRes: IntProperty(name="Bezier resolution", default=3, min=1, max=12)
    onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=False)
    readjust_point_count: BoolProperty(name="Readjust point count", description="When disabled, strand point count won't change", default=False)
    scale_strand: FloatProperty(name="Strand Length", description="Increase or decrease strand lenght in %",
                                default=100, min=30, soft_max=150, subtype='PERCENTAGE')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def invoke(self, context, event):
        self.scale_strand = 100
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"

        self.onlySelection = True if context.active_object.mode == 'EDIT' else called_from_ht_wspace
        self.sel_splines = Splines(context.active_object, onlySelection=self.onlySelection, spline_type='FLAT')  # Flat will auto resample tilt, radius
        self.pt_cnt = [s.length for s in self.sel_splines.splines]
        self.euclid_len = [s.euclidean_len for s in self.sel_splines.splines]# reduce growth on long strands, or else they blow too fast
        self.t_spat = []
        for spl in self.sel_splines.splines:
            seg_lens = np.apply_along_axis(np.linalg.norm, 1, spl.points_co[:-1, :]-spl.points_co[1:, :])  # do an - an-1 and get length
            t_spat = np.insert(seg_lens, 0, 0).cumsum()  # add zero and sum
            self.t_spat.append(t_spat/t_spat[-1])  # it will be now proportional to segments distances - bigger point spacing - more time.

        bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        return self.execute(context)

    def execute(self, context):
        curve_obj = context.active_object
        splines = deepcopy(self.sel_splines)

        max_e_len = max(self.euclid_len)
        for e_len, t_spat, pts_cnt, spl in zip(self.euclid_len, self.t_spat, self.pt_cnt, splines.splines):
            t_range = pts_cnt - 1.01
            tn_new = self.scale_strand/100*t_range  # adjust tn to get even spacing
            if self.scale_strand > 100:
                #* make long hair glow slower
                extra_t = tn_new - t_range
                grow_mul = max_e_len/e_len
                if self.readjust_point_count:
                    tn_new = t_range + extra_t * grow_mul
                    # pts_cnt / t_range = extra_pts / extra_t => extra_pts = pts_cnt * extra_t / t_range
                    extra_pts = int(grow_mul * pts_cnt * extra_t / t_range)
                    new_tns = np.linspace(t_range, tn_new, extra_pts, endpoint=False)
                    if new_tns.shape[0]:
                        new_tns = new_tns + (tn_new-new_tns[-1])
                        new_pts = np.array([spl.evaluate_at(new_t) for new_t in new_tns], 'f')
                        spl.points_co = np.append(spl.points_co, new_pts, axis=0)
                    else:
                        spl.points_co[-1] = spl.evaluate_at(tn_new)
                else:
                    cut_t = grow_mul*(self.scale_strand / 100-1)+1
                    new_tns = np.linspace(0, cut_t, pts_cnt, endpoint=True)
                    spl.resample_pts(pts_cnt, uniform=False, t_custom=new_tns)

            elif self.scale_strand < 100:
                t_cut = self.scale_strand / 100 #TODO: get in spatial time
                def find_nearest_id(array, value):
                    idx = np.abs(array - value).argmin()
                    return idx-1
                if self.readjust_point_count:
                    #fix t to spatial t
                    tspat_vals = np.linspace(0, 1, pts_cnt, endpoint=True)  # len(tspat_vals) == len(t_spat)
                    corr_t_cut = np.interp(t_cut, tspat_vals, t_spat)   # sample tspat_vals from spatial spacing t_spat, to t_in res,

                    cut_pid = find_nearest_id(t_spat, corr_t_cut)

                    spl.points_co[cut_pid+1] = spl.evaluate_at(tn_new)
                    spl.points_co = spl.points_co[0:cut_pid+2]  # remove pts after cut_pid+1
                    spl.points_radii = spl.points_radii[0:cut_pid+2]  # remove pts after cut_pid+1
                    # spl.points_tilts = spl.points_radii[0:cut_pid+2]  # remove pts after cut_pid+1
                else:
                    new_tns = np.linspace(0, t_cut, pts_cnt, endpoint=True)
                    spl.resample_pts(pts_cnt, uniform=False, t_custom=new_tns)

        splines.write_splines_to_blender(curve_obj)
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        if called_from_ht_wspace: # reselect points
            offset = context.scene.ht_props.select_offset
            active_end = context.scene.ht_props.active_end
            for spl in splines.splines:
                b_spl = curve_obj.data.splines[spl.orig_spl_id]

                pts = b_spl.points if b_spl.type in {'NURBS', 'POLY'} else b_spl.bezier_points
                last_pid = len(pts)-1
                p_id = clamp(last_pid - offset, 0, last_pid) if active_end == "TIPS" else clamp(offset, 0, last_pid)
                if b_spl.type in {'NURBS', 'POLY'}:
                    pts[p_id].select = True
                else:
                    pts[p_id].select_control_point = True

        return {"FINISHED"}
