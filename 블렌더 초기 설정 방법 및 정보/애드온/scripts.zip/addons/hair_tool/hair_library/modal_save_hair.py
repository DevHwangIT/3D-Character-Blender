# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bgl
import blf
import time
import os
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader

import subprocess
from ..utils.general_utils import get_addon_preferences
from . import hair_lib

shader_2d = gpu.shader.from_builtin('2D_UNIFORM_COLOR')


vertex_shader = '''
    in vec2 position;
    in vec2 uv;

    out vec2 uvInterp;

    void main()
    {
        uvInterp = uv;
        gl_Position = vec4(position, 0.0, 1.0);
    }
'''

fragment_shader = '''
    uniform sampler2D image;

    in vec2 uvInterp;
    out vec4 FragColor;

    void main()
    {
        vec4 img = texture(image, uvInterp);
        FragColor = blender_srgb_to_framebuffer_space(vec4(pow(img.rgb, vec3(0.3)), img.a));
    }
'''
shader_img_post = gpu.types.GPUShader(vertex_shader, fragment_shader)
batch = batch_for_shader(
    shader_img_post, 'TRI_FAN',
    {
        "position": ((-1, -1), (1, -1), (1, 1), (-1, 1)),
        "uv": ((0, 0), (1, 0), (1, 1), (0, 1)),
    },
)


def draw_background_box(width, height):
    x0 = 5
    y0 = 60

    vertices = (
        (x0, y0), (width, y0),
        (x0, height), (width, height))
    indices = ((0, 1, 2), (2, 1, 3))
    bgl.glEnable(bgl.GL_BLEND)
    batch = batch_for_shader(shader_2d, 'TRIS', {"pos": vertices}, indices=indices)
    shader_2d.bind()
    shader_2d.uniform_float("color", (0., 0., 0., 0.3))
    batch.draw(shader_2d)
    bgl.glDisable(bgl.GL_BLEND)

def draw_callback_px(self, context):
    font_id = 0
    draw_background_box(370, 180)

    blf.size(font_id, 22, 65)
    blf.position(font_id, 25, 155, 0)
    blf.draw(font_id, "Generating Thumbnail for preset")
    blf.size(font_id, 16, 60)
    blf.position(font_id, 25, 135, 0)
    blf.draw(font_id, "Draw rectangle with LMB in 3D View")
    blf.position(font_id, 25, 115, 0)
    blf.draw(font_id, "Drag corner points to adjust box size")
    blf.position(font_id, 25, 95, 0)
    blf.draw(font_id, "ENTER - confirm and save hair")
    blf.position(font_id, 25, 75, 0)
    blf.draw(font_id, "ESC / RMB - Cancel")

    bgl.glPointSize(6)
    if self.state in ['second_point', 'box_finished', 'tweak_box']:
        start_point = self.mouse_start
        end_point = self.mouse_end if self.mouse_end else self.mouse_pos

        coords = [(start_point[0], start_point[1]), (start_point[0], end_point[1]),
                    (end_point[0], end_point[1]), (end_point[0], start_point[1]),
                    (start_point[0], start_point[1])]

        batch = batch_for_shader(shader_2d, 'LINE_STRIP', {"pos": coords})
        shader_2d.bind()
        shader_2d.uniform_float("color", (0.7, 0.7, 0.7, 1))
        batch.draw(shader_2d)

        coords_points = [(start_point[0], start_point[1]),  (end_point[0], end_point[1])]
        batch = batch_for_shader(shader_2d, 'POINTS', {"pos": coords_points})
        shader_2d.bind()
        batch.draw(shader_2d)

        bgl.glPointSize(1)


def screen_grab_new(self, output_png_path):
    if hasattr(self, 'fin') and  not self.fin:
        self.fin = True
        img_name = 'vieport_thumb_oqn'
        x = min(self.mouse_start[0], self.mouse_end[0]) #+ context.region.x # to get absolute window co
        y = min(self.mouse_start[1], self.mouse_end[1]) #+ context.region.y  # to get absolute window co
        width = max(self.mouse_start[0], self.mouse_end[0]) - x  #+ context.region.x # to get absolute window co
        height = max(self.mouse_start[1], self.mouse_end[1]) - y # + context.region.y  # to get absolute window co
        # print([x,y, width, height])
        img = bpy.data.images.get(img_name)
        if not img:
            img = bpy.data.images.new(img_name , width, height, alpha=True)
        else:
            img.scale(width, height)

        #read current viewport to pixle buff.
        pixelBuffer = bgl.Buffer(bgl.GL_FLOAT, width * height * 4)
        bgl.glReadPixels(x, y, width, height, bgl.GL_RGBA, bgl.GL_FLOAT, pixelBuffer)

        # img.pixels.foreach_set(pixelBuffer)
        # pixels = np.array(pixelBuffer, dtype='f').reshape(width, height, 4)  # RGBA
        img.pixels = np.power(pixelBuffer, 0.454) # we should split Alpha in theory but the effect is cool this way
        avg_size = (width + height)/2
        k = 180 / avg_size
        img.scale(int(width * k), int(height * k))
        img.filepath_raw = output_png_path  # blender needs slash at end
        img.save()
        bpy.data.images.remove(img)

    self.fin = True

class GT_OT_ModalLibStore(bpy.types.Operator):
    bl_idname = "hair_lib.save_hair"
    bl_label = "Store hair"
    bl_description = "Save selected scene hair(s) to library"
    bl_options = {"REGISTER"}

    with_screen_grab: bpy.props.BoolProperty(name='With screen grab', description='With screen grab',  default=False)

    file_exits = False
    confirm_ask = True
    #for modal (with_screen_grab) version
    _handle = None
    mouse_start = False
    mouse_end = False
    mouse_pos = []  # we need it to pass as self.mouse_pos to draw handler
    state = 'first_point'

    def modal(self, context, event):
        if self.fin:
            context.area.tag_redraw()
            bpy.types.SpaceView3D.draw_handler_remove(self._handle_scgrab, 'WINDOW')
            hair_lib.FORCE_UPDATE_THUMBS = True
            self.report({'INFO'}, 'Export was successful')
            return {'FINISHED'}
        context.area.tag_redraw()
        if event.type == 'MOUSEMOVE':
            self.mouse_pos = [event.mouse_region_x, event.mouse_region_y]
            if self.state == 'tweak_box':
                x = event.mouse_region_x
                y = event.mouse_region_y
                delta = 33
                if x-delta < self.mouse_start[0] < x + delta and y-delta < self.mouse_start[1] < y + delta:
                    self.mouse_start = [x, y]
                elif x-delta < self.mouse_end[0] < x + delta and y-delta < self.mouse_end[1] < y + delta:
                    self.mouse_end = [x, y]


        if self.state == 'first_point' and event.type == 'LEFTMOUSE' and event.value == 'PRESS':  # PRESS
            self.mouse_start = [event.mouse_region_x, event.mouse_region_y]
            self.state = 'second_point'

        elif self.state == 'second_point' and event.type == 'LEFTMOUSE' and event.value == 'RELEASE':  # finish drawing box, and calculate uv Transformation
            self.mouse_end = [event.mouse_region_x, event.mouse_region_y]
            self.state = 'box_finished'

        elif self.state == 'box_finished' and event.type == 'LEFTMOUSE' and event.value == 'PRESS':  # finish drawing box, and calculate uv Transformation
            self.state = 'tweak_box'

        elif self.state == 'tweak_box' and event.type == 'LEFTMOUSE' and event.value == 'RELEASE':  # finish drawing box, and calculate uv Transformation
            self.state = 'box_finished'

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self._handle:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self.report({'INFO'}, 'CANCELLED')
            return {'CANCELLED'}

        elif event.type in {'NUMPAD_ENTER', 'RET'} and event.value == 'PRESS':
            if self._handle:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            context.area.tag_redraw()
            output_blend_file = save_hair_to_blend(context)
            output_png = output_blend_file[:-6] + ".png"
            # self.screen_grab(context, output_png)
            # enum_previews_from_directory_items(self, context)
            self._handle_scgrab = bpy.types.SpaceView3D.draw_handler_add(screen_grab_new, (self,output_png), 'WINDOW', 'PRE_VIEW') # this draws the viewport objects alone (without grid)
            context.area.tag_redraw()


        elif event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            # allow navigation
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.confirm_ask = True
        self.fin = False
        return context.window_manager.invoke_props_dialog(self)


    def run_mod(self, context):
        ''''Run modal save, with scrreen grab'''

        self.startTime = time.time()
        self.fin = False
        self.state = 'first_point'
        self.mouse_pos = [0, 0]
        self.mouse_start = False
        self.mouse_end = False
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Draw box shape 3D View')
        return {'RUNNING_MODAL'}


    def draw(self, context):
        layout = self.layout
        if self.file_exits:
            layout.label(text='File already exist. Pressing Ok will override it!')
        else:
            layout.prop(context.scene.ht_props, "export_merged_name", text='Name')
            # row.prop(g_props, 'save_with_screen_grab', icon='IMAGE_PLANE', text='')

    def execute(self, context):
        if self.with_screen_grab:  # run modal screen grab
            prefs = get_addon_preferences()
            if not context.selected_objects:  # there is always at leas one hair. Bug usera may chave not choose any
                self.report({'ERROR'}, 'Nothing was selected for export! Cancelling')
                return {'CANCELLED'}

            g_prop = context.scene.ht_props
            prefs = get_addon_preferences()

            current_folder = os.path.join(prefs.lib_path, g_prop.lib_relative_sub_path)
            blend_name = g_prop.export_merged_name
            output_blend_file = os.path.join(current_folder, blend_name+'.blend')

            self.file_exits = os.path.isfile(output_blend_file)
            if self.file_exits and self.confirm_ask: #ask just once if override
                self.confirm_ask = False
                return context.window_manager.invoke_props_dialog(self)
            self.run_mod(context)
            return {'RUNNING_MODAL'}

        output_blend_file = save_hair_to_blend(context)
        render_preview_background(context, output_blend_file)
        # enum_previews_from_directory_items(self, context)
        bpy.app.timers.register(delayed_thumbs_update, first_interval=3)  # delay for background finish render preview. Then update

        self.report({'INFO'}, 'Export was successful')
        return {"FINISHED"}

def render_preview_background(context, blend_file):
    command = [bpy.app.binary_path,
               blend_file,
               '-b',
               '--python',
               os.path.join(os.path.dirname(os.path.realpath(__file__)), 'generate_thumb.py')]
    subprocess.Popen(command)


def delayed_thumbs_update():
    hair_lib.FORCE_UPDATE_THUMBS = True


def save_hair_to_blend(context):
    g_prop = context.scene.ht_props  # if multiple hairs, then get selected for export from here
    prefs = get_addon_preferences()
    current_folder = os.path.join(prefs.lib_path, g_prop.lib_relative_sub_path)
    exp_scene = bpy.data.scenes.new('hair_export')

    for obj in context.selected_objects:
        exp_scene.collection.objects.link(obj)

    data_blocks = set([exp_scene])
    blend_name = g_prop.export_merged_name
    output_blend_file = os.path.join(current_folder, blend_name+'.blend')
    bpy.data.libraries.write(output_blend_file, data_blocks, fake_user=True)
    # bpy.data.scenes.remove(exp_scene)
    return output_blend_file
