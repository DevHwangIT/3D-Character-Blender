'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO (loosely based on 'dynamic enum' blender template and Simple Asset Manager)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import os
import sys
import shutil
import subprocess
from math import pi

import bpy

import bpy.utils.previews
from bpy.app.handlers import persistent
from ..utils.general_utils import get_addon_preferences


preview_collections = {} #reseted after F8. Fix?
FORCE_UPDATE_THUMBS = False  # True (eg. when performing operations on folders) to force update FOLDER_ITEMS
CHECK_FOR_FILE_CHANGES = False  # set True every 2 sec, by periodic Timers to force update FOLDER_ITEMS
FORCE_UPDATE_FOLDERS = False  # to force update FOLDER_ITEMS even if is cached (eg. when performin operaton)


def purge(data):
    # RENDER PREVIEW SCENE PREPARATION METHODS
    for el in data:
        if el.users == 0:
            data.remove(el)


def prepare_scene(filepath):
    # clean scene
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=True)
    purge(bpy.data.collections)
    purge(bpy.data.objects)
    purge(bpy.data.particles)
    purge(bpy.data.materials)
    purge(bpy.data.textures)
    purge(bpy.data.images)
    purge(bpy.data.collections)
    # set output
    eevee = bpy.context.scene.eevee
    render = bpy.context.scene.render
    eevee.use_ssr_refraction = True
    eevee.use_ssr = True
    eevee.use_gtao = True
    eevee.gtao_distance = 1


    render.filepath = filepath
    render.engine = 'CYCLES'
    bpy.context.scene.cycles.film_transparent = True
    render.alpha_mode = 'TRANSPARENT'
    render.resolution_x = 150
    render.resolution_y = 150
    render.image_settings.color_mode = 'RGBA'
    render.image_settings.color_mode = 'PNG'
    bpy.context.scene.cycles.samples = 32
    bpy.context.scene.cycles.max_bounces = 2
    if 'render_export' not in bpy.data.worlds.keys():
        world = bpy.data.worlds.new(name='render_export')
    else:
        world = bpy.data.worlds['render_export']
    world.use_nodes = False
    world.color = (1, 1, 1)
    bpy.context.scene.world = world


def add_camera():
    bpy.ops.object.camera_add(rotation=(pi / 2, 0, -pi / 6))
    cam = bpy.context.active_object
    cam.data.shift_y = -.3
    cam.data.lens = 71
    bpy.data.scenes[0].camera = cam
    bpy.ops.view3d.camera_to_view_selected()
    cam.data.lens = 70



def append_element(blendFile):
    coll_name = os.path.splitext(os.path.basename(blendFile))[0].title()
    obj_coll = bpy.data.collections.new(coll_name)
    active_scene = bpy.context.scene
    active_scene.collection.children.link(obj_coll)
    orig_mats_li = bpy.data.materials.keys()
    with bpy.data.libraries.load(blendFile) as (data_from, data_to):
        # scenes = [{'name': name} for name in data_from.scenes]
        # data_to.scenes = data_from.scenes
        dupli_mats = [name for name in data_from.materials if name in orig_mats_li]
        new_unique_mats = [name for name in data_from.materials if name not in orig_mats_li]
        data_to.objects = data_from.objects
        # in_mats = [{'name': name} for name in data_from.materials]
    # bpy.ops.wm.append(directory=blendFile + "/Scene/", files=scenes)
    # imp_scene = bpy.data.scenes[scenes[0]['name']]

    del_fe_male_driver = None # remove [Fe]Male driver
    bevel_curves = [] # hide bevel profile curves
    for obj in data_to.objects:
        obj_coll.objects.link(obj)
        #try using original material from scene, if we imported mat with same name
        if obj.data:
            for mat in obj.data.materials:
                if mat.name not in new_unique_mats: #means we imported same material 2x
                    if mat.name[:-4] in orig_mats_li:
                        mat.user_remap(bpy.data.materials[mat.name[:-4]])
        if obj.name == '[Fe]Male':
            del_fe_male_driver = obj
        if obj.name.startswith('bevelCurve'):
            bevel_curves.append(obj)
    for bc in bevel_curves:
        # override = {'active_object': bc}
        #XXX:  bpy.ops.object.ribbon_close_profile(override) gives crash so do it manually
        for col in bc.users_collection:
            col.objects.unlink(bc)
        if bc.name in bpy.context.scene.collection.objects.keys():
            bpy.context.scene.collection.objects.unlink(bc)
        bc.use_fake_user = True

    if del_fe_male_driver:
        bpy.data.objects.remove(del_fe_male_driver)
    # bpy.data.scenes.remove(imp_scene)



def enum_previews_from_directory_items(self, context):
    global FORCE_UPDATE_THUMBS
    global CHECK_FOR_FILE_CHANGES
    enum_items = []
    prefs = get_addon_preferences()
    g_prop = context.scene.ht_props
    directory = os.path.join(prefs.lib_path, g_prop.lib_relative_sub_path)
    if context is None or not os.path.exists(directory):
        return enum_items

    # Get the preview collection (defined in register func).
    pcoll = preview_collections["main"]
    if not FORCE_UPDATE_THUMBS:
        if directory == pcoll.hair_lib_prev_dir:  # we are is same folder so in theory no need to reload icons
            if CHECK_FOR_FILE_CHANGES:  # * set true by timers every 2 sec
                CHECK_FOR_FILE_CHANGES = False
                # print('Checking if new file count changed since last time')
                png_in_folder_count = len([name for name in os.listdir(directory) if name.endswith('.png')])  # but check if there was new file
                if directory in pcoll.png_in_dir_count.keys() and pcoll.png_in_dir_count[directory] == png_in_folder_count:
                    return pcoll.hair_lib_prevs
                else:
                    pcoll.png_in_dir_count[directory] = png_in_folder_count
            else:
                return pcoll.hair_lib_prevs

    pcoll.clear()
    # print("Scanning directory: %s" % directory)
    empty_path = os.path.join(os.path.dirname(__file__), 'empty.png')
    if directory and os.path.exists(directory):
        image_paths = scan_for_elements(directory)
        enum_items = get_thumbnails(image_paths, enum_items, pcoll, empty_path, directory)
    # Return validation
    if len(enum_items) == 0:  # to prevent error - list empty... it seems
        empty_thumb = pcoll['empty_ico'] if 'empty_ico' in pcoll else pcoll.load('empty_ico', empty_path, 'IMAGE')
        enum_items.append(('empty', '', "", empty_thumb.icon_id, 0))
    pcoll.hair_lib_prevs = enum_items
    pcoll.hair_lib_prev_dir = directory
    FORCE_UPDATE_THUMBS = False
    return pcoll.hair_lib_prevs


class HTOOL_OT_render_previews(bpy.types.Operator):
    bl_idname = "hair_lib.render_previews"
    bl_label = "Render previews"
    bl_description = "(re)Render all hairs previews"

    def execute(self, context):
        pref = get_addon_preferences()
        thumb_blend = os.path.join(os.path.dirname(__file__), 'render_thumb.blend')
        lib_path = pref.lib_path
        command = [bpy.app.binary_path,
                   thumb_blend,
                    '--python',
                    os.path.join(os.path.dirname(os.path.realpath(__file__)), 'generate_thumb.py'),
                    '--factory-startup',
                    '-b',
                    '--', #skip processing next line (blender command)
                    'all_thumbs',
                    lib_path] #warning this is sys.args[8], but order may change depending on above lines
        if pref.rerender:
            command.append('force_rerender')
        subprocess.Popen(command)
        # pcoll = preview_collections["main"]
        # pcoll.clear()
        return{'FINISHED'}


class HTOOL_OT_AppendObject(bpy.types.Operator):
    bl_idname = "hair_lib.append_object"
    bl_label = "Append"
    bl_description = 'Load hair preset from library'
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.scene.ht_props.lib_previews != 'empty'

    def execute(self, context):
        active_layer = context.view_layer.active_layer_collection
        if context.active_object and context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for ob in bpy.context.scene.objects:
            ob.select_set(False)
        bpy.ops.object.select_all(action='DESELECT')

        selected_preview = context.scene.ht_props.lib_previews
        append_element(selected_preview)
        context.view_layer.active_layer_collection = active_layer
        return{'FINISHED'}


class HTOOL_OT_OpenButton(bpy.types.Operator):
    bl_idname = "hair_lib.open_file"
    bl_label = "Open File"
    bl_description = 'Open hair file'

    @classmethod
    def poll(cls, context):
        return context.scene.ht_props.lib_previews != 'empty'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text='Open preset in new window?')

    def execute(self, context):
        selected_preview = context.scene.ht_props.lib_previews
        # bpy.ops.wm.open_mainfile(filepath=selected_preview)
        command = [bpy.app.binary_path, selected_preview]
        subprocess.Popen(command)
        return{'FINISHED'}



def scan_for_elements(directory):
    image_paths = []
    for fn in os.listdir(directory):
        if fn.lower().endswith('.blend'):
            png = fn.rsplit('.', 1)[0] + '.png'
            if png in os.listdir(directory):
                image_paths.append((fn, True))
            else:
                image_paths.append((fn, False))
    return image_paths



def get_thumbnails(blend_paths, enum_items, pcoll, empty_path, directory):
    # For each image in the directory, load the thumb
    # unless it has already been loaded
    for i, im in enumerate(blend_paths):
        blend_name, should_generate_preview = im
        blend_filepath = os.path.join(directory, blend_name)
        imgpath = blend_filepath[:-5]+'png'
        if blend_filepath in pcoll:
            if should_generate_preview: #if png related to blend exist in folder
                modified_time = os.path.getmtime(imgpath)  # remove .blend
                if blend_filepath not in pcoll.cached_icons_mod_time.keys():
                    pcoll.cached_icons_mod_time[imgpath] = modified_time - 2
                if pcoll.cached_icons_mod_time[imgpath] < modified_time:
                    pcoll[blend_filepath].reload()
                    pcoll.cached_icons_mod_time[imgpath] = modified_time
                thumb = pcoll[blend_filepath]
            else:  # thumb exist but no png? Maybe png was removed. use empty_path
                empty_thumb = pcoll['empty_ico'] if 'empty_ico' in pcoll else pcoll.load('empty_ico', empty_path, 'IMAGE')
                thumb = empty_thumb
        else:
            empty_thumb = pcoll['empty_ico'] if 'empty_ico' in pcoll else pcoll.load('empty_ico', empty_path, 'IMAGE')
            thumb = pcoll.load(blend_filepath, imgpath, 'IMAGE') if should_generate_preview else empty_thumb
        enum_items.append((blend_filepath, blend_name[:-6], "", thumb.icon_id, i))
    return enum_items



class HTOOL_OT_AlwaysDisabled(bpy.types.Operator):
    bl_idname = "hair_lib.disabled_oper"
    bl_label = ''
    bl_description = "Operation"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return False

    def execute(self, context):
       return {"FINISHED"}

class HTOOL_OT_LibDirOperations(bpy.types.Operator):
    bl_idname = "hair_lib.dir_operations"
    bl_label = ''
    bl_description = "Operation"
    bl_options = {"REGISTER"}

    folder: bpy.props.StringProperty(name="Folder",  default="")
    operation: bpy.props.EnumProperty(name='Operation', description='',
        items=[
            ('[..]', '[..]', ''),
            ('[ADD]', '[ADD]', ''),
            ('[DEL]', '[DEL]', ''),
            ('[RENAME]', '[RENAME]', ''),
            ('[RENAME_FILE]', '[RENAME_FILE]', ''),
            ('[GoTo]', '[GoTo]', ''),
            ('[DEL_FILE]', '[DEL_FILE]', ''),
            ('[DEL]', '[DEL]', '')
        ], default = '[..]')

    shift_clicked = False

    def invoke(self, context, event):
        if event.shift:
            self.shift_clicked = True
        if self.operation in ('[ADD]', '[DEL]', '[RENAME]', '[DEL_FILE]', '[RENAME_FILE]'):
            return context.window_manager.invoke_props_dialog(self)
        else:
            return self.execute(context)

    def draw(self, context):
        g_props = context.scene.ht_props
        layout = self.layout

        if self.operation in '[ADD]':
            layout.label(text = 'New folder name:')
            layout.prop(self, 'folder')

        if self.operation in '[RENAME]':
            files_count = len(g_props.bool_folders)
            if files_count == 0:
                layout.label(text='No folder(s) selected for renaming')
                layout.label(text='Cancelling')
            else:
                layout.label(text = 'New folder name:')
                layout.prop(self, 'folder')

        if self.operation in '[RENAME_FILE]':
            selected_blend = context.scene.ht_props.lib_previews
            if selected_blend == 'empty':
                layout.label(text='No presets selected for renaming')
                layout.label(text='Cancelling')
            else:
                old_name = os.path.split(selected_blend)[1][:-6]
                layout.label(text = f"Rename preset '{old_name}':")
                layout.prop(self, 'folder')

        elif self.operation == '[DEL]':
            files_count = len(g_props.bool_folders)
            if files_count == 0:
                layout.label(text='No categories selected for removal')
                layout.label(text='Cancelling')
            else:
                layout.label(text='Remove folder(s):')
                for sub_folder in g_props.bool_folders:
                    layout.label(text=f' - {os.path.basename(sub_folder)}') #gives part after the last /
                layout.label(text='from hairs library?')

        elif self.operation == '[DEL_FILE]':
            selected_blend = context.scene.ht_props.lib_previews
            if selected_blend == 'empty':
                layout.label(text='No presets selected for removal')
                layout.label(text='Cancelling')
            else:
                layout.label(text='Removing preset:')
                layout.label(text=f' - {selected_blend}')  # gives part after the last /


    def open_explorer(self, path):
        prefs = get_addon_preferences()
        if sys.platform == 'darwin':
            subprocess.Popen(['open', '--', path])
        elif sys.platform == 'linux':
            subprocess.Popen(['xdg-open', path])
        elif sys.platform == 'win32':
            subprocess.Popen(['explorer', path])


    def execute(self, context):
        prefs = get_addon_preferences()
        g_props = context.scene.ht_props
        pcoll = preview_collections["main"]

        if self.operation == '[..]': #go up one level
            if self.shift_clicked:
                path = os.path.join(prefs.lib_path, g_props.lib_relative_sub_path)
                self.open_explorer(path)
                return {"FINISHED"}
            g_props.lib_relative_sub_path = os.path.dirname(g_props.lib_relative_sub_path)

        elif self.operation == '[ADD]': #go up one level
            current_dir = os.path.join(prefs.lib_path, g_props.lib_relative_sub_path)
            new_dir = os.path.join(current_dir, self.folder)
            os.mkdir(new_dir)

        elif self.operation == '[RENAME]': #go up one level
            files_count = len(g_props.bool_folders)
            if files_count == 0:
                return {'CANCELLED'}
            for i,sub_folder in enumerate(g_props.bool_folders):
                current_dir = os.path.join(prefs.lib_path, sub_folder)
                parent_current_dir = os.path.dirname(current_dir)

                new_name = os.path.join(parent_current_dir, self.folder)
                suffix = str(i) if files_count > 1 else ''
                os.rename(current_dir, new_name+suffix)

        elif self.operation == '[RENAME_FILE]':  # go up one level
            selected_blend = context.scene.ht_props.lib_previews
            if selected_blend == 'empty':
                return {'CANCELLED'}
            current_dir = os.path.split(selected_blend)[0]
            if self.folder.endswith('.blend'):
                new_name = self.folder
            else:
                new_name = self.folder + '.blend'
            renamed_blend = os.path.join(current_dir, new_name)
            os.rename(selected_blend, renamed_blend)
            if os.path.exists(selected_blend[:-5]+'png'):
                os.rename(selected_blend[:-5]+'png', renamed_blend[:-5]+'png')


        elif self.operation == '[DEL]': #go up one level
            files_count = len(g_props.bool_folders)
            if files_count == 0:
                return {'CANCELLED'}
            for sub_folder in g_props.bool_folders:
                shutil.rmtree(os.path.join(prefs.lib_path, sub_folder[1:]))
            # g_props.lib_relative_sub_path = os.path.dirname(g_props.lib_relative_sub_path)

        elif self.operation == '[DEL_FILE]':  # go up one level
            selected_blend = context.scene.ht_props.lib_previews
            if selected_blend == 'empty':
                return {'CANCELLED'}
            png = selected_blend[:-5]+'png'
            try:
                os.remove(selected_blend)
                os.remove(png)
            except FileNotFoundError as Err:
                print(Err)
                return {'CANCELLED'}

            g_props.lib_previews = pcoll.hair_lib_prevs[0][0]

        elif self.operation == '[GoTo]':  # navigate to self.operation
            if self.shift_clicked:
                path = os.path.join(prefs.lib_path, self.folder)
                self.open_explorer(path)
                return {"FINISHED"}
            g_props.lib_relative_sub_path = self.folder

        g_props.bool_folders = set()
        global FORCE_UPDATE_FOLDERS
        FORCE_UPDATE_FOLDERS = True
        global FORCE_UPDATE_THUMBS
        FORCE_UPDATE_THUMBS = True
        return {"FINISHED"}


class HTOOL_MT_FolderOperations(bpy.types.Menu):
    bl_idname = "HTOOL_MT_FolderOperations"
    bl_label = "Folder operation"

    def draw(self, context):
        layout = self.layout
        layout.label(text = 'Manage categories')
        oper = layout.operator('hair_lib.dir_operations', text='Create')
        oper.operation = '[ADD]'
        oper = layout.operator('hair_lib.dir_operations', text='Delete (selected)')
        oper.operation = '[DEL]'
        oper = layout.operator('hair_lib.dir_operations', text='Rename (selected)')
        oper.operation = '[RENAME]'


class HTOOL_MT_FileOperations(bpy.types.Menu):
    bl_idname = "HTOOL_MT_FileOperations"
    bl_label = "File operation"

    def draw(self, context):
        layout = self.layout
        layout.label(text = 'Manage Presets')
        layout.operator("hair_lib.open_file", text='Open', icon='FILE_FOLDER')
        if context.scene.ht_props.lib_previews != 'empty':
            layout.operator('hair_lib.dir_operations', text='Delete', icon='TRASH').operation = '[DEL_FILE]'
            op = layout.operator('hair_lib.dir_operations', text='Rename', icon='OUTLINER_DATA_SURFACE')
            op.operation = '[RENAME_FILE]'
            selected_blend = context.scene.ht_props.lib_previews
            old_name = os.path.split(selected_blend)[1][:-6] if selected_blend != 'empty' else ''
            op.folder = old_name
        else:  # fake poll if false, since dir_operations dosent have it.
            layout.operator('hair_lib.disabled_oper', text='Delete', icon='TRASH')
            layout.operator('hair_lib.disabled_oper', text='Rename', icon='OUTLINER_DATA_SURFACE')
        if len(context.selected_objects) > 0:
            layout.operator('hair_lib.save_hair', text='Store preset', icon='FILE_NEW').with_screen_grab = True


# Panel
class HTOOL_PT_hairs_Lib(bpy.types.Panel):
    bl_idname = "HTOOL_PT_hairs_Lib"
    # Create a Panel in the Tool Shelf
    bl_label = "Library"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Hair Tool'
    bl_context = "objectmode"
    bl_options = {"DEFAULT_CLOSED"}
    bl_order = 2

    ''' Draw menu with materials list, empty slot. Each with submenu with list of materials, to replace it '''
    empty_mat_exist = False

    def get_sub_folders(self, rel_sub_dir):
        pref = get_addon_preferences()
        lib_path_len = len(pref.lib_path)
        sub_paths = []
        lib_extended_path = os.path.join(pref.lib_path, rel_sub_dir) #adds \\
        if os.path.exists(lib_extended_path):
            for fn in os.listdir(lib_extended_path):
                file_path = os.path.join(lib_extended_path, fn)
                if os.path.isdir(file_path):
                    relative_sub_dir = file_path[lib_path_len+1:]
                    sub_paths.append((relative_sub_dir, fn))
            return sub_paths
        else:
            return []

    # Draw
    def draw(self, context):
        layout = self.layout
        g_props = context.scene.ht_props
        curr_sub_dir = g_props.lib_relative_sub_path
        # layout.label(text=f'.\\{curr_sub_dir}')
        box = layout.box()
        row = box.row(align=True)
        if curr_sub_dir != '':
            oper = row.operator('hair_lib.dir_operations', text=f'../{curr_sub_dir}', icon='FILE_PARENT')
            oper.operation = '[..]'
        else:
            oper = row.operator('hair_lib.disabled_oper', text='..', icon='FILE_PARENT')
        row.menu('HTOOL_MT_FolderOperations', text='', icon='COLLAPSEMENU')
        sub_folders = self.get_sub_folders(curr_sub_dir)
        if sub_folders:
            split = box.split(factor=0.14, align=True)
            split.props_enum(g_props, 'bool_folders')
            col = split.column()
            for (sub_dir, fn) in sub_folders:
                oper = col.operator('hair_lib.dir_operations', text=fn, icon='FILE_FOLDER')
                oper.operation = '[GoTo]'
                oper.folder = sub_dir
        else:
            box.label(text='No sub-categories')

        box = layout.box()
        box.template_icon_view(g_props, "lib_previews", show_labels=True)
        row = box.row(align=True)
        row.operator("hair_lib.append_object")
        row.menu('HTOOL_MT_FileOperations', text='', icon='COLLAPSEMENU')


# @persistent
def every_2_seconds():
    # print('every 2 sec update')
    global CHECK_FOR_FILE_CHANGES
    CHECK_FOR_FILE_CHANGES = True
    return 2.5


@persistent
def handler_init_enum_htool(dummy):
    '''Prevet error X not in enum prop ScenehairProps  lib_previews'''
    #* why it was here again?
    return
    g_props = bpy.context.scene.ht_props
    pcoll = preview_collections["main"]
    if g_props.lib_previews not in pcoll.hair_lib_prevs:
        g_props.lib_previews = pcoll.hair_lib_prevs[0][0]

def reg(): #avoid 'register' name since autoload is using it
    bpy.app.timers.register(every_2_seconds, persistent=True)
    pcoll = bpy.utils.previews.new()
    pcoll.hair_lib_prev_dir = ""
    pcoll.hair_lib_prevs = ()
    pcoll.cached_icons_mod_time = {}  # store png modification time. if update found update icons
    pcoll.png_in_dir_count = {}  # store png file count per directory. if more or less png's found find new icons
    preview_collections["main"] = pcoll
    # bpy.app.handlers.load_post.append(handler_init_enum_htool)


def unreg():  # avoid 'unregister' name since autoload is using it
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()
    # if handler_init_enum_htool in bpy.app.handlers.load_post:
    #     bpy.app.handlers.load_post.remove(handler_init_enum_htool)
    bpy.app.timers.unregister(every_2_seconds)

